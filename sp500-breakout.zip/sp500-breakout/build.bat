@echo off
rem Builds sp500-breakout.exe on Windows and copies it to .\dist
setlocal
where cargo >nul 2>nul
if errorlevel 1 (
  echo Rust is not installed. Install it from https://rustup.rs ^(accept the defaults, including the
  echo Visual Studio C++ Build Tools it offers^), then run this file again.
  pause
  exit /b 1
)
echo Building the release executable. The first build downloads and compiles dependencies (a few minutes)...
cargo build --release
if errorlevel 1 (
  echo.
  echo The build failed. Please send the messages above to whoever is helping you.
  pause
  exit /b 1
)
if not exist dist mkdir dist
copy /Y target\release\sp500-breakout.exe dist\ >nul
copy /Y config.toml dist\ >nul
copy /Y .env.example dist\ >nul
echo.
echo Done: dist\sp500-breakout.exe   -- double-click it to open the app.
pause
