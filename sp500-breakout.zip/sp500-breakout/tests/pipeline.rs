//! End-to-end tests on the deterministic synthetic market (no network, no API key).
//!
//! The synthetic universe plants a LONG breakout in every stock with
//! `k % 5 == 1` and a SHORT breakout in every stock with `k % 5 == 2`
//! (symbols `SYN002`, `SYN003`, `SYN007`, ...), at ages 0-4 sessions.

use chrono::{DateTime, NaiveDate, TimeZone, Utc};

use sp500_breakout::breakout::Analyzer;
use sp500_breakout::config::Config;
use sp500_breakout::data::integrity::clean_bars;
use sp500_breakout::data::synthetic::SyntheticProvider;
use sp500_breakout::data::DataProvider;
use sp500_breakout::market::MarketState;
use sp500_breakout::scanner::{run_scan, ScanOptions};
use sp500_breakout::types::{Bar, Direction, MarketTrend, TrendAlignment};
use sp500_breakout::{chart, report};

fn end_date() -> NaiveDate {
    NaiveDate::from_ymd_opt(2026, 11, 13).unwrap()
}

/// A Saturday, so the latest completed session is Friday 2026-11-13.
fn now() -> DateTime<Utc> {
    Utc.with_ymd_and_hms(2026, 11, 14, 12, 0, 0).unwrap()
}

fn provider() -> SyntheticProvider {
    SyntheticProvider::demo(end_date())
}

fn bars_of(p: &SyntheticProvider, symbol: &str) -> Vec<Bar> {
    let raw = p.history(symbol, NaiveDate::from_ymd_opt(2000, 1, 1).unwrap(), end_date()).unwrap();
    clean_bars(&raw).0
}

#[test]
fn scan_ranks_only_fresh_and_developing_breakouts() {
    let cfg = Config::default();
    let p = provider();
    let opts = ScanOptions { as_of: None, now: now(), top_n: 10 };
    let res = run_scan(&cfg, &p, &opts).expect("scan should succeed on synthetic data");

    assert_eq!(res.as_of, end_date());
    assert_eq!(res.universe_size, 60);
    assert!(res.skipped.is_empty(), "unexpected skips: {:?}", res.skipped);

    // The gate into the main list.
    assert!(!res.ranked.is_empty(), "planted breakouts should produce signals");
    assert!(res.ranked.len() <= 10);
    assert!(res.ranked.iter().all(|s| s.classification.is_eligible()));
    assert!(res.ranked.windows(2).all(|w| w[0].composite >= w[1].composite));
    assert!(res.ranked.iter().all(|s| (0.0..=100.0).contains(&s.composite)));
    assert!(res.ranked.iter().all(|s| (0.0..=100.0).contains(&s.rigidity)));

    // One entry per ticker.
    let mut symbols: Vec<&str> = res.ranked.iter().map(|s| s.symbol.as_str()).collect();
    symbols.sort();
    symbols.dedup();
    assert_eq!(symbols.len(), res.ranked.len());

    // Ineligible classes exist in the evaluated set but never in the ranking.
    assert!(res.events.iter().any(|s| !s.classification.is_eligible()));
    assert!(res.events.len() > res.ranked.len());

    // Recency: nothing in the list is older than the DEVELOPING limit.
    assert!(res
        .ranked
        .iter()
        .all(|s| s.age <= cfg.classification.developing_max_age || s.is_continuation));
}

#[test]
fn a_smaller_top_n_is_respected_and_never_padded_with_ineligible_signals() {
    let cfg = Config::default();
    let p = provider();
    let three = run_scan(&cfg, &p, &ScanOptions { as_of: None, now: now(), top_n: 3 }).unwrap();
    assert!(three.ranked.len() <= 3);
    assert!(three.ranked.iter().all(|s| s.is_eligible()));
}

#[test]
fn reports_and_charts_render_for_ranked_signals() {
    let cfg = Config::default();
    let p = provider();
    let res = run_scan(&cfg, &p, &ScanOptions { as_of: None, now: now(), top_n: 10 }).unwrap();

    let table = report::render_table(&res.ranked);
    assert!(table.contains("Rank") && table.contains("Ticker") && table.contains("Score"));
    assert!(table.lines().count() >= res.ranked.len() + 2);

    let text = report::render_explanations(&res.ranked);
    assert!(text.contains("rigidity"));

    let first = &res.ranked[0];
    let bars = res.history.get(&first.symbol).expect("history kept for ranked symbols");
    let svg = chart::render_svg(&first.symbol, bars, Some(first), &cfg);
    assert!(svg.starts_with("<svg") && svg.trim_end().ends_with("</svg>"));
    assert!(svg.contains("Breakout"));
    assert!(!svg.contains("NaN"));
}

#[test]
fn analysis_is_causal_the_breakout_level_does_not_depend_on_later_bars() {
    // SYN007 (k = 6): planted LONG whose breakout bar is one session before the last bar.
    let p = provider();
    let bars = bars_of(&p, "SYN007");
    let n = bars.len();
    let cfg = Config::default();
    let market = MarketState::neutral();
    let analyzer = Analyzer::new(&cfg);

    // Same window start in both runs; the second simply stops one bar earlier.
    let full = analyzer.analyze("SYN007", "x", &bars[n - 504..], &market);
    let cut = analyzer.analyze("SYN007", "x", &bars[n - 504..n - 1], &market);

    let date = bars[n - 2].date;
    let f = full
        .iter()
        .find(|s| s.breakout_date == date && s.direction == Direction::Long)
        .expect("breakout found when the bars after it are visible");
    let c = cut
        .iter()
        .find(|s| s.breakout_date == date && s.direction == Direction::Long)
        .expect("same breakout found on the day it happened");

    assert_eq!(f.age, 1);
    assert_eq!(c.age, 0);
    assert_eq!(f.level, c.level, "level must be computed from information before the breakout");
    assert!((f.rigidity - c.rigidity).abs() < 1e-9);
    assert_eq!(f.zone_lower, c.zone_lower);
    assert_eq!(f.zone_upper, c.zone_upper);
}

#[test]
fn planted_short_is_detected_and_flagged_countertrend_in_a_bullish_market() {
    // SYN003 (k = 2): planted SHORT, breakout on the last bar. The synthetic index trends up.
    let p = provider();
    let cfg = Config::default();
    let index = bars_of(&p, "^GSPC");
    let market = MarketState::from_bars(&index[index.len() - 504..], &cfg.market);
    assert_eq!(market.trend, MarketTrend::Bullish);

    let bars = bars_of(&p, "SYN003");
    let n = bars.len();
    let signals = Analyzer::new(&cfg).analyze("SYN003", "Synthetic Company 3", &bars[n - 504..], &market);
    let s = signals
        .iter()
        .find(|s| s.direction == Direction::Short && s.is_eligible())
        .expect("planted short should be an eligible breakout");
    assert_eq!(s.trend_alignment, TrendAlignment::Countertrend);
    assert!(s.score.adjustments.trend < 0.0, "countertrend must be penalised");
    assert!(s.level > s.close, "SHORT: close is below the broken support level");
    assert!(s.extension_atr > 0.0);
}

#[test]
fn historical_as_of_scan_never_uses_later_data() {
    let cfg = Config::default();
    let p = provider();
    let as_of = NaiveDate::from_ymd_opt(2026, 10, 30).unwrap(); // a Friday two weeks earlier
    let res = run_scan(&cfg, &p, &ScanOptions { as_of: Some(as_of), now: now(), top_n: 10 }).unwrap();

    assert_eq!(res.as_of, as_of);
    assert!(res.events.iter().all(|s| s.as_of == as_of && s.breakout_date <= as_of));
    assert!(res.ranked.iter().all(|s| s.is_eligible()));
    // the planted breakouts happen after this date, so none of those signals can exist yet
    assert!(res.history.values().all(|b| b.last().map(|x| x.date) == Some(as_of)));
}

#[test]
fn an_incomplete_same_day_session_is_never_analysed() {
    // 15:00 UTC on a trading day = 10:00 ET: today's bar is not final.
    let cfg = Config::default();
    let p = SyntheticProvider::demo(NaiveDate::from_ymd_opt(2026, 11, 13).unwrap());
    let intraday = Utc.with_ymd_and_hms(2026, 11, 13, 15, 0, 0).unwrap();
    let res = run_scan(&cfg, &p, &ScanOptions { as_of: None, now: intraday, top_n: 10 }).unwrap();
    assert_eq!(res.as_of, NaiveDate::from_ymd_opt(2026, 11, 12).unwrap());
}
