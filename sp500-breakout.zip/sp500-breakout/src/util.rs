//! Small numeric helpers shared by several modules.

use std::cmp::Ordering;

/// Clamp to `[0, 1]`; NaN maps to 0 so a missing measurement never adds score.
pub fn clamp01(x: f64) -> f64 {
    if x.is_nan() || x < 0.0 {
        0.0
    } else if x > 1.0 {
        1.0
    } else {
        x
    }
}

/// Saturating map `[0, inf) -> [0, 1)`: `1 - exp(-x / scale)`.
///
/// Used wherever "more is better, but with diminishing returns" is wanted so
/// that no single unusually large measurement can dominate a score.
pub fn saturate(x: f64, scale: f64) -> f64 {
    if !x.is_finite() || scale <= 0.0 {
        return 0.0;
    }
    1.0 - (-x.max(0.0) / scale).exp()
}

/// Exponential half-life decay weight in `(0, 1]`.
pub fn half_life_weight(age: f64, half_life: f64) -> f64 {
    if half_life <= 0.0 {
        return 1.0;
    }
    0.5f64.powf(age.max(0.0) / half_life)
}

pub fn mean(values: &[f64]) -> f64 {
    if values.is_empty() {
        return f64::NAN;
    }
    values.iter().sum::<f64>() / values.len() as f64
}

/// Mean over the finite values only; NaN if there are none.
pub fn mean_finite(values: &[f64]) -> f64 {
    let mut sum = 0.0;
    let mut n = 0usize;
    for &v in values {
        if v.is_finite() {
            sum += v;
            n += 1;
        }
    }
    if n == 0 {
        f64::NAN
    } else {
        sum / n as f64
    }
}

/// Sample standard deviation (n - 1 denominator).
pub fn std_dev(values: &[f64]) -> f64 {
    let n = values.len();
    if n < 2 {
        return f64::NAN;
    }
    let m = mean(values);
    let var = values.iter().map(|v| (v - m) * (v - m)).sum::<f64>() / (n as f64 - 1.0);
    var.sqrt()
}

pub fn median(values: &[f64]) -> f64 {
    if values.is_empty() {
        return f64::NAN;
    }
    let mut v: Vec<f64> = values.to_vec();
    v.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
    let n = v.len();
    if n % 2 == 1 {
        v[n / 2]
    } else {
        (v[n / 2 - 1] + v[n / 2]) / 2.0
    }
}

/// Average ranks (ties share the mean rank), 1-based.
pub fn ranks(values: &[f64]) -> Vec<f64> {
    let n = values.len();
    let mut idx: Vec<usize> = (0..n).collect();
    idx.sort_by(|&a, &b| values[a].partial_cmp(&values[b]).unwrap_or(Ordering::Equal));
    let mut out = vec![0.0; n];
    let mut i = 0;
    while i < n {
        let mut j = i;
        while j + 1 < n && values[idx[j + 1]] == values[idx[i]] {
            j += 1;
        }
        let avg = (i + j) as f64 / 2.0 + 1.0;
        for k in i..=j {
            out[idx[k]] = avg;
        }
        i = j + 1;
    }
    out
}

pub fn pearson(x: &[f64], y: &[f64]) -> f64 {
    let n = x.len().min(y.len());
    if n < 3 {
        return f64::NAN;
    }
    let mx = mean(&x[..n]);
    let my = mean(&y[..n]);
    let mut sxy = 0.0;
    let mut sxx = 0.0;
    let mut syy = 0.0;
    for i in 0..n {
        let dx = x[i] - mx;
        let dy = y[i] - my;
        sxy += dx * dy;
        sxx += dx * dx;
        syy += dy * dy;
    }
    if sxx <= 0.0 || syy <= 0.0 {
        return f64::NAN;
    }
    sxy / (sxx.sqrt() * syy.sqrt())
}

/// Spearman rank correlation (information coefficient).
pub fn spearman(x: &[f64], y: &[f64]) -> f64 {
    let n = x.len().min(y.len());
    if n < 3 {
        return f64::NAN;
    }
    pearson(&ranks(&x[..n]), &ranks(&y[..n]))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clamp_and_saturate() {
        assert_eq!(clamp01(f64::NAN), 0.0);
        assert_eq!(clamp01(-3.0), 0.0);
        assert_eq!(clamp01(2.0), 1.0);
        assert!(saturate(100.0, 1.0) < 1.0);
        assert!(saturate(1.0, 1.0) > 0.6 && saturate(1.0, 1.0) < 0.7);
    }

    #[test]
    fn ranks_handle_ties() {
        let r = ranks(&[10.0, 20.0, 20.0, 30.0]);
        assert_eq!(r, vec![1.0, 2.5, 2.5, 4.0]);
    }

    #[test]
    fn spearman_is_monotone_invariant() {
        let x = [1.0, 2.0, 3.0, 4.0, 5.0];
        let y = [1.0, 4.0, 9.0, 16.0, 25.0];
        assert!((spearman(&x, &y) - 1.0).abs() < 1e-12);
    }

    #[test]
    fn median_even_and_odd() {
        assert_eq!(median(&[3.0, 1.0, 2.0]), 2.0);
        assert_eq!(median(&[4.0, 1.0, 2.0, 3.0]), 2.5);
    }
}
