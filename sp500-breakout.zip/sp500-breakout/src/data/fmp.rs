//! Financial Modeling Prep (FMP) provider, `stable` API.
//!
//! Endpoints used (all `GET`, authenticated with `?apikey=`):
//!
//! * `sp500-constituent`                           - current members
//! * `historical-sp500-constituent`                - index additions / removals
//! * `historical-price-eod/dividend-adjusted`      - daily bars (default)
//! * `historical-price-eod/full`                   - daily bars, split-adjusted only
//!
//! The API key is read from the environment variable named by
//! `data.api_key_env` (default `FMP_API_KEY`) and is never written to logs:
//! every error path strips the request URL, which is where the key lives.

use std::sync::Mutex;
use std::time::{Duration, Instant};

use chrono::NaiveDate;
use serde::de::DeserializeOwned;
use serde::Deserialize;

use super::csv_source::parse_date;
use super::provider::DataProvider;
use crate::config::DataConfig;
use crate::error::{Error, Result};
use crate::types::{Constituent, MembershipChange, RawBar};

/// Global request pacing shared by every download thread: request start times
/// are spaced at least `min_interval` apart, so the whole program stays under the
/// plan's per-minute limit however many threads are downloading.
struct Throttle {
    min_interval: Duration,
    next: Mutex<Instant>,
}

impl Throttle {
    fn new(requests_per_minute: u32) -> Self {
        let min_interval = if requests_per_minute == 0 {
            Duration::ZERO
        } else {
            Duration::from_secs_f64(60.0 / requests_per_minute as f64)
        };
        Self { min_interval, next: Mutex::new(Instant::now()) }
    }

    /// Reserve the next request slot as of `now`; returns how long to wait before using it.
    fn reserve(&self, now: Instant) -> Duration {
        if self.min_interval.is_zero() {
            return Duration::ZERO;
        }
        let mut next = self.next.lock().unwrap_or_else(|p| p.into_inner());
        let start = if *next > now { *next } else { now };
        *next = start + self.min_interval;
        start.saturating_duration_since(now)
    }

    fn wait(&self) {
        let d = self.reserve(Instant::now());
        if !d.is_zero() {
            std::thread::sleep(d);
        }
    }
}

pub struct FmpProvider {
    client: reqwest::blocking::Client,
    api_key: String,
    base_url: String,
    price_endpoint: String,
    delay: Duration,
    throttle: Throttle,
    max_retries: u32,
}

#[derive(Debug, Deserialize)]
struct FmpConstituent {
    symbol: String,
    #[serde(default)]
    name: Option<String>,
    #[serde(default)]
    sector: Option<String>,
    #[serde(default, rename = "dateFirstAdded")]
    date_first_added: Option<String>,
}

#[derive(Debug, Deserialize)]
struct FmpChange {
    #[serde(default)]
    date: Option<String>,
    #[serde(default, rename = "dateAdded")]
    date_added: Option<String>,
    /// Ticker that joined the index.
    #[serde(default)]
    symbol: Option<String>,
    #[serde(default, rename = "removedTicker")]
    removed_ticker: Option<String>,
}

#[derive(Debug, Deserialize)]
struct FmpBar {
    date: String,
    #[serde(default)]
    open: Option<f64>,
    #[serde(default)]
    high: Option<f64>,
    #[serde(default)]
    low: Option<f64>,
    #[serde(default)]
    close: Option<f64>,
    #[serde(default, rename = "adjOpen")]
    adj_open: Option<f64>,
    #[serde(default, rename = "adjHigh")]
    adj_high: Option<f64>,
    #[serde(default, rename = "adjLow")]
    adj_low: Option<f64>,
    #[serde(default, rename = "adjClose")]
    adj_close: Option<f64>,
    #[serde(default)]
    volume: Option<f64>,
}

/// Prefer the adjusted columns when the endpoint supplies them. Because the
/// whole OHLC range comes from the same series, `adj_close == close` and the
/// downstream adjustment factor is 1.
fn bar_from_row(r: FmpBar) -> Option<RawBar> {
    let date = parse_date(&r.date).ok()?;
    let open = r.adj_open.or(r.open)?;
    let high = r.adj_high.or(r.high)?;
    let low = r.adj_low.or(r.low)?;
    let close = r.adj_close.or(r.close)?;
    Some(RawBar { date, open, high, low, close, adj_close: close, volume: r.volume.unwrap_or(0.0) })
}

fn nonempty(s: Option<String>) -> Option<String> {
    s.map(|v| v.trim().to_string()).filter(|v| !v.is_empty())
}

fn change_from_row(r: FmpChange) -> Option<MembershipChange> {
    let date = r
        .date
        .as_deref()
        .and_then(|s| parse_date(s).ok())
        .or_else(|| r.date_added.as_deref().and_then(|s| NaiveDate::parse_from_str(s.trim(), "%B %d, %Y").ok()))?;
    let added = nonempty(r.symbol);
    let removed = nonempty(r.removed_ticker);
    if added.is_none() && removed.is_none() {
        return None;
    }
    Some(MembershipChange { date, added, removed })
}

impl FmpProvider {
    pub fn from_config(cfg: &DataConfig) -> Result<Self> {
        let api_key = cfg
            .api_key_override
            .clone()
            .filter(|k| !k.trim().is_empty())
            .unwrap_or_else(|| std::env::var(&cfg.api_key_env).unwrap_or_default());
        if api_key.trim().is_empty() {
            return Err(Error::Config(format!(
                "no Financial Modeling Prep API key found: set the {} environment variable, put it in a \
                 .env file, or paste it into the app's API key box. Demo data and local CSV files need no key.",
                cfg.api_key_env
            )));
        }
        let client = reqwest::blocking::Client::builder()
            .timeout(Duration::from_secs(30))
            .user_agent(concat!("sp500-breakout/", env!("CARGO_PKG_VERSION")))
            .build()
            .map_err(|e| Error::Provider(e.without_url().to_string()))?;
        Ok(Self {
            client,
            api_key: api_key.trim().to_string(),
            base_url: cfg.fmp_base_url.trim_end_matches('/').to_string(),
            price_endpoint: cfg.fmp_price_endpoint.clone(),
            delay: Duration::from_millis(cfg.request_delay_ms),
            throttle: Throttle::new(cfg.max_requests_per_minute),
            max_retries: cfg.max_retries,
        })
    }

    fn get_text(&self, path: &str, query: &[(&str, &str)]) -> Result<String> {
        let url = format!("{}/{}", self.base_url, path);
        let mut attempt = 0u32;
        loop {
            self.throttle.wait();
            if !self.delay.is_zero() {
                std::thread::sleep(self.delay);
            }
            let sent = self
                .client
                .get(&url)
                .query(query)
                .query(&[("apikey", self.api_key.as_str())])
                .send();
            match sent {
                Ok(resp) => {
                    let status = resp.status();
                    if status.is_success() {
                        return resp.text().map_err(|e| Error::Provider(e.without_url().to_string()));
                    }
                    let retryable = status.as_u16() == 429 || status.is_server_error();
                    if retryable && attempt < self.max_retries {
                        backoff(attempt);
                        attempt += 1;
                        continue;
                    }
                    let body = resp.text().unwrap_or_default();
                    let snippet: String = body.chars().take(200).collect();
                    return Err(Error::Provider(format!("HTTP {} from {path}: {snippet}", status.as_u16())));
                }
                Err(e) => {
                    if attempt < self.max_retries && (e.is_timeout() || e.is_connect()) {
                        backoff(attempt);
                        attempt += 1;
                        continue;
                    }
                    return Err(Error::Provider(format!("request to {path} failed: {}", e.without_url())));
                }
            }
        }
    }

    fn get_json<T: DeserializeOwned>(&self, path: &str, query: &[(&str, &str)]) -> Result<T> {
        let text = self.get_text(path, query)?;
        serde_json::from_str::<T>(&text).map_err(|e| {
            let snippet: String = text.chars().take(160).collect();
            Error::Provider(format!("unexpected response from {path}: {e}; body starts: {snippet}"))
        })
    }
}

fn backoff(attempt: u32) {
    let ms = 500u64.saturating_mul(2u64.saturating_pow(attempt.min(6)));
    std::thread::sleep(Duration::from_millis(ms));
}

impl DataProvider for FmpProvider {
    fn name(&self) -> &str {
        "fmp"
    }

    fn constituents(&self) -> Result<Vec<Constituent>> {
        let rows: Vec<FmpConstituent> = self.get_json("sp500-constituent", &[])?;
        let mut out: Vec<Constituent> = Vec::with_capacity(rows.len());
        for r in rows {
            if r.symbol.trim().is_empty() || out.iter().any(|c| c.symbol == r.symbol) {
                continue;
            }
            let date_added = r.date_first_added.as_deref().and_then(|s| parse_date(s).ok());
            let name = nonempty(r.name).unwrap_or_else(|| r.symbol.clone());
            out.push(Constituent { symbol: r.symbol.trim().to_string(), name, sector: nonempty(r.sector), date_added });
        }
        if out.is_empty() {
            return Err(Error::Provider("sp500-constituent returned no rows".into()));
        }
        Ok(out)
    }

    fn membership_changes(&self) -> Result<Vec<MembershipChange>> {
        let rows: Vec<FmpChange> = self.get_json("historical-sp500-constituent", &[])?;
        Ok(rows.into_iter().filter_map(change_from_row).collect())
    }

    fn history(&self, symbol: &str, from: NaiveDate, to: NaiveDate) -> Result<Vec<RawBar>> {
        let from_s = from.to_string();
        let to_s = to.to_string();
        // Indices (symbols starting with '^') have no dividends, so use the plain
        // endpoint for them even when dividend-adjusted prices are configured.
        let endpoint = if symbol.starts_with('^') { "full" } else { self.price_endpoint.as_str() };
        let path = format!("historical-price-eod/{endpoint}");
        let rows: Vec<FmpBar> =
            self.get_json(&path, &[("symbol", symbol), ("from", from_s.as_str()), ("to", to_s.as_str())])?;
        let mut bars: Vec<RawBar> = rows.into_iter().filter_map(bar_from_row).collect();
        bars.sort_by_key(|b| b.date);
        Ok(bars)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_dividend_adjusted_rows() {
        let json = r#"[{"symbol":"AAPL","date":"2026-11-12","adjOpen":200.5,"adjHigh":205.0,"adjLow":199.0,"adjClose":204.0,"volume":51234567}]"#;
        let rows: Vec<FmpBar> = serde_json::from_str(json).unwrap();
        let bar = bar_from_row(rows.into_iter().next().unwrap()).unwrap();
        assert_eq!(bar.close, 204.0);
        assert_eq!(bar.adj_close, 204.0);
        assert_eq!(bar.volume, 51234567.0);
    }

    #[test]
    fn parses_plain_rows_and_skips_incomplete_ones() {
        let json = r#"[{"date":"2026-11-12","open":1,"high":2,"low":0.5,"close":1.5,"volume":10},
                       {"date":"2026-11-11","open":1,"high":2}]"#;
        let rows: Vec<FmpBar> = serde_json::from_str(json).unwrap();
        let bars: Vec<RawBar> = rows.into_iter().filter_map(bar_from_row).collect();
        assert_eq!(bars.len(), 1);
        assert_eq!(bars[0].close, 1.5);
    }

    #[test]
    fn parses_membership_changes_with_either_date_format() {
        let json = r#"[{"dateAdded":"June 29, 2026","addedSecurity":"Honeywell Aerospace Inc","removedTicker":"CAG","removedSecurity":"Conagra Brands","date":"2026-06-29","symbol":"HONA","reason":"x"},
                       {"dateAdded":"March 3, 2025","symbol":"NEW","removedTicker":""}]"#;
        let rows: Vec<FmpChange> = serde_json::from_str(json).unwrap();
        let ch: Vec<MembershipChange> = rows.into_iter().filter_map(change_from_row).collect();
        assert_eq!(ch.len(), 2);
        assert_eq!(ch[0].date, NaiveDate::from_ymd_opt(2026, 6, 29).unwrap());
        assert_eq!(ch[0].added.as_deref(), Some("HONA"));
        assert_eq!(ch[0].removed.as_deref(), Some("CAG"));
        assert_eq!(ch[1].date, NaiveDate::from_ymd_opt(2025, 3, 3).unwrap());
        assert_eq!(ch[1].removed, None);
    }

    #[test]
    fn throttle_spaces_requests_evenly() {
        let t = Throttle::new(600); // one request every 100 ms
        let now = Instant::now();
        let a = t.reserve(now);
        let b = t.reserve(now);
        let c = t.reserve(now);
        assert_eq!(a, Duration::ZERO);
        assert!(b >= Duration::from_millis(99) && b <= Duration::from_millis(101));
        assert!(c >= Duration::from_millis(199) && c <= Duration::from_millis(201));
        // later, with the slot long expired, there is no wait
        assert_eq!(t.reserve(now + Duration::from_secs(10)), Duration::ZERO);
    }

    #[test]
    fn zero_rate_means_unlimited() {
        let t = Throttle::new(0);
        let now = Instant::now();
        assert_eq!(t.reserve(now), Duration::ZERO);
        assert_eq!(t.reserve(now), Duration::ZERO);
    }

    #[test]
    fn missing_key_is_a_clear_config_error() {
        let cfg = DataConfig { api_key_env: "SP500_TEST_KEY_THAT_IS_NOT_SET".into(), ..DataConfig::default() };
        match FmpProvider::from_config(&cfg) {
            Err(Error::Config(msg)) => assert!(msg.contains("SP500_TEST_KEY_THAT_IS_NOT_SET")),
            _ => panic!("expected a config error"),
        }
    }
}
