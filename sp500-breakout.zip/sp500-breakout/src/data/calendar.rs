//! US equity-session calendar helpers.
//!
//! Only weekends are known here (no holiday table): holidays simply produce no
//! bar from the provider, and the index series is used as the authoritative
//! trading calendar everywhere else.

use chrono::{DateTime, Datelike, Duration, NaiveDate, NaiveTime, Utc, Weekday};
use chrono_tz::America::New_York;

fn close_time(buffer_minutes: i64) -> NaiveTime {
    // 16:00 ET plus a settling buffer so late prints and the official close are in.
    let base = NaiveTime::from_hms_opt(16, 0, 0).expect("valid time");
    base + Duration::minutes(buffer_minutes.max(0))
}

fn is_weekday(d: NaiveDate) -> bool {
    !matches!(d.weekday(), Weekday::Sat | Weekday::Sun)
}

/// Latest weekday on or before `d`.
pub fn last_weekday_on_or_before(mut d: NaiveDate) -> NaiveDate {
    while !is_weekday(d) {
        d -= Duration::days(1);
    }
    d
}

/// Is the daily bar for `date` final? A past date always is; today's bar only
/// once the regular session has closed (plus `buffer_minutes`); the future never.
pub fn session_is_complete(date: NaiveDate, now: DateTime<Utc>, buffer_minutes: i64) -> bool {
    let et = now.with_timezone(&New_York);
    let today = et.date_naive();
    if date < today {
        true
    } else if date == today {
        is_weekday(today) && et.time() >= close_time(buffer_minutes)
    } else {
        false
    }
}

/// Best estimate of the most recent completed session at `now` (weekend-aware,
/// holiday-blind): today if the market has closed, otherwise the previous weekday.
pub fn last_completed_session_estimate(now: DateTime<Utc>, buffer_minutes: i64) -> NaiveDate {
    let et = now.with_timezone(&New_York);
    let today = et.date_naive();
    let candidate = if is_weekday(today) && et.time() >= close_time(buffer_minutes) {
        today
    } else {
        today - Duration::days(1)
    };
    last_weekday_on_or_before(candidate)
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::TimeZone;

    fn utc(y: i32, m: u32, d: u32, h: u32, min: u32) -> DateTime<Utc> {
        Utc.with_ymd_and_hms(y, m, d, h, min, 0).unwrap()
    }

    #[test]
    fn weekend_rolls_back_to_friday() {
        let sat = NaiveDate::from_ymd_opt(2026, 11, 14).unwrap();
        assert_eq!(last_weekday_on_or_before(sat), NaiveDate::from_ymd_opt(2026, 11, 13).unwrap());
    }

    #[test]
    fn same_day_bar_is_incomplete_before_close() {
        // Wed 2026-11-11 15:00 UTC = 10:00 ET
        let now = utc(2026, 11, 11, 15, 0);
        let today = NaiveDate::from_ymd_opt(2026, 11, 11).unwrap();
        assert!(!session_is_complete(today, now, 20));
        assert!(session_is_complete(today - Duration::days(1), now, 20));
        assert_eq!(last_completed_session_estimate(now, 20), today - Duration::days(1));
    }

    #[test]
    fn same_day_bar_is_complete_after_close_plus_buffer() {
        // 22:00 UTC = 17:00 ET
        let now = utc(2026, 11, 11, 22, 0);
        let today = NaiveDate::from_ymd_opt(2026, 11, 11).unwrap();
        assert!(session_is_complete(today, now, 20));
        assert_eq!(last_completed_session_estimate(now, 20), today);
        // 21:10 UTC = 16:10 ET is inside the 20-minute buffer
        assert!(!session_is_complete(today, utc(2026, 11, 11, 21, 10), 20));
    }

    #[test]
    fn saturday_estimate_is_friday() {
        let now = utc(2026, 11, 14, 12, 0);
        assert_eq!(
            last_completed_session_estimate(now, 20),
            NaiveDate::from_ymd_opt(2026, 11, 13).unwrap()
        );
    }
}
