//! Data integrity (spec 2.3): adjustment, sanitising, incomplete-session
//! removal and anomaly detection.

use std::collections::HashSet;

use chrono::{DateTime, NaiveDate, Utc};

use super::calendar;
use crate::config::DataConfig;
use crate::types::{Bar, RawBar};

/// Convert provider bars into clean, ascending, de-duplicated, back-adjusted bars.
///
/// * Split/dividend adjustment is applied via `adj_close / close` (see [`RawBar::adjusted`]).
/// * Bars with non-positive or non-finite prices are dropped (and reported).
/// * Wicks are repaired so `low <= open, close <= high`.
/// * Negative or non-finite volume becomes 0.
///
/// Returns the bars plus human-readable warnings.
pub fn clean_bars(raw: &[RawBar]) -> (Vec<Bar>, Vec<String>) {
    let mut warnings = Vec::new();
    let mut bars: Vec<Bar> = Vec::with_capacity(raw.len());
    let mut dropped = 0usize;
    let mut repaired = 0usize;

    for r in raw {
        let mut b = r.adjusted();
        let valid = [b.open, b.high, b.low, b.close].iter().all(|v| v.is_finite() && *v > 0.0);
        if !valid {
            dropped += 1;
            continue;
        }
        let hi = b.high.max(b.open).max(b.close);
        let lo = b.low.min(b.open).min(b.close);
        if hi != b.high || lo != b.low {
            repaired += 1;
        }
        b.high = hi;
        b.low = lo;
        if !b.volume.is_finite() || b.volume < 0.0 {
            b.volume = 0.0;
        }
        bars.push(b);
    }

    bars.sort_by_key(|b| b.date);
    let before = bars.len();
    bars.dedup_by_key(|b| b.date);
    let dupes = before - bars.len();

    if dropped > 0 {
        warnings.push(format!("dropped {dropped} bars with invalid prices"));
    }
    if repaired > 0 {
        warnings.push(format!("repaired high/low on {repaired} bars"));
    }
    if dupes > 0 {
        warnings.push(format!("removed {dupes} duplicate dates"));
    }
    (bars, warnings)
}

/// Remove bars that are not yet final (after `cap`, or a same-day bar before
/// the close) so no signal is ever generated from an incomplete session.
/// Returns how many bars were removed.
pub fn drop_incomplete(bars: &mut Vec<Bar>, now: DateTime<Utc>, cap: NaiveDate, buffer_minutes: i64) -> usize {
    let before = bars.len();
    bars.retain(|b| b.date <= cap && calendar::session_is_complete(b.date, now, buffer_minutes));
    before - bars.len()
}

/// Keep only the most recent `n` bars.
pub fn keep_last(bars: &mut Vec<Bar>, n: usize) {
    if bars.len() > n {
        let cut = bars.len() - n;
        bars.drain(..cut);
    }
}

#[derive(Debug, Default, Clone)]
pub struct IntegrityReport {
    /// Reasons the symbol must be excluded from the scan.
    pub fatal: Vec<String>,
    /// Anomalies worth knowing about that do not disqualify the symbol.
    pub warnings: Vec<String>,
}

impl IntegrityReport {
    pub fn is_ok(&self) -> bool {
        self.fatal.is_empty()
    }
}

/// Validate one stock's cleaned bars against the index trading calendar.
///
/// Fatal: too little history; last bar is not `as_of` (stale); missing sessions
/// (overall share or inside the recent window); zero volume on the latest bar.
/// Warnings: older isolated gaps, abnormal single-day moves (possible
/// unadjusted split), many zero-volume days.
pub fn validate(
    symbol: &str,
    bars: &[Bar],
    index_dates: &[NaiveDate],
    as_of: NaiveDate,
    cfg: &DataConfig,
) -> IntegrityReport {
    let mut rep = IntegrityReport::default();

    if bars.len() < cfg.min_history_sessions {
        rep.fatal.push(format!(
            "{symbol}: only {} sessions of history (need {})",
            bars.len(),
            cfg.min_history_sessions
        ));
        return rep;
    }
    let last = bars[bars.len() - 1].date;
    if last != as_of {
        rep.fatal.push(format!("{symbol}: stale data, last bar {last} but analysis date is {as_of}"));
        return rep;
    }
    if bars[bars.len() - 1].volume <= 0.0 {
        rep.fatal.push(format!("{symbol}: zero volume on the latest session (incomplete or unreliable)"));
        return rep;
    }

    // Completeness against the index calendar.
    let first = bars[0].date;
    let have: HashSet<NaiveDate> = bars.iter().map(|b| b.date).collect();
    let expected: Vec<NaiveDate> = index_dates.iter().copied().filter(|d| *d >= first && *d <= as_of).collect();
    let missing: Vec<NaiveDate> = expected.iter().copied().filter(|d| !have.contains(d)).collect();
    if !expected.is_empty() {
        let frac = missing.len() as f64 / expected.len() as f64;
        if frac > cfg.max_missing_fraction {
            rep.fatal.push(format!(
                "{symbol}: {:.1}% of sessions missing (limit {:.1}%)",
                frac * 100.0,
                cfg.max_missing_fraction * 100.0
            ));
            return rep;
        }
    }
    let recent: HashSet<NaiveDate> = index_dates
        .iter()
        .rev()
        .filter(|d| **d <= as_of)
        .take(cfg.recent_window)
        .copied()
        .collect();
    let recent_missing = missing.iter().filter(|d| recent.contains(d)).count();
    if recent_missing > cfg.max_recent_missing {
        rep.fatal.push(format!("{symbol}: {recent_missing} sessions missing inside the last {} sessions", cfg.recent_window));
        return rep;
    }
    if !missing.is_empty() {
        rep.warnings.push(format!("{symbol}: {} missing sessions (older than the recent window)", missing.len()));
    }

    // Anomalous moves (possible unadjusted splits / bad prints).
    let mut jumps = 0usize;
    for w in bars.windows(2) {
        let r = w[1].close / w[0].close - 1.0;
        if r.abs() > cfg.max_abs_daily_return {
            jumps += 1;
        }
    }
    if jumps > 0 {
        rep.warnings.push(format!(
            "{symbol}: {jumps} daily moves larger than {:.0}% (check split adjustment)",
            cfg.max_abs_daily_return * 100.0
        ));
    }

    let zero_vol = bars.iter().filter(|b| b.volume <= 0.0).count();
    if zero_vol as f64 / bars.len() as f64 > 0.05 {
        rep.warnings.push(format!("{symbol}: {zero_vol} zero-volume sessions"));
    }
    rep
}

#[cfg(test)]
mod tests {
    use super::*;

    fn raw(d: u32, close: f64, adj: f64) -> RawBar {
        RawBar {
            date: NaiveDate::from_ymd_opt(2024, 1, 1).unwrap() + chrono::Duration::days(d as i64),
            open: close,
            high: close,
            low: close,
            close,
            adj_close: adj,
            volume: 1000.0,
        }
    }

    #[test]
    fn adjustment_scales_whole_candle() {
        let r = RawBar { open: 100.0, high: 110.0, low: 90.0, close: 100.0, adj_close: 50.0, ..raw(0, 100.0, 50.0) };
        let (bars, _) = clean_bars(&[r]);
        assert_eq!(bars[0].high, 55.0);
        assert_eq!(bars[0].low, 45.0);
        assert_eq!(bars[0].close, 50.0);
    }

    #[test]
    fn sorts_dedups_and_drops_invalid() {
        let rows = vec![raw(2, 10.0, 10.0), raw(1, 11.0, 11.0), raw(1, 11.0, 11.0), raw(3, -1.0, -1.0)];
        let (bars, warnings) = clean_bars(&rows);
        assert_eq!(bars.len(), 2);
        assert!(bars[0].date < bars[1].date);
        assert_eq!(warnings.len(), 2);
    }

    #[test]
    fn repairs_inconsistent_wicks() {
        let r = RawBar { open: 10.0, high: 9.0, low: 11.0, close: 10.5, adj_close: 10.5, ..raw(0, 10.5, 10.5) };
        let (bars, _) = clean_bars(&[r]);
        assert!(bars[0].high >= bars[0].close && bars[0].low <= bars[0].open);
    }

    #[test]
    fn keep_last_trims_from_the_front() {
        let (mut bars, _) = clean_bars(&(0..10).map(|i| raw(i, 10.0 + i as f64, 10.0 + i as f64)).collect::<Vec<_>>());
        keep_last(&mut bars, 4);
        assert_eq!(bars.len(), 4);
        assert_eq!(bars[3].close, 19.0);
    }

    #[test]
    fn stale_symbol_is_rejected() {
        let cfg = DataConfig { min_history_sessions: 5, ..DataConfig::default() };
        let rows: Vec<RawBar> = (0..10).map(|i| raw(i, 10.0, 10.0)).collect();
        let (bars, _) = clean_bars(&rows);
        let dates: Vec<NaiveDate> = bars.iter().map(|b| b.date).collect();
        let as_of = dates[dates.len() - 1] + chrono::Duration::days(1);
        let rep = validate("XYZ", &bars, &dates, as_of, &cfg);
        assert!(!rep.is_ok());
    }

    #[test]
    fn clean_complete_symbol_passes() {
        let cfg = DataConfig { min_history_sessions: 5, ..DataConfig::default() };
        let rows: Vec<RawBar> = (0..10).map(|i| raw(i, 10.0, 10.0)).collect();
        let (bars, _) = clean_bars(&rows);
        let dates: Vec<NaiveDate> = bars.iter().map(|b| b.date).collect();
        let as_of = dates[dates.len() - 1];
        assert!(validate("XYZ", &bars, &dates, as_of, &cfg).is_ok());
    }
}
