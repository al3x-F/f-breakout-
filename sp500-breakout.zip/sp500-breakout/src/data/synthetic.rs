//! Deterministic synthetic market for demos and tests (no API key, no network).
//!
//! Every fifth stock is a random walk with occasional volume spikes. Stocks
//! with `k % 5 == 1` (LONG) and `k % 5 == 2` (SHORT) are *planted*: ~150
//! sessions of a mean-reverting range with repeated, volume-backed tests of one
//! level, followed by a decisive close beyond it on heavy volume and a drift
//! that continues for `age` further sessions (`age = (k / 5) % 5`). The index is a
//! smooth uptrend, so planted shorts are countertrend.

use chrono::{Duration, NaiveDate};

use super::calendar::last_weekday_on_or_before;
use super::provider::DataProvider;
use crate::error::{Error, Result};
use crate::types::{Constituent, RawBar};

/// xorshift64* PRNG: tiny, deterministic, dependency-free.
struct Rng(u64);

impl Rng {
    fn new(seed: u64) -> Self {
        Rng(seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407) | 1)
    }

    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_F491_4F6C_DD1D)
    }

    /// Uniform in `[0, 1)`.
    fn next_f64(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 / (1u64 << 53) as f64
    }

    /// Standard normal (Box-Muller).
    fn normal(&mut self) -> f64 {
        let u1 = self.next_f64().max(1e-12);
        let u2 = self.next_f64();
        (-2.0 * u1.ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos()
    }
}

pub struct SyntheticProvider {
    seed: u64,
    n_symbols: usize,
    sessions: usize,
    end: NaiveDate,
}

fn symbol_name(k: usize) -> String {
    format!("SYN{:03}", k + 1)
}

fn parse_symbol(sym: &str) -> Option<usize> {
    sym.strip_prefix("SYN")?.parse::<usize>().ok()?.checked_sub(1)
}

impl SyntheticProvider {
    pub fn new(seed: u64, n_symbols: usize, sessions: usize, end: NaiveDate) -> Self {
        Self { seed, n_symbols, sessions, end }
    }

    /// 60 stocks and ~3 years of sessions ending at `end`.
    pub fn demo(end: NaiveDate) -> Self {
        Self::new(42, 60, 800, end)
    }

    /// Ascending weekday calendar of `sessions` dates ending at (or before) `end`.
    pub fn calendar(&self) -> Vec<NaiveDate> {
        let mut dates = Vec::with_capacity(self.sessions);
        let mut d = last_weekday_on_or_before(self.end);
        while dates.len() < self.sessions {
            dates.push(d);
            d = last_weekday_on_or_before(d - Duration::days(1));
        }
        dates.reverse();
        dates
    }

    fn gen_index(&self, dates: &[NaiveDate]) -> Vec<RawBar> {
        let mut rows = Vec::with_capacity(dates.len());
        let mut prev = 3000.0f64;
        for (i, &date) in dates.iter().enumerate() {
            let x = i as f64;
            // strictly increasing: drift 0.0006/day beats the sine's max slope 0.00025/day
            let close = 3000.0 * (0.0006 * x + 0.01 * (x / 40.0).sin()).exp();
            rows.push(RawBar {
                date,
                open: prev,
                high: close.max(prev) * 1.003,
                low: close.min(prev) * 0.997,
                close,
                adj_close: close,
                volume: 3.0e9,
            });
            prev = close;
        }
        rows
    }

    fn gen_stock(&self, k: usize, dates: &[NaiveDate]) -> Vec<RawBar> {
        let n = dates.len();
        let mut rng = Rng::new(self.seed ^ (k as u64 + 1).wrapping_mul(0x9E37_79B9_7F4A_7C15));
        let kind = k % 5;
        let planted = (kind == 1 || kind == 2) && n > 400;
        let up = kind == 1;
        let sign = if up { 1.0 } else { -1.0 };

        let base = 30.0 + 150.0 * rng.next_f64();
        let sigma = 0.012 + 0.010 * rng.next_f64();
        let vol_base = 1.0e6 * (0.5 + 4.0 * rng.next_f64());

        let age = (k / 5) % 5; // sessions between the breakout bar and the last bar
        let b_idx = n.saturating_sub(1 + age);
        let range_len = 150usize;
        let range_start = b_idx.saturating_sub(range_len);
        let period = 28.0;
        let amp = 0.07;
        let follow_vol = [2.2, 1.9, 1.7, 1.6];

        let mut rows = Vec::with_capacity(n);
        let mut prev_close = base;
        let mut mid = base;
        let mut extreme = if up { f64::NEG_INFINITY } else { f64::INFINITY };

        for i in 0..n {
            let mut open = prev_close;
            let mut close: f64;
            let mut volume: f64;
            let in_range = planted && i >= range_start && i < b_idx;

            if in_range {
                if i == range_start {
                    mid = prev_close;
                }
                let t = (i - range_start) as f64;
                let wave = (2.0 * std::f64::consts::PI * t / period).sin();
                // LONG: waves crest at mid*(1+amp) = resistance. SHORT: they trough at mid*(1-amp) = support.
                close = mid * (1.0 + sign * amp * wave) * (1.0 + 0.35 * sigma * rng.normal());
                // heavier volume whenever price is at the tested extreme (wave = +1)
                let prox = wave.max(0.0).powi(4);
                volume = vol_base * (0.8 + 0.4 * rng.next_f64()) * (1.0 + 0.9 * prox);
            } else if planted && i == b_idx {
                open = prev_close * (1.0 + 0.004 * sign);
                close = extreme * (1.0 + 0.024 * sign);
                volume = vol_base * 3.2;
            } else if planted && i > b_idx {
                let j = i - b_idx;
                close = prev_close * (1.0 + sign * 0.005 + 0.25 * sigma * rng.normal());
                volume = vol_base * follow_vol[(j - 1).min(3)];
            } else {
                close = prev_close * (1.0 + 0.0003 + sigma * rng.normal());
                volume = vol_base * (0.7 + 0.6 * rng.next_f64());
                if rng.next_f64() < 0.03 {
                    volume *= 2.0 + 2.0 * rng.next_f64();
                }
            }
            close = close.max(1.0);

            let wick_h = (0.1 + 0.3 * rng.next_f64()) * sigma;
            let wick_l = (0.1 + 0.3 * rng.next_f64()) * sigma;
            let high = open.max(close) * (1.0 + wick_h);
            let low = open.min(close) * (1.0 - wick_l);
            if in_range {
                extreme = if up { extreme.max(high) } else { extreme.min(low) };
            }

            rows.push(RawBar { date: dates[i], open, high, low, close, adj_close: close, volume });
            prev_close = close;
        }
        rows
    }
}

impl DataProvider for SyntheticProvider {
    fn name(&self) -> &str {
        "synthetic"
    }

    fn constituents(&self) -> Result<Vec<Constituent>> {
        Ok((0..self.n_symbols)
            .map(|k| Constituent {
                symbol: symbol_name(k),
                name: format!("Synthetic Company {}", k + 1),
                sector: Some("Synthetic".to_string()),
                date_added: None,
            })
            .collect())
    }

    fn history(&self, symbol: &str, from: NaiveDate, to: NaiveDate) -> Result<Vec<RawBar>> {
        let dates = self.calendar();
        let mut rows = if symbol.starts_with('^') || symbol == "SPY" {
            self.gen_index(&dates)
        } else {
            match parse_symbol(symbol) {
                Some(k) if k < self.n_symbols => self.gen_stock(k, &dates),
                _ => return Err(Error::Provider(format!("unknown synthetic symbol {symbol}"))),
            }
        };
        rows.retain(|r| r.date >= from && r.date <= to);
        Ok(rows)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::Datelike;

    fn d(y: i32, m: u32, day: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, day).unwrap()
    }

    #[test]
    fn calendar_is_ascending_weekdays_ending_at_end() {
        let p = SyntheticProvider::new(1, 5, 50, d(2026, 11, 14)); // a Saturday
        let cal = p.calendar();
        assert_eq!(cal.len(), 50);
        assert_eq!(cal[49], d(2026, 11, 13));
        assert!(cal.windows(2).all(|w| w[0] < w[1]));
        assert!(cal.iter().all(|x| x.weekday().number_from_monday() <= 5));
    }

    #[test]
    fn data_is_deterministic_and_well_formed() {
        let p = SyntheticProvider::new(7, 10, 700, d(2026, 11, 13));
        let a = p.history("SYN002", d(2000, 1, 1), d(2100, 1, 1)).unwrap();
        let b = p.history("SYN002", d(2000, 1, 1), d(2100, 1, 1)).unwrap();
        assert_eq!(a, b);
        assert_eq!(a.len(), 700);
        for bar in &a {
            assert!(bar.low > 0.0 && bar.low <= bar.open && bar.low <= bar.close);
            assert!(bar.high >= bar.open && bar.high >= bar.close);
            assert!(bar.volume > 0.0);
        }
    }

    #[test]
    fn history_filters_the_date_range_and_rejects_unknown_symbols() {
        let p = SyntheticProvider::new(7, 10, 300, d(2026, 11, 13));
        let rows = p.history("SYN001", d(2026, 11, 2), d(2026, 11, 6)).unwrap();
        assert_eq!(rows.len(), 5);
        assert!(p.history("NOPE", d(2026, 1, 1), d(2026, 11, 13)).is_err());
        assert!(p.history("SYN999", d(2026, 1, 1), d(2026, 11, 13)).is_err());
    }

    #[test]
    fn index_trends_upward() {
        let p = SyntheticProvider::new(1, 3, 300, d(2026, 11, 13));
        let idx = p.history("^GSPC", d(2000, 1, 1), d(2100, 1, 1)).unwrap();
        assert!(idx.windows(2).all(|w| w[1].close > w[0].close));
    }

    #[test]
    fn planted_long_ends_above_its_range_on_heavy_volume() {
        // k = 1 -> planted LONG with age 0: the last bar is the breakout bar
        let p = SyntheticProvider::new(42, 60, 800, d(2026, 11, 13));
        let rows = p.history("SYN002", d(2000, 1, 1), d(2100, 1, 1)).unwrap();
        let n = rows.len();
        let range_high = rows[n - 151..n - 1].iter().map(|r| r.high).fold(f64::MIN, f64::max);
        assert!(rows[n - 1].close > range_high);
        let avg_vol: f64 = rows[n - 21..n - 1].iter().map(|r| r.volume).sum::<f64>() / 20.0;
        assert!(rows[n - 1].volume > 2.0 * avg_vol);
    }
}
