//! Data-provider abstraction.

use std::collections::HashSet;

use chrono::NaiveDate;

use crate::error::Result;
use crate::types::{Constituent, MembershipChange, RawBar};

/// A source of S&P 500 membership and daily OHLCV history.
///
/// Implementations must be thread-safe: the scanner downloads many symbols in parallel.
pub trait DataProvider: Send + Sync {
    fn name(&self) -> &str;

    /// Current S&P 500 constituents.
    fn constituents(&self) -> Result<Vec<Constituent>>;

    /// Historical index additions/removals (used to reduce survivorship bias in
    /// backtests). Providers without this data return an empty list.
    fn membership_changes(&self) -> Result<Vec<MembershipChange>> {
        Ok(Vec::new())
    }

    /// Daily bars for `symbol` between `from` and `to` inclusive, ascending.
    fn history(&self, symbol: &str, from: NaiveDate, to: NaiveDate) -> Result<Vec<RawBar>>;
}

/// Point-in-time index membership reconstructed by walking the change log
/// backwards from today's constituents.
#[derive(Debug, Clone)]
pub struct MembershipHistory {
    current: HashSet<String>,
    /// Sorted newest first.
    changes: Vec<MembershipChange>,
}

impl MembershipHistory {
    pub fn new(current: &[Constituent], mut changes: Vec<MembershipChange>) -> Self {
        changes.sort_by(|a, b| b.date.cmp(&a.date));
        Self { current: current.iter().map(|c| c.symbol.clone()).collect(), changes }
    }

    /// Members as of the close of `date`: undo every change that happened after it.
    pub fn members_on(&self, date: NaiveDate) -> HashSet<String> {
        let mut set = self.current.clone();
        for ch in &self.changes {
            if ch.date <= date {
                break; // sorted newest-first: everything further is older
            }
            if let Some(a) = &ch.added {
                set.remove(a);
            }
            if let Some(r) = &ch.removed {
                set.insert(r.clone());
            }
        }
        set
    }

    /// Every symbol that was a member at any time since `since` (current members
    /// plus tickers removed after that date).
    pub fn all_symbols_since(&self, since: NaiveDate) -> HashSet<String> {
        let mut set = self.current.clone();
        for ch in &self.changes {
            if ch.date < since {
                break;
            }
            if let Some(r) = &ch.removed {
                set.insert(r.clone());
            }
            if let Some(a) = &ch.added {
                set.insert(a.clone());
            }
        }
        set
    }

    pub fn is_empty(&self) -> bool {
        self.changes.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn d(y: i32, m: u32, day: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, day).unwrap()
    }

    fn c(sym: &str) -> Constituent {
        Constituent { symbol: sym.to_string(), name: sym.to_string(), sector: None, date_added: None }
    }

    #[test]
    fn membership_is_reconstructed_backwards() {
        // today: AAA, NEW.  NEW replaced OLD on 2026-06-01.
        let hist = MembershipHistory::new(
            &[c("AAA"), c("NEW")],
            vec![MembershipChange { date: d(2026, 6, 1), added: Some("NEW".into()), removed: Some("OLD".into()) }],
        );
        let before = hist.members_on(d(2026, 5, 31));
        assert!(before.contains("OLD") && !before.contains("NEW"));
        let after = hist.members_on(d(2026, 6, 1));
        assert!(after.contains("NEW") && !after.contains("OLD"));
        assert!(hist.all_symbols_since(d(2026, 1, 1)).contains("OLD"));
    }
}
