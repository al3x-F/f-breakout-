//! On-disk cache wrapper for any [`DataProvider`].
//!
//! Each symbol is stored as `<cache_dir>/<SYMBOL>.csv` with a first-line
//! comment recording the date range that was requested and how far the data was
//! known to be complete (`fetched_from` .. `fetched_to`). A cached file is reused
//! only if it covers the requested start date and already includes the latest
//! *completed* session; otherwise the range is re-downloaded. Re-downloading
//! (rather than appending) also guarantees that dividend/split restatements of
//! history are always picked up.
//!
//! In practice the cache makes repeated runs on the same day, charting and
//! backtests cheap; a fresh trading day always triggers a refresh.

use std::path::PathBuf;

use chrono::{NaiveDate, Utc};

use super::calendar::{last_completed_session_estimate, last_weekday_on_or_before};
use super::csv_source::{read_bars_csv, safe_name, write_bars_csv};
use super::provider::DataProvider;
use crate::config::DataConfig;
use crate::error::Result;
use crate::types::{Constituent, MembershipChange, RawBar};

pub struct CachedProvider {
    inner: Box<dyn DataProvider>,
    dir: PathBuf,
    buffer_minutes: i64,
}

impl CachedProvider {
    pub fn new(inner: Box<dyn DataProvider>, cfg: &DataConfig) -> Self {
        Self { inner, dir: cfg.cache_dir.clone(), buffer_minutes: cfg.market_close_buffer_minutes }
    }
}

impl DataProvider for CachedProvider {
    fn name(&self) -> &str {
        self.inner.name()
    }

    fn constituents(&self) -> Result<Vec<Constituent>> {
        self.inner.constituents()
    }

    fn membership_changes(&self) -> Result<Vec<MembershipChange>> {
        self.inner.membership_changes()
    }

    fn history(&self, symbol: &str, from: NaiveDate, to: NaiveDate) -> Result<Vec<RawBar>> {
        let path = self.dir.join(format!("{}.csv", safe_name(symbol)));

        // The latest session that can possibly have a final bar right now.
        let latest = last_completed_session_estimate(Utc::now(), self.buffer_minutes);
        let needed_to = last_weekday_on_or_before(to.min(latest));

        if let Ok((mut bars, Some((cached_from, cached_to)))) = read_bars_csv(&path) {
            if cached_from <= from && cached_to >= needed_to && !bars.is_empty() {
                bars.retain(|b| b.date >= from && b.date <= to);
                return Ok(bars);
            }
        }

        let bars = self.inner.history(symbol, from, to)?;
        if !bars.is_empty() {
            if let Err(e) = write_bars_csv(&path, &bars, Some((from, needed_to))) {
                log::warn!("could not write cache for {symbol}: {e}");
            }
        }
        Ok(bars)
    }
}
