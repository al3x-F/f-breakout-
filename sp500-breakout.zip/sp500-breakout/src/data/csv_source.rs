//! Local-CSV data provider (no API key required) and shared CSV helpers.
//!
//! Layout expected by [`CsvProvider`]:
//!
//! * `constituents_file` - header `symbol,name,sector` (name and sector optional).
//! * `csv_dir/<SYMBOL>.csv` - header `date,open,high,low,close,adj_close,volume`
//!   (`adj_close` optional; `^` in symbols is written as `_`, e.g. `_GSPC.csv`).

use std::fs::File;
use std::io::{BufRead, BufReader, Write};
use std::path::{Path, PathBuf};

use chrono::NaiveDate;
use serde::Deserialize;

use super::provider::DataProvider;
use crate::config::DataConfig;
use crate::error::{Error, Result};
use crate::types::{Constituent, RawBar};

/// File-system-safe version of a ticker (`^GSPC` -> `_GSPC`, `BRK.B` stays).
pub fn safe_name(symbol: &str) -> String {
    symbol
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == '_' { c } else { '_' })
        .collect()
}

pub fn parse_date(s: &str) -> Result<NaiveDate> {
    Ok(NaiveDate::parse_from_str(s.trim(), "%Y-%m-%d")?)
}

#[derive(Debug, Deserialize)]
struct CsvRow {
    date: String,
    open: f64,
    high: f64,
    low: f64,
    close: f64,
    #[serde(default)]
    adj_close: Option<f64>,
    #[serde(default)]
    volume: Option<f64>,
}

/// Read a bar CSV. Lines starting with `#` are comments; a comment of the form
/// `# fetched_from=YYYY-MM-DD fetched_to=YYYY-MM-DD` is returned as metadata
/// (used by the cache).
pub fn read_bars_csv(path: &Path) -> Result<(Vec<RawBar>, Option<(NaiveDate, NaiveDate)>)> {
    let file = File::open(path)?;
    let mut reader = BufReader::new(file);
    let mut first_line = String::new();
    reader.read_line(&mut first_line)?;
    let meta = parse_meta(&first_line);

    // Re-open so the csv reader sees the whole file (comments are skipped by the reader).
    let file = File::open(path)?;
    let mut rdr = csv::ReaderBuilder::new().comment(Some(b'#')).trim(csv::Trim::All).from_reader(file);
    let mut bars = Vec::new();
    for rec in rdr.deserialize::<CsvRow>() {
        let row = rec?;
        let date = parse_date(&row.date)?;
        bars.push(RawBar {
            date,
            open: row.open,
            high: row.high,
            low: row.low,
            close: row.close,
            adj_close: row.adj_close.unwrap_or(row.close),
            volume: row.volume.unwrap_or(0.0),
        });
    }
    Ok((bars, meta))
}

fn parse_meta(line: &str) -> Option<(NaiveDate, NaiveDate)> {
    let line = line.trim();
    if !line.starts_with('#') {
        return None;
    }
    let mut from = None;
    let mut to = None;
    for tok in line.trim_start_matches('#').split_whitespace() {
        if let Some(v) = tok.strip_prefix("fetched_from=") {
            from = parse_date(v).ok();
        } else if let Some(v) = tok.strip_prefix("fetched_to=") {
            to = parse_date(v).ok();
        }
    }
    match (from, to) {
        (Some(f), Some(t)) => Some((f, t)),
        _ => None,
    }
}

/// Write bars (optionally preceded by the cache metadata comment). The write is
/// atomic: data goes to a temporary file that is then renamed.
pub fn write_bars_csv(path: &Path, bars: &[RawBar], meta: Option<(NaiveDate, NaiveDate)>) -> Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let tmp = path.with_extension("csv.tmp");
    {
        let mut f = File::create(&tmp)?;
        if let Some((from, to)) = meta {
            writeln!(f, "# fetched_from={from} fetched_to={to}")?;
        }
        let mut w = csv::Writer::from_writer(f);
        w.write_record(["date", "open", "high", "low", "close", "adj_close", "volume"])?;
        for b in bars {
            w.write_record([
                b.date.to_string(),
                b.open.to_string(),
                b.high.to_string(),
                b.low.to_string(),
                b.close.to_string(),
                b.adj_close.to_string(),
                b.volume.to_string(),
            ])?;
        }
        w.flush()?;
    }
    std::fs::rename(&tmp, path)?;
    Ok(())
}

#[derive(Debug, Deserialize)]
struct ConstituentRow {
    symbol: String,
    #[serde(default)]
    name: Option<String>,
    #[serde(default)]
    sector: Option<String>,
}

pub struct CsvProvider {
    dir: PathBuf,
    constituents_file: PathBuf,
}

impl CsvProvider {
    pub fn new(cfg: &DataConfig) -> Self {
        Self { dir: cfg.csv_dir.clone(), constituents_file: cfg.constituents_file.clone() }
    }
}

impl DataProvider for CsvProvider {
    fn name(&self) -> &str {
        "csv"
    }

    fn constituents(&self) -> Result<Vec<Constituent>> {
        let file = File::open(&self.constituents_file).map_err(|e| {
            Error::Provider(format!("cannot open {}: {e}", self.constituents_file.display()))
        })?;
        let mut rdr = csv::ReaderBuilder::new().trim(csv::Trim::All).from_reader(file);
        let mut out = Vec::new();
        for rec in rdr.deserialize::<ConstituentRow>() {
            let row = rec?;
            let name = row.name.filter(|n| !n.is_empty()).unwrap_or_else(|| row.symbol.clone());
            out.push(Constituent { symbol: row.symbol, name, sector: row.sector, date_added: None });
        }
        Ok(out)
    }

    fn history(&self, symbol: &str, from: NaiveDate, to: NaiveDate) -> Result<Vec<RawBar>> {
        let path = self.dir.join(format!("{}.csv", safe_name(symbol)));
        let (mut bars, _) = read_bars_csv(&path)
            .map_err(|e| Error::Provider(format!("{}: {e}", path.display())))?;
        bars.retain(|b| b.date >= from && b.date <= to);
        bars.sort_by_key(|b| b.date);
        Ok(bars)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn safe_names() {
        assert_eq!(safe_name("^GSPC"), "_GSPC");
        assert_eq!(safe_name("BRK.B"), "BRK.B");
    }

    #[test]
    fn roundtrip_with_metadata() {
        let dir = std::env::temp_dir().join(format!("sp500_csv_test_{}", std::process::id()));
        let path = dir.join("TEST.csv");
        let d = |n: u32| NaiveDate::from_ymd_opt(2024, 3, n).unwrap();
        let bars = vec![
            RawBar { date: d(1), open: 1.0, high: 2.0, low: 0.5, close: 1.5, adj_close: 1.4, volume: 100.0 },
            RawBar { date: d(4), open: 1.5, high: 2.5, low: 1.0, close: 2.0, adj_close: 1.9, volume: 200.0 },
        ];
        write_bars_csv(&path, &bars, Some((d(1), d(4)))).unwrap();
        let (back, meta) = read_bars_csv(&path).unwrap();
        assert_eq!(back, bars);
        assert_eq!(meta, Some((d(1), d(4))));
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn parse_meta_rejects_garbage() {
        assert!(parse_meta("date,open").is_none());
        assert!(parse_meta("# something else").is_none());
    }
}
