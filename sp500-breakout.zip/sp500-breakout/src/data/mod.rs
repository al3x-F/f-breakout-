//! Data acquisition and integrity (spec section 2).

pub mod cache;
pub mod calendar;
pub mod csv_source;
pub mod fmp;
pub mod integrity;
pub mod provider;
pub mod synthetic;

pub use provider::{DataProvider, MembershipHistory};

use chrono::{NaiveDate, Utc};

use crate::config::{Config, DataConfig, ProviderKind};
use crate::error::{Error, Result};
use crate::types::RawBar;

/// Download the S&P 500 index series used as the trading calendar and market-trend
/// source. If the configured symbol returns nothing or fails, `index_fallback_symbol`
/// (default `SPY`) is tried. Returns the symbol that actually supplied the data.
pub fn fetch_index(
    provider: &dyn DataProvider,
    cfg: &DataConfig,
    from: NaiveDate,
    to: NaiveDate,
) -> Result<(String, Vec<RawBar>)> {
    let first_error: Option<Error> = match provider.history(&cfg.index_symbol, from, to) {
        Ok(rows) if !rows.is_empty() => return Ok((cfg.index_symbol.clone(), rows)),
        Ok(_) => {
            log::warn!("no data returned for index {}", cfg.index_symbol);
            None
        }
        Err(e) => {
            log::warn!("index {} failed: {e}", cfg.index_symbol);
            Some(e)
        }
    };

    let fallback = cfg.index_fallback_symbol.trim();
    if !fallback.is_empty() && fallback != cfg.index_symbol {
        log::warn!("using {fallback} for the market-trend filter instead");
        let rows = provider.history(fallback, from, to)?;
        if !rows.is_empty() {
            return Ok((fallback.to_string(), rows));
        }
    }
    Err(first_error.unwrap_or_else(|| Error::Data(format!("no data returned for index {}", cfg.index_symbol))))
}

/// Build the provider selected in `cfg.data.provider`.
///
/// * `fmp`       - Financial Modeling Prep behind the on-disk cache (needs the API key env var).
/// * `csv`       - local files, no key.
/// * `synthetic` - generated demo market, no key.
pub fn build_provider(cfg: &Config) -> Result<Box<dyn DataProvider>> {
    match cfg.data.provider {
        ProviderKind::Fmp => {
            let inner = fmp::FmpProvider::from_config(&cfg.data)?;
            Ok(Box::new(cache::CachedProvider::new(Box::new(inner), &cfg.data)))
        }
        ProviderKind::Csv => Ok(Box::new(csv_source::CsvProvider::new(&cfg.data))),
        ProviderKind::Synthetic => {
            let end = calendar::last_completed_session_estimate(Utc::now(), cfg.data.market_close_buffer_minutes);
            Ok(Box::new(synthetic::SyntheticProvider::demo(end)))
        }
    }
}
