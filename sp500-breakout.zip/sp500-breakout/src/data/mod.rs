//! Data acquisition and integrity (spec section 2).

pub mod cache;
pub mod calendar;
pub mod csv_source;
pub mod fmp;
pub mod integrity;
pub mod provider;
pub mod synthetic;

pub use provider::{DataProvider, MembershipHistory};

use chrono::Utc;

use crate::config::{Config, ProviderKind};
use crate::error::Result;

/// Build the provider selected in `cfg.data.provider`.
///
/// * `fmp`       - Financial Modeling Prep behind the on-disk cache (needs the API key env var).
/// * `csv`       - local files, no key.
/// * `synthetic` - generated demo market, no key.
pub fn build_provider(cfg: &Config) -> Result<Box<dyn DataProvider>> {
    match cfg.data.provider {
        ProviderKind::Fmp => {
            let inner = fmp::FmpProvider::from_config(&cfg.data)?;
            Ok(Box::new(cache::CachedProvider::new(Box::new(inner), &cfg.data)))
        }
        ProviderKind::Csv => Ok(Box::new(csv_source::CsvProvider::new(&cfg.data))),
        ProviderKind::Synthetic => {
            let end = calendar::last_completed_session_estimate(Utc::now(), cfg.data.market_close_buffer_minutes);
            Ok(Box::new(synthetic::SyntheticProvider::demo(end)))
        }
    }
}
