//! Runs the bundled Python scraper (`tools/scrape_companies.py`) from inside the program.
//!
//! * The script is **embedded in the executable** (`include_str!`), so the single `.exe` is
//!   self-contained. It is written to `./tools/scrape_companies.py` next to the program
//!   whenever it is missing or out of date, then run with the Python found on the PC.
//! * Python 3.8+ must be installed (python.org; tick "Add python.exe to PATH"). The program
//!   looks for `python`, then `py -3`, then `python3`.
//! * From the browser page the script runs as a background job whose progress lines are
//!   streamed into the page; from the command line (`sp500-breakout scrape`) it runs in the
//!   foreground with its output on your terminal.
//! * The Stooq API key (if you give one) is passed to the script as the `STOOQ_API_KEY`
//!   environment variable, never as a command-line argument, and is not logged.

use std::io::{BufRead, BufReader, Read};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::Duration;

use serde::Serialize;

use crate::config::Config;
use crate::error::{Error, Result};

/// The scraper, embedded so the executable needs no companion files.
pub const SCRAPER_PY: &str = include_str!("../tools/scrape_companies.py");

/// Folder (relative to the working directory) the script is written to.
pub fn tools_dir() -> PathBuf {
    PathBuf::from("tools")
}

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|p| p.into_inner())
}

/// Keep child processes from flashing a console window on Windows.
fn hide_window(cmd: &mut Command) {
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    }
    #[cfg(not(windows))]
    {
        let _ = cmd;
    }
}

// ---------------------------------------------------------------------------
// Finding Python and installing the script
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
pub struct Python {
    pub program: String,
    /// Extra leading arguments (`-3` for the Windows `py` launcher).
    pub prefix_args: Vec<String>,
    /// e.g. `Python 3.12.3`.
    pub version: String,
}

/// Minor version from text like `Python 3.12.3`; `None` if it is not Python 3.
fn python3_minor(text: &str) -> Option<u32> {
    let rest = text.trim_start().strip_prefix("Python 3.")?;
    let digits: String = rest.chars().take_while(|c| c.is_ascii_digit()).collect();
    digits.parse().ok()
}

/// Locate a usable Python (3.8 or newer).
pub fn find_python() -> Option<Python> {
    let candidates: [(&str, &[&str]); 3] = [("python", &[]), ("py", &["-3"]), ("python3", &[])];
    for (program, prefix) in candidates {
        let mut cmd = Command::new(program);
        cmd.args(prefix).arg("--version").stdin(Stdio::null());
        hide_window(&mut cmd);
        if let Ok(out) = cmd.output() {
            // Older Pythons print the version on stderr.
            let text = format!("{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr));
            if out.status.success() && python3_minor(&text).map_or(false, |m| m >= 8) {
                return Some(Python {
                    program: program.to_string(),
                    prefix_args: prefix.iter().map(|s| s.to_string()).collect(),
                    version: text.trim().to_string(),
                });
            }
        }
    }
    None
}

pub const PYTHON_MISSING_HELP: &str = "Python 3.8 or newer was not found on this computer. Install it from \
    https://www.python.org/downloads/ (on Windows, tick \"Add python.exe to PATH\" in the installer), \
    then try again.";

/// Write the embedded script into `dir` (only if it differs) and return its path.
pub fn install_script(dir: &Path) -> Result<PathBuf> {
    std::fs::create_dir_all(dir)?;
    let path = dir.join("scrape_companies.py");
    let current = std::fs::read_to_string(&path).ok();
    if current.as_deref() != Some(SCRAPER_PY) {
        std::fs::write(&path, SCRAPER_PY)?;
    }
    Ok(path)
}

/// Command-line arguments for the script. `mode` is `prices` or `profiles`.
///
/// The output locations come from the configuration, so what the script writes is exactly
/// what the "Local CSV files" data source reads.
pub fn build_args(cfg: &Config, mode: &str, count: usize, years: f64, tickers: &str) -> Vec<String> {
    let mut a: Vec<String> = Vec::new();
    let contact = cfg.scrape.contact.trim();
    if !contact.is_empty() {
        a.push("--contact".to_string());
        a.push(contact.to_string());
    }
    a.push(mode.to_string());
    a.push("--count".to_string());
    a.push(count.to_string());
    if !tickers.trim().is_empty() {
        a.push("--tickers".to_string());
        a.push(tickers.trim().to_string());
    }
    if mode == "prices" {
        a.push("--years".to_string());
        a.push(format!("{years}"));
        a.push("--out-dir".to_string());
        a.push(cfg.data.csv_dir.to_string_lossy().into_owned());
        a.push("--constituents".to_string());
        a.push(cfg.data.constituents_file.to_string_lossy().into_owned());
        a.push("--delay".to_string());
        a.push(format!("{}", cfg.scrape.delay_seconds));
    } else {
        a.push("--out".to_string());
        a.push(cfg.output.dir.join("companies.csv").to_string_lossy().into_owned());
    }
    a
}

/// Run the script in the foreground with its output on this terminal. Returns its exit code.
pub fn run_blocking(python: &Python, script: &Path, args: &[String]) -> Result<i32> {
    let status = Command::new(&python.program)
        .args(&python.prefix_args)
        .arg(script)
        .args(args)
        .env("PYTHONIOENCODING", "utf-8")
        .status()
        .map_err(|e| Error::Data(format!("could not start Python: {e}")))?;
    Ok(status.code().unwrap_or(-1))
}

// ---------------------------------------------------------------------------
// Background job (used by the web page)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Default, Serialize)]
pub struct JobSnapshot {
    pub running: bool,
    pub finished: bool,
    /// Finished with exit code 0 (complete) or 4 (stopped early by the data site's quota, partial data kept).
    pub success: bool,
    pub exit_code: Option<i32>,
    pub done: usize,
    pub total: usize,
    pub message: String,
    /// The most recent output lines.
    pub lines: Vec<String>,
}

const MAX_KEPT_LINES: usize = 400;
const MAX_SENT_LINES: usize = 80;

/// One scraper process at a time, observed from other threads.
pub struct ScrapeJob {
    snap: Arc<Mutex<JobSnapshot>>,
    child: Arc<Mutex<Option<Child>>>,
}

impl Default for ScrapeJob {
    fn default() -> Self {
        Self::new()
    }
}

/// Fold one line of script output into the snapshot. `PROGRESS done total` lines drive the
/// progress bar; everything else goes into the visible log.
fn apply_line(snap: &Mutex<JobSnapshot>, line: &str) {
    let mut s = lock(snap);
    if let Some(rest) = line.strip_prefix("PROGRESS ") {
        let mut it = rest.split_whitespace();
        let done = it.next().and_then(|x| x.parse::<usize>().ok());
        let total = it.next().and_then(|x| x.parse::<usize>().ok());
        if let (Some(d), Some(t)) = (done, total) {
            s.done = d;
            s.total = t;
        }
        return;
    }
    s.lines.push(line.to_string());
    if s.lines.len() > MAX_KEPT_LINES {
        let cut = s.lines.len() - MAX_KEPT_LINES;
        s.lines.drain(..cut);
    }
}

fn spawn_reader<R: Read + Send + 'static>(reader: R, snap: Arc<Mutex<JobSnapshot>>) -> thread::JoinHandle<()> {
    thread::spawn(move || {
        for line in BufReader::new(reader).lines() {
            match line {
                Ok(l) => apply_line(&snap, &l),
                Err(_) => break,
            }
        }
    })
}

fn finish_message(code: Option<i32>, cancelled: bool) -> String {
    if cancelled {
        return "Cancelled. Anything already downloaded was kept.".to_string();
    }
    match code {
        Some(0) => "Finished.".to_string(),
        Some(4) => "Stopped early because the data site's daily request limit was reached. What was downloaded is \
                    kept; run it again later to continue."
            .to_string(),
        Some(3) => "The data site needs an API key (or rejected the one given). Get a free key from stooq.com and \
                    paste it into the box."
            .to_string(),
        Some(c) => format!("The script failed (exit code {c}). See the log for details."),
        None => "The script ended unexpectedly.".to_string(),
    }
}

impl ScrapeJob {
    pub fn new() -> Self {
        Self { snap: Arc::new(Mutex::new(JobSnapshot::default())), child: Arc::new(Mutex::new(None)) }
    }

    pub fn snapshot(&self) -> JobSnapshot {
        let mut s = lock(&self.snap).clone();
        if s.lines.len() > MAX_SENT_LINES {
            let cut = s.lines.len() - MAX_SENT_LINES;
            s.lines.drain(..cut);
        }
        s
    }

    /// Start the script in the background. Fails if one is already running.
    pub fn start(&self, python: &Python, script: &Path, args: &[String], stooq_key: Option<&str>) -> Result<()> {
        if lock(&self.snap).running {
            return Err(Error::Data("a download is already running".to_string()));
        }
        let mut cmd = Command::new(&python.program);
        cmd.args(&python.prefix_args)
            .arg(script)
            .args(args)
            .env("PYTHONUNBUFFERED", "1")
            .env("PYTHONIOENCODING", "utf-8")
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        if let Some(key) = stooq_key.map(|k| k.trim()).filter(|k| !k.is_empty()) {
            cmd.env("STOOQ_API_KEY", key);
        }
        hide_window(&mut cmd);
        let mut child = cmd.spawn().map_err(|e| Error::Data(format!("could not start Python: {e}")))?;
        let stdout = child.stdout.take();
        let stderr = child.stderr.take();

        *lock(&self.snap) = JobSnapshot { running: true, message: "Starting\u{2026}".to_string(), ..Default::default() };
        *lock(&self.child) = Some(child);

        let mut readers = Vec::new();
        if let Some(o) = stdout {
            readers.push(spawn_reader(o, Arc::clone(&self.snap)));
        }
        if let Some(e) = stderr {
            readers.push(spawn_reader(e, Arc::clone(&self.snap)));
        }

        let snap = Arc::clone(&self.snap);
        let child = Arc::clone(&self.child);
        thread::spawn(move || {
            // Poll rather than block in wait(), so cancel() can take the lock and kill the process.
            let status = loop {
                let polled = {
                    let mut g = lock(&child);
                    match g.as_mut() {
                        Some(c) => c.try_wait(),
                        None => break None,
                    }
                };
                match polled {
                    Ok(Some(st)) => break Some(st),
                    Ok(None) => thread::sleep(Duration::from_millis(250)),
                    Err(_) => break None,
                }
            };
            for h in readers {
                let _ = h.join();
            }
            // Release the child before touching the snapshot (cancel() locks them in the other order).
            *lock(&child) = None;
            let code = status.and_then(|s| s.code());
            let mut s = lock(&snap);
            let cancelled = s.message == "Cancelling\u{2026}";
            s.running = false;
            s.finished = true;
            s.exit_code = code;
            s.success = !cancelled && matches!(code, Some(0) | Some(4));
            s.message = finish_message(code, cancelled);
        });
        Ok(())
    }

    /// Stop the running script. Returns whether there was one to stop.
    pub fn cancel(&self) -> bool {
        let killed = {
            let mut g = lock(&self.child);
            match g.as_mut() {
                Some(c) => {
                    let _ = c.kill();
                    true
                }
                None => false,
            }
        };
        if killed {
            lock(&self.snap).message = "Cancelling\u{2026}".to_string();
        }
        killed
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn python_version_parsing() {
        assert_eq!(python3_minor("Python 3.12.3\n"), Some(12));
        assert_eq!(python3_minor("  Python 3.8.10"), Some(8));
        assert_eq!(python3_minor("Python 2.7.18"), None);
        assert_eq!(python3_minor("Python was not found; run without arguments to install"), None);
    }

    #[test]
    fn the_embedded_script_is_the_real_one() {
        assert!(SCRAPER_PY.contains("def run_prices"));
        assert!(SCRAPER_PY.contains("STOOQ_API_KEY"));
    }

    #[test]
    fn install_script_writes_once_and_repairs_edits() {
        let dir = std::env::temp_dir().join(format!("sp500_scrape_test_{}", std::process::id()));
        let path = install_script(&dir).unwrap();
        assert_eq!(std::fs::read_to_string(&path).unwrap(), SCRAPER_PY);
        std::fs::write(&path, "# tampered").unwrap();
        let again = install_script(&dir).unwrap();
        assert_eq!(std::fs::read_to_string(&again).unwrap(), SCRAPER_PY);
        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn prices_arguments_point_at_the_folders_the_csv_source_reads() {
        let mut cfg = Config::default();
        cfg.scrape.contact = "me@example.com".to_string();
        let a = build_args(&cfg, "prices", 120, 2.0, " AAPL,MSFT ");
        let joined = a.join(" ");
        assert!(joined.starts_with("--contact me@example.com prices --count 120"));
        assert!(joined.contains("--tickers AAPL,MSFT"));
        assert!(joined.contains("--years 2 "));
        assert!(a.windows(2).any(|w| w[0] == "--out-dir" && w[1] == cfg.data.csv_dir.to_string_lossy()));
        assert!(a.windows(2).any(|w| w[0] == "--constituents" && w[1] == cfg.data.constituents_file.to_string_lossy()));
        // no key ever goes on the command line
        assert!(!joined.to_lowercase().contains("key"));

        let p = build_args(&Config::default(), "profiles", 10, 2.0, "");
        assert_eq!(p[0], "profiles");
        assert!(p.iter().any(|x| x.ends_with("companies.csv")));
        assert!(!p.contains(&"--tickers".to_string()));
    }

    #[test]
    fn output_lines_update_progress_and_the_log() {
        let snap = Mutex::new(JobSnapshot::default());
        apply_line(&snap, "PROGRESS 3 51");
        apply_line(&snap, "PROGRESS x y");
        apply_line(&snap, "[3/50] AAPL: 503 days saved");
        let s = lock(&snap).clone();
        assert_eq!((s.done, s.total), (3, 51)); // the malformed PROGRESS line changed nothing
        assert_eq!(s.lines, vec!["[3/50] AAPL: 503 days saved".to_string()]); // PROGRESS lines are not logged

        for i in 0..(MAX_KEPT_LINES + 25) {
            apply_line(&snap, &format!("line {i}"));
        }
        let kept = lock(&snap).lines.clone();
        assert_eq!(kept.len(), MAX_KEPT_LINES);
        assert_eq!(kept.last().cloned(), Some(format!("line {}", MAX_KEPT_LINES + 24)));
    }

    #[test]
    fn finish_messages() {
        assert_eq!(finish_message(Some(0), false), "Finished.");
        assert!(finish_message(Some(4), false).contains("daily request limit"));
        assert!(finish_message(Some(3), false).contains("API key"));
        assert!(finish_message(Some(1), false).contains("exit code 1"));
        assert!(finish_message(Some(0), true).starts_with("Cancelled"));
    }

    /// These need a real Python; they are skipped (pass trivially) on machines without one.
    #[test]
    fn the_embedded_script_runs_and_a_failing_job_is_reported() {
        let Some(py) = find_python() else { return };
        let dir = std::env::temp_dir().join(format!("sp500_scrape_run_{}", std::process::id()));
        let script = install_script(&dir).unwrap();

        // --help proves the script is valid Python for this interpreter
        let out = Command::new(&py.program)
            .args(&py.prefix_args)
            .arg(&script)
            .arg("prices")
            .arg("--help")
            .output()
            .unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        assert!(String::from_utf8_lossy(&out.stdout).contains("--stooq-key"));

        // a job that fails fast offline (usage error, exit code 2), observed through the job API
        let job = ScrapeJob::new();
        let args = vec!["prices".to_string(), "--count".to_string(), "0".to_string()];
        job.start(&py, &script, &args, None).unwrap();
        let mut snap = job.snapshot();
        for _ in 0..100 {
            if snap.finished {
                break;
            }
            thread::sleep(Duration::from_millis(100));
            snap = job.snapshot();
        }
        assert!(snap.finished, "job did not finish: {snap:?}");
        assert!(!snap.running && !snap.success);
        assert_eq!(snap.exit_code, Some(2));
        assert!(snap.message.contains("exit code 2"));
        assert!(!job.cancel()); // nothing left to cancel
        std::fs::remove_dir_all(&dir).ok();
    }
}
