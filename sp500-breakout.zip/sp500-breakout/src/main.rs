//! Command-line interface.
//!
//! ```text
//! sp500-breakout scan      [--as-of DATE] [--top N] [--out-dir DIR] [--no-charts] [--no-registry]
//! sp500-breakout backtest  [--start DATE] [--end DATE] [--out-dir DIR]
//! sp500-breakout chart TICKER [--as-of DATE] [--out FILE]
//! sp500-breakout universe
//! sp500-breakout scrape    [--count N] [--years Y] [--tickers A,B] [--profiles]
//! sp500-breakout serve     [--port N] [--no-open]     (also the default with no arguments)
//!
//! global: --config FILE   --source fmp|csv|synthetic   --limit N
//! ```

use std::collections::HashSet;
use std::path::PathBuf;

use anyhow::{anyhow, Context, Result};
use chrono::{Duration, NaiveDate, Utc};
use clap::{Parser, Subcommand, ValueEnum};

use sp500_breakout::backtest::{self, metrics};
use sp500_breakout::config::{Config, ProviderKind};
use sp500_breakout::data::calendar::last_completed_session_estimate;
use sp500_breakout::data::csv_source::safe_name;
use sp500_breakout::data::{self, DataProvider};
use sp500_breakout::registry::{Observation, Registry};
use sp500_breakout::scanner::{self, ScanOptions};
use sp500_breakout::scrape;
use sp500_breakout::{chart, report};

#[derive(Parser)]
#[command(
    name = "sp500-breakout",
    version,
    about = "Daily-timeframe S&P 500 breakout scanner with a support/resistance rigidity score",
    long_about = "Finds and ranks FRESH and DEVELOPING bullish and bearish breakouts across the S&P 500 \
                  using only completed daily candles. An analytical and research tool: LONG/SHORT labels \
                  describe detected market conditions, not trading instructions."
)]
struct Cli {
    /// Path to a TOML configuration file (default: ./config.toml if present).
    #[arg(short, long, global = true, value_name = "FILE")]
    config: Option<PathBuf>,

    /// Data source, overriding `data.provider` in the configuration.
    #[arg(long, global = true, value_enum)]
    source: Option<SourceArg>,

    /// Restrict the universe to the first N constituents (for quick tests).
    #[arg(long, global = true, value_name = "N")]
    limit: Option<usize>,

    /// With no command, the browser interface is started.
    #[command(subcommand)]
    command: Option<Command>,
}

#[derive(Clone, Copy, ValueEnum)]
enum SourceArg {
    /// Financial Modeling Prep (needs the FMP_API_KEY environment variable).
    Fmp,
    /// Local CSV files (no key).
    Csv,
    /// Generated demo market (no key, works offline).
    Synthetic,
}

#[derive(Subcommand)]
enum Command {
    /// Scan the S&P 500 and print the ranked FRESH/DEVELOPING breakouts.
    Scan {
        /// Analyse as of this completed session (YYYY-MM-DD) instead of the latest.
        #[arg(long, value_name = "DATE")]
        as_of: Option<String>,
        /// Number of results (default: scan.top_n, normally 10).
        #[arg(long, value_name = "N")]
        top: Option<usize>,
        /// Output directory (default: output.dir).
        #[arg(long, value_name = "DIR")]
        out_dir: Option<PathBuf>,
        /// Do not write chart SVGs.
        #[arg(long)]
        no_charts: bool,
        /// Do not read or update the signal registry.
        #[arg(long)]
        no_registry: bool,
    },
    /// Replay the scanner over history and report how its signals performed.
    Backtest {
        /// First simulated session (default: about backtest.test_sessions before the end).
        #[arg(long, value_name = "DATE")]
        start: Option<String>,
        /// Last simulated session (default: latest completed session).
        #[arg(long, value_name = "DATE")]
        end: Option<String>,
        #[arg(long, value_name = "DIR")]
        out_dir: Option<PathBuf>,
    },
    /// Draw the daily chart for one ticker (with its best breakout, if any).
    Chart {
        ticker: String,
        #[arg(long, value_name = "DATE")]
        as_of: Option<String>,
        /// Output file (default: <output.dir>/charts/<TICKER>.svg).
        #[arg(long, value_name = "FILE")]
        out: Option<PathBuf>,
    },
    /// List the current constituents from the configured source.
    Universe,
    /// Run the bundled Python scraper: download daily prices (default 2 years) for many companies
    /// into the folders the "Local CSV files" data source reads. Needs Python 3.8+.
    Scrape {
        /// Number of companies (default: scrape.count in the configuration).
        #[arg(long, value_name = "N")]
        count: Option<usize>,
        /// Years of history (default: scrape.years).
        #[arg(long, value_name = "YEARS")]
        years: Option<f64>,
        /// Comma-separated tickers instead of --count, e.g. AAPL,MSFT,KO.
        #[arg(long, value_name = "LIST")]
        tickers: Option<String>,
        /// Collect company profiles (companies.csv) instead of prices.
        #[arg(long)]
        profiles: bool,
    },
    /// Start the simple browser interface (the default when no command is given).
    Serve {
        /// Preferred local port; the next free one is used if it is taken.
        #[arg(long, default_value_t = 8787)]
        port: u16,
        /// Do not open the browser automatically.
        #[arg(long)]
        no_open: bool,
    },
}

fn main() {
    if let Err(e) = run() {
        eprintln!("error: {e:#}");
        std::process::exit(1);
    }
}

fn run() -> Result<()> {
    // Optional .env file (e.g. FMP_API_KEY=...). Missing file is fine.
    dotenvy::dotenv().ok();
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info"))
        .format_timestamp(None)
        .init();

    let cli = Cli::parse();
    let mut cfg = Config::load(cli.config.as_deref())?;
    if let Some(src) = cli.source {
        cfg.data.provider = match src {
            SourceArg::Fmp => ProviderKind::Fmp,
            SourceArg::Csv => ProviderKind::Csv,
            SourceArg::Synthetic => ProviderKind::Synthetic,
        };
    }
    if let Some(n) = cli.limit {
        cfg.scan.universe_limit = Some(n);
    }

    // Double-clicking the .exe passes no arguments: open the browser interface.
    let command = cli.command.unwrap_or(Command::Serve { port: 8787, no_open: false });
    match command {
        Command::Scan { as_of, top, out_dir, no_charts, no_registry } => {
            cmd_scan(&cfg, as_of, top, out_dir, no_charts, no_registry)
        }
        Command::Backtest { start, end, out_dir } => cmd_backtest(&cfg, start, end, out_dir),
        Command::Chart { ticker, as_of, out } => cmd_chart(&cfg, &ticker, as_of, out),
        Command::Universe => cmd_universe(&cfg),
        Command::Scrape { count, years, tickers, profiles } => cmd_scrape(&cfg, count, years, tickers, profiles),
        Command::Serve { port, no_open } => {
            sp500_breakout::web::serve(cfg, port, !no_open)?;
            Ok(())
        }
    }
}

fn parse_date(s: &str) -> Result<NaiveDate> {
    NaiveDate::parse_from_str(s.trim(), "%Y-%m-%d").with_context(|| format!("invalid date '{s}' (expected YYYY-MM-DD)"))
}

fn cmd_scan(
    cfg: &Config,
    as_of: Option<String>,
    top: Option<usize>,
    out_dir: Option<PathBuf>,
    no_charts: bool,
    no_registry: bool,
) -> Result<()> {
    let provider = data::build_provider(cfg)?;
    let as_of = as_of.as_deref().map(parse_date).transpose()?;
    let opts = ScanOptions { as_of, now: Utc::now(), top_n: top.unwrap_or(cfg.scan.top_n) };
    let result = scanner::run_scan(cfg, provider.as_ref(), &opts)?;

    // The registry tracks the live daily scan; replaying a past date must not rewind it.
    let use_registry = !no_registry && as_of.is_none();
    let mut changes = Vec::new();
    if use_registry {
        let mut reg = Registry::load(&cfg.scan.registry_path)?;
        let listed: HashSet<String> = result.ranked.iter().map(|s| s.event_key()).collect();
        let observations: Vec<Observation> = result.events.iter().map(Observation::from_signal).collect();
        changes = reg.update(result.as_of, &observations, &listed, cfg.scan.registry_retention_days);
        reg.save(&cfg.scan.registry_path)?;
    }

    println!("{}\n", report::render_header(&result));
    print!("{}", report::render_table(&result.ranked));
    println!();
    print!("{}", report::render_explanations(&result.ranked));
    if use_registry {
        print!("{}", report::render_changes(&changes));
    }
    if !result.skipped.is_empty() {
        println!("\nSkipped {} symbols (first 10):", result.skipped.len());
        for (sym, why) in result.skipped.iter().take(10) {
            println!("  {sym}: {why}");
        }
    }
    if !result.warnings.is_empty() {
        log::info!("{} non-fatal data warnings (run with RUST_LOG=debug to list)", result.warnings.len());
        for w in &result.warnings {
            log::debug!("{w}");
        }
    }

    // files
    let dir = out_dir.unwrap_or_else(|| cfg.output.dir.clone());
    let stamp = result.as_of.to_string();
    if cfg.output.write_json {
        let path = dir.join(format!("breakouts_{stamp}.json"));
        report::write_json(&path, &result, &changes)?;
        println!("\nwrote {}", path.display());
    }
    if cfg.output.write_csv {
        let path = dir.join(format!("breakouts_{stamp}.csv"));
        report::write_csv(&path, &result.ranked)?;
        println!("wrote {}", path.display());
    }
    if cfg.output.write_charts && !no_charts && !result.ranked.is_empty() {
        let chart_dir = dir.join("charts");
        std::fs::create_dir_all(&chart_dir)?;
        for (i, s) in result.ranked.iter().enumerate() {
            if let Some(bars) = result.history.get(&s.symbol) {
                let svg = chart::render_svg(&s.symbol, bars, Some(s), cfg);
                let path = chart_dir.join(format!("{stamp}_{:02}_{}_{}.svg", i + 1, safe_name(&s.symbol), s.direction));
                std::fs::write(&path, svg)?;
            }
        }
        println!("wrote {} charts to {}", result.ranked.len(), chart_dir.display());
    }
    Ok(())
}

fn cmd_backtest(cfg: &Config, start: Option<String>, end: Option<String>, out_dir: Option<PathBuf>) -> Result<()> {
    let provider = data::build_provider(cfg)?;
    let now = Utc::now();
    let latest = last_completed_session_estimate(now, cfg.data.market_close_buffer_minutes);
    let end = match end.as_deref() {
        Some(s) => parse_date(s)?,
        None => latest,
    };
    let start = match start.as_deref() {
        Some(s) => parse_date(s)?,
        None => end - Duration::days((cfg.backtest.test_sessions as f64 * 1.45).ceil() as i64),
    };

    let out = backtest::engine::run(cfg, provider.as_ref(), start, end, now)?;
    let summary = metrics::summarize(&out, cfg);
    println!("{}", metrics::render(&summary, cfg.backtest.min_group_size));

    let dir = out_dir.unwrap_or_else(|| cfg.output.dir.clone());
    std::fs::create_dir_all(&dir)?;
    let json_path = dir.join(format!("backtest_{}_{}.json", out.start, out.end));
    std::fs::write(&json_path, serde_json::to_string_pretty(&summary)?)?;
    let csv_path = dir.join(format!("backtest_{}_{}_signals.csv", out.start, out.end));
    backtest::write_records_csv(&csv_path, &out)?;
    println!("wrote {}\nwrote {}", json_path.display(), csv_path.display());
    Ok(())
}

fn cmd_chart(cfg: &Config, ticker: &str, as_of: Option<String>, out: Option<PathBuf>) -> Result<()> {
    let provider = data::build_provider(cfg)?;
    let as_of = as_of.as_deref().map(parse_date).transpose()?;
    let ticker = ticker.trim().to_uppercase();
    let analysis = scanner::analyze_symbol(cfg, provider.as_ref(), &ticker, as_of, Utc::now())?;

    // Prefer an eligible breakout; otherwise show the strongest one of any class.
    let best = analysis
        .signals
        .iter()
        .filter(|s| s.is_eligible())
        .chain(analysis.signals.iter())
        .max_by(|a, b| {
            let ka = (a.is_eligible(), a.composite);
            let kb = (b.is_eligible(), b.composite);
            ka.partial_cmp(&kb).unwrap_or(std::cmp::Ordering::Equal)
        });

    match best {
        Some(s) => println!("{}", report::wrap(&s.explanation, 104, "")),
        None => println!("{ticker}: no breakout detected in the last {} sessions.", cfg.breakout.max_age),
    }

    let svg = chart::render_svg(&ticker, &analysis.bars, best, cfg);
    let path = out.unwrap_or_else(|| cfg.output.dir.join("charts").join(format!("{}.svg", safe_name(&ticker))));
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    std::fs::write(&path, svg).map_err(|e| anyhow!("cannot write {}: {e}", path.display()))?;
    println!("wrote {}", path.display());
    Ok(())
}

fn cmd_scrape(cfg: &Config, count: Option<usize>, years: Option<f64>, tickers: Option<String>, profiles: bool) -> Result<()> {
    let python = scrape::find_python().ok_or_else(|| anyhow!(scrape::PYTHON_MISSING_HELP))?;
    let script = scrape::install_script(&scrape::tools_dir())?;
    let mode = if profiles { "profiles" } else { "prices" };
    let args = scrape::build_args(
        cfg,
        mode,
        count.unwrap_or(cfg.scrape.count),
        years.unwrap_or(cfg.scrape.years),
        tickers.as_deref().unwrap_or(""),
    );
    println!("Running {} with {}\n", script.display(), python.version);
    let code = scrape::run_blocking(&python, &script, &args)?;
    match code {
        0 => {
            if !profiles {
                println!("\nDone. Start the program (no arguments) and choose 'Local CSV files' to scan this data.");
            }
            Ok(())
        }
        4 => {
            println!("\nStopped early by the data site's daily limit; what was downloaded is kept. Run again later to continue.");
            Ok(())
        }
        3 => Err(anyhow!("the data site needs an API key: set the STOOQ_API_KEY environment variable (free key from stooq.com)")),
        c => Err(anyhow!("the scraper exited with code {c}")),
    }
}

fn cmd_universe(cfg: &Config) -> Result<()> {
    let provider: Box<dyn DataProvider> = data::build_provider(cfg)?;
    let list = provider.constituents()?;
    println!("{} constituents from '{}':", list.len(), provider.name());
    for c in &list {
        println!("{:<8} {:<40} {}", c.symbol, c.name, c.sector.as_deref().unwrap_or(""));
    }
    Ok(())
}
