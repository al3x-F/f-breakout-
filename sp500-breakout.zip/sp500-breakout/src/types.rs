//! Core domain types shared by every module.

use std::fmt;

use chrono::NaiveDate;
use serde::{Deserialize, Serialize};

/// A raw daily bar exactly as a data provider delivered it.
///
/// `adj_close` carries the provider's split/dividend-adjusted close. When a
/// provider only supplies one price series it sets `adj_close == close`.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct RawBar {
    pub date: NaiveDate,
    pub open: f64,
    pub high: f64,
    pub low: f64,
    pub close: f64,
    pub adj_close: f64,
    pub volume: f64,
}

impl RawBar {
    /// Ratio used to back-adjust the whole OHLC range of this bar.
    pub fn adjustment_factor(&self) -> f64 {
        if self.close.is_finite()
            && self.adj_close.is_finite()
            && self.close > 0.0
            && self.adj_close > 0.0
        {
            self.adj_close / self.close
        } else {
            1.0
        }
    }

    /// Convert to an adjusted bar: O/H/L/C are all scaled by the same factor so
    /// candle geometry is preserved; volume is left untouched.
    pub fn adjusted(&self) -> Bar {
        let f = self.adjustment_factor();
        Bar {
            date: self.date,
            open: self.open * f,
            high: self.high * f,
            low: self.low * f,
            close: self.close * f,
            volume: self.volume,
        }
    }
}

/// An adjusted daily bar. Every analytical module works on this type.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Bar {
    pub date: NaiveDate,
    pub open: f64,
    pub high: f64,
    pub low: f64,
    pub close: f64,
    pub volume: f64,
}

/// Breakout direction.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum Direction {
    Long,
    Short,
}

impl Direction {
    /// +1 for LONG, -1 for SHORT. Multiplying a price change by this value
    /// expresses it "in the direction of the trade".
    pub fn sign(self) -> f64 {
        match self {
            Direction::Long => 1.0,
            Direction::Short => -1.0,
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Direction::Long => "LONG",
            Direction::Short => "SHORT",
        }
    }

    pub fn both() -> [Direction; 2] {
        [Direction::Long, Direction::Short]
    }
}

impl fmt::Display for Direction {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Opportunity classification (spec section 7.5).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum Classification {
    Fresh,
    Developing,
    Extended,
    Fading,
    Failed,
}

impl Classification {
    /// Only FRESH and DEVELOPING signals may appear in the main ranking.
    pub fn is_eligible(self) -> bool {
        matches!(self, Classification::Fresh | Classification::Developing)
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Classification::Fresh => "FRESH",
            Classification::Developing => "DEVELOPING",
            Classification::Extended => "EXTENDED",
            Classification::Fading => "FADING",
            Classification::Failed => "FAILED",
        }
    }

    pub fn all() -> [Classification; 5] {
        [
            Classification::Fresh,
            Classification::Developing,
            Classification::Extended,
            Classification::Fading,
            Classification::Failed,
        ]
    }
}

impl fmt::Display for Classification {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Potential vs confirmed breakout (spec section 7.3).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum Confirmation {
    Potential,
    Confirmed,
}

impl Confirmation {
    pub fn as_str(self) -> &'static str {
        match self {
            Confirmation::Potential => "POTENTIAL",
            Confirmation::Confirmed => "CONFIRMED",
        }
    }
}

/// Broad-market regime derived from the S&P 500 index (spec section 8.1).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum MarketTrend {
    Bullish,
    Bearish,
    Neutral,
}

impl MarketTrend {
    pub fn as_str(self) -> &'static str {
        match self {
            MarketTrend::Bullish => "BULLISH",
            MarketTrend::Bearish => "BEARISH",
            MarketTrend::Neutral => "NEUTRAL",
        }
    }
}

/// How a breakout relates to the broad-market regime.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TrendAlignment {
    WithTrend,
    Neutral,
    Countertrend,
}

impl TrendAlignment {
    pub fn as_str(self) -> &'static str {
        match self {
            TrendAlignment::WithTrend => "with-trend",
            TrendAlignment::Neutral => "neutral",
            TrendAlignment::Countertrend => "countertrend",
        }
    }
}

/// An S&P 500 member.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Constituent {
    pub symbol: String,
    pub name: String,
    #[serde(default)]
    pub sector: Option<String>,
    #[serde(default)]
    pub date_added: Option<NaiveDate>,
}

/// One S&P 500 index change event (an addition and/or a removal).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MembershipChange {
    pub date: NaiveDate,
    pub added: Option<String>,
    pub removed: Option<String>,
}
