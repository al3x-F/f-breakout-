//! Universe-wide scan: fetch -> clean -> validate -> analyse in parallel ->
//! filter to FRESH/DEVELOPING -> rank (spec sections 2, 10 and 12).

use std::cmp::Ordering;
use std::collections::HashMap;

use chrono::{DateTime, Duration, NaiveDate, Utc};
use rayon::prelude::*;

use crate::breakout::Analyzer;
use crate::config::Config;
use crate::data::calendar::last_completed_session_estimate;
use crate::data::integrity::{clean_bars, drop_incomplete, keep_last, validate};
use crate::data::DataProvider;
use crate::error::{Error, Result};
use crate::market::MarketState;
use crate::signal::BreakoutSignal;
use crate::types::{Bar, Constituent};

pub struct ScanOptions {
    /// Analyse as of this date (must not be in the future); `None` = latest completed session.
    pub as_of: Option<NaiveDate>,
    /// Injected so behaviour is testable; use `Utc::now()` in production.
    pub now: DateTime<Utc>,
    pub top_n: usize,
}

pub struct ScanResult {
    /// Last completed session that was analysed.
    pub as_of: NaiveDate,
    pub market: MarketState,
    pub universe_size: usize,
    pub analysed: usize,
    /// `(symbol, reason)` for every stock excluded by integrity checks or fetch errors.
    pub skipped: Vec<(String, String)>,
    /// Non-fatal data anomalies.
    pub warnings: Vec<String>,
    /// The main ranked list: FRESH / DEVELOPING only, best first, at most `top_n`.
    pub ranked: Vec<BreakoutSignal>,
    /// Every breakout evaluated, whatever its classification (for the registry and statistics).
    pub events: Vec<BreakoutSignal>,
    /// Adjusted bars of the ranked symbols, for charting.
    pub history: HashMap<String, Vec<Bar>>,
}

/// A stock that passed data validation.
pub struct SymbolData {
    pub constituent: Constituent,
    pub bars: Vec<Bar>,
}

/// Order signals best-first: composite score, then fresher, then more rigid, then ticker.
pub fn rank_order(a: &BreakoutSignal, b: &BreakoutSignal) -> Ordering {
    b.composite
        .partial_cmp(&a.composite)
        .unwrap_or(Ordering::Equal)
        .then_with(|| a.age.cmp(&b.age))
        .then_with(|| b.rigidity.partial_cmp(&a.rigidity).unwrap_or(Ordering::Equal))
        .then_with(|| a.symbol.cmp(&b.symbol))
}

/// Keep only FRESH / DEVELOPING signals, optionally one per ticker (the best),
/// sorted best-first and truncated to `top_n`.
///
/// This is the **only** gate into the main ranking: a high composite score can
/// never promote an EXTENDED, FADING or FAILED signal. If fewer than `top_n`
/// qualify, fewer are returned (the list is never padded).
pub fn select_ranked(events: &[BreakoutSignal], top_n: usize, one_per_symbol: bool) -> Vec<BreakoutSignal> {
    let mut eligible: Vec<BreakoutSignal> = events.iter().filter(|s| s.is_eligible()).cloned().collect();
    eligible.sort_by(rank_order);
    if one_per_symbol {
        let mut seen = std::collections::HashSet::new();
        eligible.retain(|s| seen.insert(s.symbol.clone()));
    }
    eligible.truncate(top_n);
    eligible
}

/// The S&P 500 index series plus the resolved analysis window.
struct IndexData {
    /// Last session allowed (never a session that is still incomplete).
    cap: NaiveDate,
    /// First calendar day requested.
    from: NaiveDate,
    /// Last completed session actually present in the index data.
    as_of: NaiveDate,
    bars: Vec<Bar>,
}

fn load_index(
    cfg: &Config,
    provider: &dyn DataProvider,
    as_of: Option<NaiveDate>,
    now: DateTime<Utc>,
) -> Result<IndexData> {
    let buffer = cfg.data.market_close_buffer_minutes;

    // Never analyse a session that is not complete yet.
    let latest = last_completed_session_estimate(now, buffer);
    let cap = match as_of {
        Some(d) if d < latest => d,
        Some(d) => {
            if d > latest {
                log::warn!("as-of date {d} is not a completed session yet; using {latest}");
            }
            latest
        }
        None => latest,
    };
    let from = cap - Duration::days(cfg.data.history_calendar_days);

    // The index is the authoritative trading calendar and the market-trend source.
    let (mut bars, index_warn) = clean_bars(
        &provider
            .history(&cfg.data.index_symbol, from, cap)
            .map_err(|e| Error::Provider(format!("index {}: {e}", cfg.data.index_symbol)))?,
    );
    for w in index_warn {
        log::warn!("index {}: {w}", cfg.data.index_symbol);
    }
    drop_incomplete(&mut bars, now, cap, buffer);
    if bars.len() < cfg.market.slow_period {
        log::warn!(
            "only {} index sessions available (< {}): market-trend filter will be neutral",
            bars.len(),
            cfg.market.slow_period
        );
    }
    let as_of = bars
        .last()
        .map(|b| b.date)
        .ok_or_else(|| Error::Data(format!("no data returned for index {}", cfg.data.index_symbol)))?;
    Ok(IndexData { cap, from, as_of, bars })
}

/// Result of analysing one stock (used by the `chart` command).
pub struct SymbolAnalysis {
    pub as_of: NaiveDate,
    pub company: String,
    pub bars: Vec<Bar>,
    pub market: MarketState,
    /// Every breakout detected, whatever its classification.
    pub signals: Vec<BreakoutSignal>,
}

/// Fetch, clean and analyse a single ticker (no universe, no ranking).
pub fn analyze_symbol(
    cfg: &Config,
    provider: &dyn DataProvider,
    symbol: &str,
    as_of: Option<NaiveDate>,
    now: DateTime<Utc>,
) -> Result<SymbolAnalysis> {
    let buffer = cfg.data.market_close_buffer_minutes;
    let idx = load_index(cfg, provider, as_of, now)?;
    let market = MarketState::from_bars(&idx.bars, &cfg.market);

    let raw = provider.history(symbol, idx.from, idx.cap)?;
    let (mut bars, _) = clean_bars(&raw);
    drop_incomplete(&mut bars, now, idx.as_of, buffer);
    keep_last(&mut bars, cfg.data.history_sessions);
    if bars.len() < cfg.data.min_history_sessions {
        return Err(Error::Data(format!(
            "{symbol}: only {} sessions of history (need {})",
            bars.len(),
            cfg.data.min_history_sessions
        )));
    }

    // Company name is cosmetic: fall back to the ticker if the lookup fails.
    let company = provider
        .constituents()
        .ok()
        .and_then(|v| v.into_iter().find(|c| c.symbol.eq_ignore_ascii_case(symbol)))
        .map(|c| c.name)
        .unwrap_or_else(|| symbol.to_string());

    let signals = Analyzer::new(cfg).analyze(symbol, &company, &bars, &market);
    Ok(SymbolAnalysis { as_of: idx.as_of, company, bars, market, signals })
}

pub fn run_scan(cfg: &Config, provider: &dyn DataProvider, opts: &ScanOptions) -> Result<ScanResult> {
    let buffer = cfg.data.market_close_buffer_minutes;
    let IndexData { cap, from, as_of, bars: index_bars } = load_index(cfg, provider, opts.as_of, opts.now)?;
    let index_dates: Vec<NaiveDate> = index_bars.iter().map(|b| b.date).collect();
    let market = MarketState::from_bars(&index_bars, &cfg.market);
    log::info!("analysis date {as_of}; market trend {}", market.trend.as_str());

    // 2. universe
    let mut universe = provider.constituents()?;
    if let Some(limit) = cfg.scan.universe_limit {
        universe.truncate(limit);
    }
    let universe_size = universe.len();
    log::info!("downloading {} symbols with {} threads", universe_size, cfg.data.concurrency);

    // 3. parallel download (bounded thread pool)
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(cfg.data.concurrency.max(1))
        .build()
        .map_err(|e| Error::Config(format!("cannot build thread pool: {e}")))?;
    let fetched: Vec<(Constituent, Result<Vec<crate::types::RawBar>>)> = pool.install(|| {
        universe
            .par_iter()
            .map(|c| (c.clone(), provider.history(&c.symbol, from, cap)))
            .collect()
    });

    // 4. clean + validate
    let mut datasets: Vec<SymbolData> = Vec::new();
    let mut skipped: Vec<(String, String)> = Vec::new();
    let mut warnings: Vec<String> = Vec::new();
    for (c, res) in fetched {
        let raw = match res {
            Ok(r) => r,
            Err(e) => {
                skipped.push((c.symbol.clone(), format!("download failed: {e}")));
                continue;
            }
        };
        let (mut bars, clean_warn) = clean_bars(&raw);
        warnings.extend(clean_warn.into_iter().map(|w| format!("{}: {w}", c.symbol)));
        drop_incomplete(&mut bars, opts.now, as_of, buffer);
        keep_last(&mut bars, cfg.data.history_sessions);
        let report = validate(&c.symbol, &bars, &index_dates, as_of, &cfg.data);
        let ok = report.is_ok();
        warnings.extend(report.warnings);
        if !ok {
            for f in report.fatal {
                skipped.push((c.symbol.clone(), f));
            }
            continue;
        }
        datasets.push(SymbolData { constituent: c, bars });
    }
    log::info!("{} symbols analysed, {} skipped", datasets.len(), skipped.len());

    // 5. analyse in parallel
    let analyzer = Analyzer::new(cfg);
    let per_symbol: Vec<Vec<BreakoutSignal>> = datasets
        .par_iter()
        .map(|d| analyzer.analyze(&d.constituent.symbol, &d.constituent.name, &d.bars, &market))
        .collect();
    let events: Vec<BreakoutSignal> = per_symbol.into_iter().flatten().collect();

    // 6. rank
    let ranked = select_ranked(&events, opts.top_n, cfg.scan.one_per_symbol);
    let mut history = HashMap::new();
    for s in &ranked {
        if let Some(d) = datasets.iter().find(|d| d.constituent.symbol == s.symbol) {
            history.insert(s.symbol.clone(), d.bars.clone());
        }
    }

    Ok(ScanResult {
        as_of,
        market,
        universe_size,
        analysed: datasets.len(),
        skipped,
        warnings,
        ranked,
        events,
        history,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::breakout::context::SeriesContext;
    use crate::breakout::detector::BreakoutEvent;
    use crate::consolidation;
    use crate::levels::{LevelStats, Zone};
    use crate::scoring;
    use crate::signal;
    use crate::types::Direction;

    /// Build a minimal real signal by running the pipeline pieces on flat bars,
    /// then overwrite the fields the ranking cares about.
    fn fake_signal(symbol: &str, class: crate::types::Classification, composite: f64, age: usize) -> BreakoutSignal {
        let cfg = Config::default();
        let bars: Vec<Bar> = (0..120)
            .map(|i| Bar {
                date: NaiveDate::from_ymd_opt(2025, 1, 1).unwrap() + Duration::days(i),
                open: 100.0,
                high: 101.0,
                low: 99.0,
                close: 100.0,
                volume: 1000.0 + i as f64,
            })
            .collect();
        let ctx = SeriesContext::new(&bars, &cfg);
        let zone = Zone { lower: 99.0, upper: 101.0, center: 100.0, n_pivots: 2, first_pivot_idx: 10, last_pivot_idx: 50 };
        let ev = BreakoutEvent {
            direction: Direction::Long,
            idx: 100,
            date: bars[100].date,
            zone,
            stats: LevelStats::empty(crate::levels::Role::Resistance),
            level: 101.0,
            buffer: 0.5,
            atr_at_breakout: 2.0,
            close: 102.0,
            distance_atr: 0.5,
            rvol: 2.0,
            volume_z: 2.0,
            rsi: 60.0,
            bandwidth: 0.05,
        };
        let eval = crate::breakout::classifier::evaluate(&ctx, &ev, &cfg);
        let cons = consolidation::measure(&ctx, &ev, &cfg);
        let market = MarketState::neutral();
        let bd = scoring::score(&ctx, &ev, &eval, &cons, &market, &cfg);
        let mut s = signal::build(symbol, symbol, &ctx, &ev, &eval, cons, bd, &market, &cfg);
        s.classification = class;
        s.composite = composite;
        s.age = age;
        s
    }

    #[test]
    fn only_fresh_and_developing_reach_the_ranking() {
        use crate::types::Classification::*;
        let events = vec![
            fake_signal("EXT", Extended, 99.0, 1),
            fake_signal("FAD", Fading, 98.0, 1),
            fake_signal("FAI", Failed, 97.0, 1),
            fake_signal("FRE", Fresh, 60.0, 1),
            fake_signal("DEV", Developing, 70.0, 6),
        ];
        let ranked = select_ranked(&events, 10, true);
        let syms: Vec<&str> = ranked.iter().map(|s| s.symbol.as_str()).collect();
        assert_eq!(syms, vec!["DEV", "FRE"]); // fewer than 10 is fine: never padded
    }

    #[test]
    fn ties_break_on_age_and_one_per_symbol_keeps_the_best() {
        use crate::types::Classification::*;
        let events = vec![
            fake_signal("AAA", Fresh, 80.0, 3),
            fake_signal("BBB", Fresh, 80.0, 1),
            fake_signal("AAA", Developing, 85.0, 9),
        ];
        let ranked = select_ranked(&events, 10, true);
        assert_eq!(ranked.len(), 2);
        assert_eq!(ranked[0].symbol, "AAA");
        assert_eq!(ranked[0].composite, 85.0);

        let all = select_ranked(&events, 10, false);
        assert_eq!(all.len(), 3);

        let top1 = select_ranked(&events, 1, false);
        assert_eq!(top1.len(), 1);
    }
}
