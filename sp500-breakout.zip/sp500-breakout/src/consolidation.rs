//! Pre-breakout consolidation analysis (spec section 8.2).
//!
//! A breakout that follows a long, tight, quiet period of price compression is
//! more significant than one out of a volatile, trending stretch. This module
//! measures the compression that immediately preceded the breakout bar.

use serde::Serialize;

use crate::breakout::context::SeriesContext;
use crate::breakout::detector::BreakoutEvent;
use crate::config::Config;
use crate::levels::{find_interactions, Role};
use crate::types::Bar;
use crate::util::{clamp01, mean};

#[derive(Debug, Clone, Serialize)]
pub struct ConsolidationMetrics {
    /// Sessions of consolidation immediately before the breakout bar.
    pub duration: usize,
    /// High-low range of that window in ATRs.
    pub range_atr: f64,
    /// High-low range as a fraction of the mean close.
    pub range_pct: f64,
    /// Distinct tests of the broken zone inside the window.
    pub touches: usize,
    /// Mean volume of the last third of the window / first third (< 1 = drying up).
    pub volume_ratio: f64,
    /// Mean daily range of the last third / first third (< 1 = volatility contracting).
    pub volatility_ratio: f64,
    /// Normalised consolidation quality in `[0, 1]`.
    pub score: f64,
}

impl ConsolidationMetrics {
    fn none(duration: usize) -> Self {
        Self {
            duration,
            range_atr: f64::NAN,
            range_pct: f64::NAN,
            touches: 0,
            volume_ratio: f64::NAN,
            volatility_ratio: f64::NAN,
            score: 0.0,
        }
    }
}

/// Longest window (in bars, at most `max_len`) ending at `end - 1` whose
/// high-low range stays within `cap_atr * atr_ref`.
pub fn consolidation_window(bars: &[Bar], end: usize, atr_ref: f64, max_len: usize, cap_atr: f64) -> usize {
    let limit = max_len.min(end);
    let mut hi = f64::NEG_INFINITY;
    let mut lo = f64::INFINITY;
    let mut best = 0;
    for len in 1..=limit {
        let b = &bars[end - len];
        hi = hi.max(b.high);
        lo = lo.min(b.low);
        if hi - lo <= cap_atr * atr_ref {
            best = len;
        } else {
            break;
        }
    }
    best
}

pub fn measure(ctx: &SeriesContext, ev: &BreakoutEvent, cfg: &Config) -> ConsolidationMetrics {
    let cc = &cfg.consolidation;
    let bars = ctx.bars;
    let end = ev.idx;
    let atr_ref = ev.atr_at_breakout;
    if end == 0 || !atr_ref.is_finite() || atr_ref <= 0.0 {
        return ConsolidationMetrics::none(0);
    }

    let len = consolidation_window(bars, end, atr_ref, cc.max_len, cc.max_range_atr);
    if len < cc.min_len {
        return ConsolidationMetrics::none(len);
    }
    let window = &bars[end - len..end];

    let hi = window.iter().map(|b| b.high).fold(f64::NEG_INFINITY, f64::max);
    let lo = window.iter().map(|b| b.low).fold(f64::INFINITY, f64::min);
    let closes: Vec<f64> = window.iter().map(|b| b.close).collect();
    let range = hi - lo;
    let range_atr = range / atr_ref;
    let range_pct = range / mean(&closes);

    // Interactions with the broken zone during the window.
    let role = Role::for_direction(ev.direction);
    let inter = find_interactions(
        &bars[..end],
        &ctx.atr[..end],
        &ctx.rvol[..end],
        &ev.zone,
        role,
        atr_ref,
        &cfg.levels,
        &cfg.rigidity,
    );
    let touches = inter.iter().filter(|i| i.extreme_idx >= end - len).count();

    // Compare the first and last thirds of the window.
    let third = (len / 3).max(1);
    let first = &window[..third];
    let last = &window[len - third..];
    let vol_first = mean(&first.iter().map(|b| b.volume).collect::<Vec<_>>());
    let vol_last = mean(&last.iter().map(|b| b.volume).collect::<Vec<_>>());
    let rng_first = mean(&first.iter().map(|b| b.high - b.low).collect::<Vec<_>>());
    let rng_last = mean(&last.iter().map(|b| b.high - b.low).collect::<Vec<_>>());
    let volume_ratio = if vol_first > 0.0 { vol_last / vol_first } else { f64::NAN };
    let volatility_ratio = if rng_first > 0.0 { rng_last / rng_first } else { f64::NAN };

    let target = cc.contraction_target.max(1e-9);
    let duration_s = clamp01(len as f64 / cc.duration_target.max(1.0));
    let tightness_s = clamp01(1.0 - range_atr / cc.max_range_atr.max(1e-9));
    let touches_s = clamp01(touches as f64 / cc.touches_target.max(1.0));
    let volume_s = clamp01((1.0 - volume_ratio) / target);
    let volatility_s = clamp01((1.0 - volatility_ratio) / target);

    let weights = [cc.w_duration, cc.w_tightness, cc.w_touches, cc.w_volume, cc.w_volatility];
    let values = [duration_s, tightness_s, touches_s, volume_s, volatility_s];
    let wsum: f64 = weights.iter().sum();
    let score = if wsum > 0.0 {
        clamp01(weights.iter().zip(values.iter()).map(|(w, v)| w * v).sum::<f64>() / wsum)
    } else {
        0.0
    };

    ConsolidationMetrics { duration: len, range_atr, range_pct, touches, volume_ratio, volatility_ratio, score }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn bar(i: usize, hi: f64, lo: f64) -> Bar {
        Bar {
            date: NaiveDate::from_ymd_opt(2024, 1, 1).unwrap() + chrono::Duration::days(i as i64),
            open: (hi + lo) / 2.0,
            high: hi,
            low: lo,
            close: (hi + lo) / 2.0,
            volume: 1000.0,
        }
    }

    #[test]
    fn window_stops_where_range_exceeds_cap() {
        // 10 quiet bars (range 2) preceded by 5 wild bars
        let mut bars: Vec<Bar> = (0..5).map(|i| bar(i, 130.0, 70.0)).collect();
        bars.extend((5..15).map(|i| bar(i, 101.0, 99.0)));
        // ATR 1.0, cap 6 ATR -> quiet region qualifies, wild bars do not
        assert_eq!(consolidation_window(&bars, 15, 1.0, 60, 6.0), 10);
    }

    #[test]
    fn window_is_limited_by_max_len_and_available_bars() {
        let bars: Vec<Bar> = (0..30).map(|i| bar(i, 101.0, 99.0)).collect();
        assert_eq!(consolidation_window(&bars, 30, 1.0, 12, 6.0), 12);
        assert_eq!(consolidation_window(&bars, 5, 1.0, 60, 6.0), 5);
    }
}
