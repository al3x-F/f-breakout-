//! Breakout analysis pipeline for one stock.
//!
//! ```text
//! bars -> SeriesContext (indicators) -> pivots -> detect_events
//!      -> evaluate (classification) -> consolidation -> score -> BreakoutSignal
//! ```

pub mod classifier;
pub mod context;
pub mod continuation;
pub mod detector;

use crate::config::Config;
use crate::consolidation;
use crate::levels::find_pivots;
use crate::market::MarketState;
use crate::scoring;
use crate::signal::{self, BreakoutSignal};
use crate::types::Bar;

use context::SeriesContext;

/// Runs the full per-stock analysis. Stateless and cheap to share across threads.
pub struct Analyzer<'c> {
    cfg: &'c Config,
}

impl<'c> Analyzer<'c> {
    pub fn new(cfg: &'c Config) -> Self {
        Self { cfg }
    }

    /// Analyse a stock whose **last bar is the last completed session**.
    ///
    /// Returns every breakout detected within `breakout.max_age` sessions,
    /// whatever its classification. Callers keep only FRESH / DEVELOPING ones
    /// for the main ranking (see `scanner`); the rest feed false-breakout
    /// statistics, the signal registry and the backtester.
    pub fn analyze(&self, symbol: &str, company: &str, bars: &[Bar], market: &MarketState) -> Vec<BreakoutSignal> {
        let cfg = self.cfg;
        let ctx = SeriesContext::new(bars, cfg);
        if ctx.len() <= ctx.warmup + 2 {
            return Vec::new();
        }
        let pivots = find_pivots(ctx.bars, &ctx.atr, &ctx.rvol, &cfg.levels);
        let events = detector::detect_events(&ctx, &pivots, cfg);

        let mut signals = Vec::with_capacity(events.len());
        for ev in &events {
            let eval = classifier::evaluate(&ctx, ev, cfg);
            let cons = consolidation::measure(&ctx, ev, cfg);
            let breakdown = scoring::score(&ctx, ev, &eval, &cons, market, cfg);
            signals.push(signal::build(symbol, company, &ctx, ev, &eval, cons, breakdown, market, cfg));
        }
        signals
    }
}
