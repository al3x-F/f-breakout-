//! Opportunity classification (spec 7.3-7.5): FRESH / DEVELOPING / EXTENDED /
//! FADING / FAILED, plus the POTENTIAL / CONFIRMED status.
//!
//! The rules are objective and fully driven by [`crate::config::ClassificationConfig`].
//! Precedence, first match wins:
//!
//! 1. **FAILED**    - a later close came back inside the broken zone.
//! 2. **EXTENDED**  - price is `>= extended_atr` ATRs beyond the level, or the
//!    breakout is older than `developing_max_age`; *unless* a valid
//!    continuation setup exists, in which case it is DEVELOPING.
//! 3. **FADING**    - at least `fading_min_signals` of {RSI rolling over, volume
//!    below the floor, pullback from the post-breakout peak}, or neither
//!    momentum nor volume currently supports the move.
//! 4. **FRESH**     - age <= `fresh_max_age`, extension <= `fresh_max_extension_atr`,
//!    and both momentum and volume support it.
//! 5. **DEVELOPING** - everything else that survived the checks above.
//!
//! "EXTENDED" therefore covers both *price* extension and *time* extension
//! (stale); the `reason` string says which.

use super::context::SeriesContext;
use super::continuation::{find_continuation, Continuation};
use super::detector::{momentum_supportive, BreakoutEvent};
use crate::config::Config;
use crate::types::{Classification, Confirmation};
use crate::util::mean_finite;

#[derive(Debug, Clone)]
pub struct Evaluation {
    pub classification: Classification,
    pub confirmation: Confirmation,
    /// Completed sessions since the original breakout bar (0 = breakout on the latest bar).
    pub age: usize,
    /// Latest close beyond the level, in ATRs (negative = back inside).
    pub extension_atr: f64,
    /// Best close beyond the level since the breakout, in ATRs.
    pub peak_extension_atr: f64,
    pub failed: bool,
    /// Returned inside the zone within `false_breakout_sessions`.
    pub false_breakout: bool,
    pub momentum_ok_now: bool,
    pub volume_ok_now: bool,
    /// Change in direction-adjusted RSI since the breakout (since the prior bar when age is 0).
    pub rsi_change: f64,
    pub momentum_strengthening: bool,
    /// Mean RVOL of the post-breakout bars (the breakout bar's RVOL when age is 0).
    pub follow_rvol: f64,
    /// `follow_rvol / breakout RVOL`; > 1 means volume has increased since the breakout.
    pub volume_trend_ratio: f64,
    pub fading_signals: usize,
    pub continuation: Option<Continuation>,
    pub reason: String,
}

pub fn evaluate(ctx: &SeriesContext, ev: &BreakoutEvent, cfg: &Config) -> Evaluation {
    let c = &cfg.classification;
    let bars = ctx.bars;
    let e = ctx.len() - 1;
    let b = ev.idx;
    let age = e - b;
    let dir = ev.direction;
    let s = dir.sign();
    let atr_b = ev.atr_at_breakout;
    let level = ev.level;
    let ext_of = |price: f64| s * (price - level) / atr_b;

    // --- price path since the breakout -----------------------------------
    let extension = ext_of(bars[e].close);
    let mut peak_ext = ext_of(bars[b].close);
    let mut failed_at: Option<usize> = None;
    for j in (b + 1)..=e {
        let x = ext_of(bars[j].close);
        if x > peak_ext {
            peak_ext = x;
        }
        if failed_at.is_none() && x <= -cfg.breakout.failure_buffer_atr {
            failed_at = Some(j);
        }
    }
    let failed = failed_at.is_some();
    let false_breakout = failed_at.map_or(false, |j| j - b <= cfg.breakout.false_breakout_sessions);

    // --- momentum since the breakout --------------------------------------
    let rsi_now = ctx.dir_rsi(dir, e);
    let rsi_ref = if age >= 1 { ctx.dir_rsi(dir, b) } else { ctx.dir_rsi(dir, e - 1) };
    let rsi_change = rsi_now - rsi_ref;
    let mut rsi_peak = rsi_now;
    for j in b..=e {
        let v = ctx.dir_rsi(dir, j);
        if v.is_finite() && v > rsi_peak {
            rsi_peak = v;
        }
    }
    let momentum_drop = rsi_peak - rsi_now;
    let momentum_ok_now = momentum_supportive(ctx, dir, e, &cfg.breakout);

    // --- volume since the breakout -----------------------------------------
    let follow_rvol = if age >= 1 {
        let start = (e + 1).saturating_sub(c.follow_window).max(b + 1);
        mean_finite(&ctx.rvol[start..=e])
    } else {
        ev.rvol
    };
    let volume_trend_ratio = if ev.rvol.is_finite() && ev.rvol > 0.0 && follow_rvol.is_finite() {
        follow_rvol / ev.rvol
    } else {
        1.0
    };
    let volume_ok_now = age == 0 || (follow_rvol.is_finite() && follow_rvol >= c.developing_min_rvol);

    // --- fading symptoms ----------------------------------------------------
    let pullback = peak_ext - extension;
    let mut fading_signals = 0usize;
    if age >= 1 {
        if momentum_drop >= c.fading_rsi_drop {
            fading_signals += 1;
        }
        if follow_rvol.is_finite() && follow_rvol < c.fading_rvol_floor {
            fading_signals += 1;
        }
        if pullback >= c.fading_pullback_atr {
            fading_signals += 1;
        }
    }
    let fading = fading_signals >= c.fading_min_signals;

    // --- classification ------------------------------------------------------
    let extended_price = extension >= c.extended_atr;
    let extended_time = age > c.developing_max_age;
    let mut continuation: Option<Continuation> = None;

    let (classification, reason) = if failed {
        let when = failed_at.map(|j| bars[j].date.to_string()).unwrap_or_default();
        (
            Classification::Failed,
            format!("closed back inside the broken zone on {when}; the breakout is no longer valid"),
        )
    } else if extended_price || extended_time {
        if c.continuation_enabled {
            continuation = find_continuation(ctx, ev, cfg);
        }
        if let Some(cont) = &continuation {
            (
                Classification::Developing,
                format!(
                    "continuation setup: {}-session base beyond the original level cleared on {} \
                     ({:.1} ATR beyond the base)",
                    cont.base_len, cont.resume_date, cont.extension_from_trigger_atr
                ),
            )
        } else if extended_price {
            (
                Classification::Extended,
                format!(
                    "price is {:.1} ATR beyond the level (limit {:.1}); most of the move has already happened",
                    extension, c.extended_atr
                ),
            )
        } else {
            (
                Classification::Extended,
                format!(
                    "breakout is {} sessions old (limit {}) with no continuation setup",
                    age, c.developing_max_age
                ),
            )
        }
    } else if fading || (!momentum_ok_now && !volume_ok_now) {
        let why = if fading {
            format!("{} of 3 fading symptoms present (RSI rolling over, thin volume, pullback)", fading_signals)
        } else {
            "neither momentum nor volume still supports the move".to_string()
        };
        (Classification::Fading, why)
    } else if age <= c.fresh_max_age && extension <= c.fresh_max_extension_atr && momentum_ok_now && volume_ok_now {
        (
            Classification::Fresh,
            format!(
                "age {} <= {} sessions, {:.1} ATR beyond the level (<= {:.1}), momentum and volume supportive",
                age, c.fresh_max_age, extension, c.fresh_max_extension_atr
            ),
        )
    } else {
        (
            Classification::Developing,
            format!(
                "age {} sessions, {:.1} ATR beyond the level, still supported by {}",
                age,
                extension,
                match (momentum_ok_now, volume_ok_now) {
                    (true, true) => "momentum and volume",
                    (true, false) => "momentum",
                    _ => "volume",
                }
            ),
        )
    };

    let confirmation = if !failed && age >= cfg.breakout.confirm_sessions {
        Confirmation::Confirmed
    } else {
        Confirmation::Potential
    };

    Evaluation {
        classification,
        confirmation,
        age,
        extension_atr: extension,
        peak_extension_atr: peak_ext,
        failed,
        false_breakout,
        momentum_ok_now,
        volume_ok_now,
        rsi_change,
        momentum_strengthening: rsi_change > 0.0,
        follow_rvol,
        volume_trend_ratio,
        fading_signals,
        continuation,
        reason,
    }
}
