//! Pre-computed indicator context for one stock's bar slice.

use crate::config::Config;
use crate::indicators::{atr, bollinger, rsi, Bollinger};
use crate::types::{Bar, Direction};
use crate::volume::{rvol_series, zscore_series};

/// All causal indicator series for a slice of daily bars, computed once.
///
/// Because every series is causal, the value at index `i` is identical whether
/// the slice ends at `i` or later, which is what lets the detector look at
/// "the state as of an earlier bar" without any look-ahead.
pub struct SeriesContext<'a> {
    pub bars: &'a [Bar],
    pub rsi: Vec<f64>,
    pub atr: Vec<f64>,
    pub bb: Bollinger,
    pub rvol: Vec<f64>,
    pub vz: Vec<f64>,
    /// First index at which every indicator (and the look-backs the rules use) is valid.
    pub warmup: usize,
}

impl<'a> SeriesContext<'a> {
    pub fn new(bars: &'a [Bar], cfg: &Config) -> Self {
        let close: Vec<f64> = bars.iter().map(|b| b.close).collect();
        let volume: Vec<f64> = bars.iter().map(|b| b.volume).collect();
        let ind = &cfg.indicators;
        let longest = [
            cfg.volume.z_window,
            cfg.volume.rvol_window,
            ind.rsi_period,
            ind.atr_period,
            ind.bb_period,
        ]
        .into_iter()
        .max()
        .unwrap_or(0);
        let lookback = cfg.breakout.rsi_improve_lookback.max(cfg.scoring.rsi_slope_lookback);
        Self {
            bars,
            rsi: rsi(&close, ind.rsi_period),
            atr: atr(bars, ind.atr_period),
            bb: bollinger(&close, ind.bb_period, ind.bb_std),
            rvol: rvol_series(&volume, cfg.volume.rvol_window),
            vz: zscore_series(&volume, cfg.volume.z_window, cfg.volume.z_use_log),
            warmup: longest + lookback + 2,
        }
    }

    pub fn len(&self) -> usize {
        self.bars.len()
    }

    pub fn is_empty(&self) -> bool {
        self.bars.is_empty()
    }

    /// RSI expressed in the trade's direction: RSI for LONG, `100 - RSI` for SHORT,
    /// so "higher is more supportive" in both cases.
    pub fn dir_rsi(&self, dir: Direction, i: usize) -> f64 {
        match dir {
            Direction::Long => self.rsi[i],
            Direction::Short => 100.0 - self.rsi[i],
        }
    }
}
