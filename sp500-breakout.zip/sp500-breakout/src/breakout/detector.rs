//! Breakout detection on completed daily candles (spec sections 7.1-7.3, 12).
//!
//! For every candidate session `t` in the look-back window the detector
//! rebuilds the support/resistance zones **as they were known after bar
//! `t - 1`** and asks whether bar `t` was the first close beyond a zone by a
//! volatility-adjusted buffer. Doing it per session (rather than once for
//! today) means the original breakout date is recorded exactly and no
//! information from after the breakout leaks into the level that was broken.

use chrono::NaiveDate;
use serde::Serialize;

use super::context::SeriesContext;
use crate::config::{BreakoutConfig, Config};
use crate::levels::{build_zones, compute_rigidity, find_interactions, LevelStats, Pivot, Role, Zone};
use crate::types::Direction;

/// A detected breakout: the first buffered close beyond an eligible zone.
#[derive(Debug, Clone, Serialize)]
pub struct BreakoutEvent {
    pub direction: Direction,
    /// Index of the breakout bar in the analysed slice.
    pub idx: usize,
    pub date: NaiveDate,
    /// The zone as known before the breakout bar.
    pub zone: Zone,
    /// Role-specific statistics for that zone (rigidity etc.).
    pub stats: LevelStats,
    /// Zone edge that was crossed (`upper` for LONG, `lower` for SHORT).
    pub level: f64,
    /// Volatility-adjusted buffer (price units) that the close had to clear.
    pub buffer: f64,
    /// ATR as of the bar *before* the breakout (the yardstick for extension).
    pub atr_at_breakout: f64,
    pub close: f64,
    /// Close distance beyond the level on the breakout bar, in ATRs.
    pub distance_atr: f64,
    pub rvol: f64,
    pub volume_z: f64,
    pub rsi: f64,
    pub bandwidth: f64,
}

/// "Positive or improving momentum" (spec 7.1/7.2): the direction-adjusted RSI
/// is on the right side of the midline, or has risen by at least
/// `rsi_improve_min` points over `rsi_improve_lookback` sessions. Overbought /
/// oversold readings deliberately do *not* disqualify a breakout.
pub fn momentum_supportive(ctx: &SeriesContext, dir: Direction, i: usize, cfg: &BreakoutConfig) -> bool {
    let lb = cfg.rsi_improve_lookback;
    if i < lb {
        return false;
    }
    let now = ctx.dir_rsi(dir, i);
    let before = ctx.dir_rsi(dir, i - lb);
    if !now.is_finite() || !before.is_finite() {
        return false;
    }
    let threshold = match dir {
        Direction::Long => cfg.rsi_mid,
        Direction::Short => 100.0 - cfg.rsi_mid,
    };
    now >= threshold || (now - before) >= cfg.rsi_improve_min
}

/// "Bollinger Bands indicate expanding volatility or a developing breakout":
/// bandwidth is expanding, or the close is outside the band in the breakout direction.
pub fn bollinger_supportive(ctx: &SeriesContext, dir: Direction, i: usize, cfg: &BreakoutConfig) -> bool {
    if i == 0 {
        return false;
    }
    let bw = ctx.bb.bandwidth[i];
    let prev = ctx.bb.bandwidth[i - 1];
    if !bw.is_finite() || !prev.is_finite() {
        return false;
    }
    let expanding = bw > prev * (1.0 + cfg.bb_expand_min);
    let close = ctx.bars[i].close;
    let beyond_band = match dir {
        Direction::Long => close > ctx.bb.upper[i],
        Direction::Short => close < ctx.bb.lower[i],
    };
    expanding || beyond_band
}

/// "Trading volume demonstrates sufficient abnormality": both RVOL and Z clear their minimums.
pub fn volume_supportive(ctx: &SeriesContext, i: usize, cfg: &BreakoutConfig) -> bool {
    let rv = ctx.rvol[i];
    let z = ctx.vz[i];
    rv.is_finite() && z.is_finite() && rv >= cfg.min_rvol && z >= cfg.min_z
}

/// Has price closed back inside the zone at any point in `(ev.idx, upto)`?
pub fn has_failed(ctx: &SeriesContext, ev: &BreakoutEvent, upto: usize, cfg: &BreakoutConfig) -> bool {
    let s = ev.direction.sign();
    let end = upto.min(ctx.len());
    for j in (ev.idx + 1)..end {
        let ext = s * (ctx.bars[j].close - ev.level) / ev.atr_at_breakout;
        if ext <= -cfg.failure_buffer_atr {
            return true;
        }
    }
    false
}

/// Find every breakout whose age (completed sessions since the breakout bar) is
/// at most `breakout.max_age`.
///
/// Scanning starts `cooldown_sessions` earlier than strictly necessary so that
/// the cooldown rule sees breakouts that are themselves too old to report.
/// The cooldown is **per level**: a second break of the *same* level (zone edge
/// within one cluster-width of the earlier one) inside the cooldown window,
/// while the first breakout has not failed, is the same breakout continuing and
/// is suppressed. A break of a *different* level is always considered, so a
/// minor zone cleared a few sessions earlier cannot hide the real breakout. If
/// the first breakout failed, a new break of that level is allowed.
pub fn detect_events(ctx: &SeriesContext, pivots: &[Pivot], cfg: &Config) -> Vec<BreakoutEvent> {
    let n = ctx.len();
    if n <= ctx.warmup + 1 {
        return Vec::new();
    }
    let last = n - 1;
    let scan_start = last
        .saturating_sub(cfg.breakout.max_age + cfg.breakout.cooldown_sessions)
        .max(ctx.warmup + 1);

    let mut events: Vec<BreakoutEvent> = Vec::new();
    for t in scan_start..=last {
        for dir in Direction::both() {
            let found = {
                // Recent, still-valid breakouts in this direction: their levels are on cooldown.
                let recent: Vec<&BreakoutEvent> = events
                    .iter()
                    .filter(|e| {
                        e.direction == dir
                            && t - e.idx < cfg.breakout.cooldown_sessions
                            && !has_failed(ctx, e, t, &cfg.breakout)
                    })
                    .collect();
                detect_at(ctx, pivots, t, dir, &recent, cfg)
            };
            if let Some(ev) = found {
                events.push(ev);
            }
        }
    }
    events.retain(|e| last - e.idx <= cfg.breakout.max_age);
    events
}

/// Is bar `t` the first buffered close beyond an eligible zone in direction `dir`?
fn detect_at(
    ctx: &SeriesContext,
    pivots: &[Pivot],
    t: usize,
    dir: Direction,
    recent: &[&BreakoutEvent],
    cfg: &Config,
) -> Option<BreakoutEvent> {
    let bars = ctx.bars;
    let atr_ref = ctx.atr[t - 1];
    if !atr_ref.is_finite() || atr_ref <= 0.0 {
        return None;
    }
    let buf = cfg.breakout.buffer_atr * atr_ref;
    let close = bars[t].close;
    let prev_close = bars[t - 1].close;
    let role = Role::for_direction(dir);
    let s = dir.sign();

    // Zones exactly as known after bar t-1.
    let zones = build_zones(pivots, t, atr_ref, &cfg.levels);

    let mut best: Option<(Zone, LevelStats)> = None;
    for z in zones {
        let edge = z.edge(dir);
        let crossed = match dir {
            Direction::Long => close > edge + buf && prev_close <= edge + buf,
            Direction::Short => close < edge - buf && prev_close >= edge - buf,
        };
        if !crossed {
            continue;
        }
        // Same level as a recent, still-valid breakout: it is on cooldown.
        if recent.iter().any(|e| (e.level - edge).abs() <= cfg.levels.cluster_width_atr * atr_ref) {
            continue;
        }
        let inter = find_interactions(
            &bars[..t],
            &ctx.atr[..t],
            &ctx.rvol[..t],
            &z,
            role,
            atr_ref,
            &cfg.levels,
            &cfg.rigidity,
        );
        let stats = compute_rigidity(&inter, role, t, atr_ref, &cfg.levels, &cfg.rigidity);
        if !stats.is_eligible(&cfg.levels) {
            continue;
        }
        let better = match &best {
            Some((_, bs)) => stats.rigidity > bs.rigidity,
            None => true,
        };
        if better {
            best = Some((z, stats));
        }
    }
    let (zone, stats) = best?;

    // Confirmation evidence on the breakout bar (spec 7.1 / 7.2).
    if cfg.breakout.require_volume && !volume_supportive(ctx, t, &cfg.breakout) {
        return None;
    }
    if cfg.breakout.require_momentum && !momentum_supportive(ctx, dir, t, &cfg.breakout) {
        return None;
    }
    if cfg.breakout.require_bollinger && !bollinger_supportive(ctx, dir, t, &cfg.breakout) {
        return None;
    }

    let level = zone.edge(dir);
    Some(BreakoutEvent {
        direction: dir,
        idx: t,
        date: bars[t].date,
        level,
        buffer: buf,
        atr_at_breakout: atr_ref,
        close,
        distance_atr: s * (close - level) / atr_ref,
        rvol: ctx.rvol[t],
        volume_z: ctx.vz[t],
        rsi: ctx.rsi[t],
        bandwidth: ctx.bb.bandwidth[t],
        zone,
        stats,
    })
}
