//! Continuation setups (spec 7.5, last paragraph).
//!
//! A breakout that has already travelled far (or is old) may still offer a
//! *new* developing opportunity if price consolidated beyond the original
//! level and has now resumed in the same direction. Such a setup is reported as
//! DEVELOPING with `is_continuation = true`; it is never presented as a fresh
//! breakout at the original level.

use chrono::NaiveDate;
use serde::Serialize;

use super::context::SeriesContext;
use super::detector::{momentum_supportive, BreakoutEvent};
use crate::config::Config;
use crate::types::Direction;

#[derive(Debug, Clone, Serialize)]
pub struct Continuation {
    pub base_start: usize,
    /// Last bar of the base (the bar before the resumption bar).
    pub base_end: usize,
    pub base_len: usize,
    pub base_high: f64,
    pub base_low: f64,
    /// Edge of the base that price had to clear (`base_high` LONG, `base_low` SHORT).
    pub trigger_level: f64,
    pub resume_idx: usize,
    pub resume_date: NaiveDate,
    /// How far the latest close is beyond the trigger, in ATRs.
    pub extension_from_trigger_atr: f64,
}

/// Look for a base that formed after the breakout, held beyond the original
/// level, was reasonably tight, and was then cleared on supportive volume and
/// momentum within the last `cont_resume_max_age` sessions.
pub fn find_continuation(ctx: &SeriesContext, ev: &BreakoutEvent, cfg: &Config) -> Option<Continuation> {
    let c = &cfg.classification;
    let bars = ctx.bars;
    let e = ctx.len().checked_sub(1)?;
    let b = ev.idx;
    let dir = ev.direction;
    let s = dir.sign();
    let atr_b = ev.atr_at_breakout;
    if atr_b <= 0.0 || e <= b {
        return None;
    }

    // The move must not already be beyond what a continuation can sensibly add to.
    let total_ext = s * (bars[e].close - ev.level) / atr_b;
    if total_ext > c.cont_max_total_extension_atr {
        return None;
    }

    // The resumption bar r needs a base of at least cont_min_base bars after b.
    let r_min = (b + c.cont_min_base + 1).max(e.saturating_sub(c.cont_resume_max_age));
    if r_min > e {
        return None;
    }

    for r in (r_min..=e).rev() {
        let rv = ctx.rvol[r];
        if !rv.is_finite() || rv < c.cont_min_rvol {
            continue;
        }
        if !momentum_supportive(ctx, dir, r, &cfg.breakout) {
            continue;
        }
        // Prefer the longest base that still satisfies the tightness cap.
        for len in (c.cont_min_base..=c.cont_max_base).rev() {
            if r < len || r - len < b + 1 {
                continue;
            }
            let start = r - len;
            let mut hi = f64::NEG_INFINITY;
            let mut lo = f64::INFINITY;
            for bar in &bars[start..r] {
                hi = hi.max(bar.high);
                lo = lo.min(bar.low);
            }
            if hi - lo > c.cont_max_range_atr * atr_b {
                continue;
            }
            // The base must have held beyond the original level (small wick tolerance).
            let adverse = match dir {
                Direction::Long => ev.level - lo,
                Direction::Short => hi - ev.level,
            } / atr_b;
            if adverse > 0.25 {
                continue;
            }
            let trigger = match dir {
                Direction::Long => hi,
                Direction::Short => lo,
            };
            let trig_ext = s * (bars[r].close - trigger) / atr_b;
            if trig_ext < c.cont_resume_buffer_atr {
                continue;
            }
            let now_ext = s * (bars[e].close - trigger) / atr_b;
            if now_ext > c.cont_max_trigger_extension_atr {
                continue; // the resumption itself has already run too far
            }
            return Some(Continuation {
                base_start: start,
                base_end: r - 1,
                base_len: len,
                base_high: hi,
                base_low: lo,
                trigger_level: trigger,
                resume_idx: r,
                resume_date: bars[r].date,
                extension_from_trigger_atr: now_ext,
            });
        }
    }
    None
}
