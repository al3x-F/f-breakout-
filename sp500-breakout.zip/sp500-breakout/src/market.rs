//! Broad-market trend filter built from the S&P 500 index (spec section 8.1).

use chrono::NaiveDate;
use serde::Serialize;

use crate::config::MarketConfig;
use crate::indicators::sma;
use crate::types::{Bar, Direction, MarketTrend, TrendAlignment};

#[derive(Debug, Clone, Serialize)]
pub struct MarketState {
    pub as_of: Option<NaiveDate>,
    pub close: f64,
    pub sma_fast: f64,
    pub sma_slow: f64,
    pub trend: MarketTrend,
}

fn classify(close: f64, fast: f64, slow: f64) -> MarketTrend {
    if !(close.is_finite() && fast.is_finite() && slow.is_finite()) {
        return MarketTrend::Neutral;
    }
    if close > fast && fast > slow {
        MarketTrend::Bullish
    } else if close < fast && fast < slow {
        MarketTrend::Bearish
    } else {
        MarketTrend::Neutral
    }
}

impl MarketState {
    /// Used when no index data is available: nothing is rewarded or penalised.
    pub fn neutral() -> Self {
        Self { as_of: None, close: f64::NAN, sma_fast: f64::NAN, sma_slow: f64::NAN, trend: MarketTrend::Neutral }
    }

    /// Market state as of the last bar.
    pub fn from_bars(bars: &[Bar], cfg: &MarketConfig) -> Self {
        Self::series(bars, cfg).pop().unwrap_or_else(Self::neutral)
    }

    /// Market state as of *every* bar (causal), used by the backtester so each
    /// simulated day sees only the trend known on that day.
    ///
    /// Bullish: close > fast MA > slow MA. Bearish: close < fast MA < slow MA.
    /// Anything else (mixed signals, or too little history) is Neutral.
    pub fn series(bars: &[Bar], cfg: &MarketConfig) -> Vec<MarketState> {
        let close: Vec<f64> = bars.iter().map(|b| b.close).collect();
        let fast = sma(&close, cfg.fast_period);
        let slow = sma(&close, cfg.slow_period);
        bars.iter()
            .enumerate()
            .map(|(i, b)| MarketState {
                as_of: Some(b.date),
                close: close[i],
                sma_fast: fast[i],
                sma_slow: slow[i],
                trend: classify(close[i], fast[i], slow[i]),
            })
            .collect()
    }

    /// Is a breakout in `dir` with, against, or indifferent to the market?
    pub fn alignment(&self, dir: Direction) -> TrendAlignment {
        match (self.trend, dir) {
            (MarketTrend::Bullish, Direction::Long) | (MarketTrend::Bearish, Direction::Short) => {
                TrendAlignment::WithTrend
            }
            (MarketTrend::Bullish, Direction::Short) | (MarketTrend::Bearish, Direction::Long) => {
                TrendAlignment::Countertrend
            }
            _ => TrendAlignment::Neutral,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn bars(closes: &[f64]) -> Vec<Bar> {
        closes
            .iter()
            .enumerate()
            .map(|(i, &c)| Bar {
                date: NaiveDate::from_ymd_opt(2023, 1, 1).unwrap() + chrono::Duration::days(i as i64),
                open: c,
                high: c,
                low: c,
                close: c,
                volume: 1.0,
            })
            .collect()
    }

    #[test]
    fn uptrend_is_bullish_and_alignment_follows() {
        let closes: Vec<f64> = (0..260).map(|i| 100.0 + i as f64).collect();
        let m = MarketState::from_bars(&bars(&closes), &MarketConfig::default());
        assert_eq!(m.trend, MarketTrend::Bullish);
        assert_eq!(m.alignment(Direction::Long), TrendAlignment::WithTrend);
        assert_eq!(m.alignment(Direction::Short), TrendAlignment::Countertrend);
    }

    #[test]
    fn downtrend_is_bearish() {
        let closes: Vec<f64> = (0..260).map(|i| 500.0 - i as f64).collect();
        let m = MarketState::from_bars(&bars(&closes), &MarketConfig::default());
        assert_eq!(m.trend, MarketTrend::Bearish);
    }

    #[test]
    fn short_history_is_neutral() {
        let closes: Vec<f64> = (0..100).map(|i| 100.0 + i as f64).collect();
        let m = MarketState::from_bars(&bars(&closes), &MarketConfig::default());
        assert_eq!(m.trend, MarketTrend::Neutral);
        assert_eq!(MarketState::neutral().alignment(Direction::Long), TrendAlignment::Neutral);
    }
}
