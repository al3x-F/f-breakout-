//! The fully-evaluated breakout signal that flows to ranking, reports, charts
//! and the backtester.

use chrono::NaiveDate;
use serde::Serialize;

use crate::breakout::classifier::Evaluation;
use crate::breakout::context::SeriesContext;
use crate::breakout::continuation::Continuation;
use crate::breakout::detector::BreakoutEvent;
use crate::config::Config;
use crate::consolidation::ConsolidationMetrics;
use crate::levels::{Maturity, RigidityComponents};
use crate::market::MarketState;
use crate::scoring::{ScoreBreakdown, COMPONENT_NAMES};
use crate::types::{Classification, Confirmation, Direction, MarketTrend, TrendAlignment};

#[derive(Debug, Clone, Serialize)]
pub struct BreakoutSignal {
    pub symbol: String,
    pub company: String,
    pub direction: Direction,
    pub classification: Classification,
    pub confirmation: Confirmation,

    /// Last completed session analysed.
    pub as_of: NaiveDate,
    pub close: f64,

    /// Zone edge that was crossed.
    pub level: f64,
    pub zone_lower: f64,
    pub zone_upper: f64,
    pub breakout_date: NaiveDate,
    /// Completed sessions since the original breakout.
    pub age: usize,
    /// Distance of the latest close beyond the level in ATRs (of the pre-breakout ATR).
    pub extension_atr: f64,
    pub peak_extension_atr: f64,

    pub rigidity: f64,
    pub rigidity_maturity: Maturity,
    pub rigidity_components: RigidityComponents,
    pub level_interactions: usize,
    pub mean_rejection_atr: f64,

    /// Current relative volume and Z-score (latest completed session).
    pub rvol: f64,
    pub volume_z: f64,
    /// Relative volume and Z-score on the breakout bar.
    pub breakout_rvol: f64,
    pub breakout_volume_z: f64,
    pub volume_trend_ratio: f64,

    pub rsi: f64,
    /// Direction-adjusted RSI change since the breakout (positive = momentum strengthened).
    pub rsi_change: f64,
    pub momentum_strengthening: bool,
    pub bandwidth: f64,
    pub atr: f64,
    pub atr_at_breakout: f64,

    pub composite: f64,
    pub score: ScoreBreakdown,

    pub market_trend: MarketTrend,
    pub trend_alignment: TrendAlignment,
    pub consolidation: ConsolidationMetrics,

    pub is_continuation: bool,
    pub continuation: Option<Continuation>,
    pub false_breakout: bool,

    /// Why it received its classification.
    pub reason: String,
    /// Human-readable summary of why it was selected.
    pub explanation: String,
}

impl BreakoutSignal {
    pub fn is_eligible(&self) -> bool {
        self.classification.is_eligible()
    }

    /// Unique key for one breakout event of one stock.
    pub fn event_key(&self) -> String {
        format!("{}|{}|{}", self.symbol, self.direction, self.breakout_date)
    }
}

#[allow(clippy::too_many_arguments)]
pub fn build(
    symbol: &str,
    company: &str,
    ctx: &SeriesContext,
    ev: &BreakoutEvent,
    eval: &Evaluation,
    cons: ConsolidationMetrics,
    breakdown: ScoreBreakdown,
    market: &MarketState,
    cfg: &Config,
) -> BreakoutSignal {
    let e = ctx.len() - 1;
    let mut sig = BreakoutSignal {
        symbol: symbol.to_string(),
        company: company.to_string(),
        direction: ev.direction,
        classification: eval.classification,
        confirmation: eval.confirmation,
        as_of: ctx.bars[e].date,
        close: ctx.bars[e].close,
        level: ev.level,
        zone_lower: ev.zone.lower,
        zone_upper: ev.zone.upper,
        breakout_date: ev.date,
        age: eval.age,
        extension_atr: eval.extension_atr,
        peak_extension_atr: eval.peak_extension_atr,
        rigidity: ev.stats.rigidity,
        rigidity_maturity: ev.stats.maturity,
        rigidity_components: ev.stats.components,
        level_interactions: ev.stats.quality_interactions,
        mean_rejection_atr: ev.stats.mean_rejection_atr,
        rvol: ctx.rvol[e],
        volume_z: ctx.vz[e],
        breakout_rvol: ev.rvol,
        breakout_volume_z: ev.volume_z,
        volume_trend_ratio: eval.volume_trend_ratio,
        rsi: ctx.rsi[e],
        rsi_change: eval.rsi_change,
        momentum_strengthening: eval.momentum_strengthening,
        bandwidth: ctx.bb.bandwidth[e],
        atr: ctx.atr[e],
        atr_at_breakout: ev.atr_at_breakout,
        composite: breakdown.composite,
        score: breakdown,
        market_trend: market.trend,
        trend_alignment: market.alignment(ev.direction),
        consolidation: cons,
        is_continuation: eval.continuation.is_some(),
        continuation: eval.continuation.clone(),
        false_breakout: eval.false_breakout,
        reason: eval.reason.clone(),
        explanation: String::new(),
    };
    sig.explanation = explain(&sig, cfg);
    sig
}

fn age_text(age: usize) -> String {
    match age {
        0 => "on the latest completed session".to_string(),
        1 => "1 session ago".to_string(),
        n => format!("{n} sessions ago"),
    }
}

/// Plain-English summary naming the most significant contributing factors and
/// why the signal is FRESH or DEVELOPING (or whatever it was classified as).
pub fn explain(s: &BreakoutSignal, cfg: &Config) -> String {
    let (role, beyond) = match s.direction {
        Direction::Long => ("resistance", "above"),
        Direction::Short => ("support", "below"),
    };
    let mut parts: Vec<String> = Vec::new();

    parts.push(format!(
        "{} {}: closed at {:.2}, {:.1} ATR {} the {} zone {:.2}-{:.2}; first crossed {} on {} ({}).",
        s.direction,
        s.classification,
        s.close,
        s.extension_atr,
        beyond,
        role,
        s.zone_lower,
        s.zone_upper,
        age_text(s.age),
        s.breakout_date,
        s.confirmation.as_str().to_lowercase(),
    ));

    parts.push(format!(
        "The level is {} with rigidity {:.0}/100: {} meaningful tests, {:.1} ATR average rejection.",
        match s.rigidity_maturity {
            Maturity::Established => "established",
            Maturity::RecentlyFormed => "recently formed",
        },
        s.rigidity,
        s.level_interactions,
        s.mean_rejection_atr,
    ));

    // Most significant contributors by weighted points.
    let mut ranked: Vec<(usize, f64)> = s.score.points.iter().cloned().enumerate().collect();
    ranked.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
    let top: Vec<String> = ranked
        .iter()
        .take(3)
        .map(|(i, p)| format!("{} ({:.1} pts)", COMPONENT_NAMES[*i], p))
        .collect();
    parts.push(format!("Strongest score contributors: {}.", top.join(", ")));

    if s.age == 0 {
        parts.push(format!(
            "Volume is {:.1}x its {}-day average (Z = {:.1}).",
            s.breakout_rvol, cfg.volume.rvol_window, s.breakout_volume_z
        ));
    } else {
        parts.push(format!(
            "Breakout-day volume was {:.1}x average (Z = {:.1}); volume has since {} (post-breakout RVOL ratio {:.2}).",
            s.breakout_rvol,
            s.breakout_volume_z,
            if s.volume_trend_ratio > 1.0 { "increased" } else { "declined" },
            s.volume_trend_ratio
        ));
    }

    parts.push(format!(
        "RSI is {:.0} and momentum has {} since the breakout.",
        s.rsi,
        if s.momentum_strengthening { "strengthened" } else { "weakened" }
    ));

    if s.consolidation.duration >= cfg.consolidation.min_len {
        parts.push(format!(
            "It followed a {}-session consolidation ({:.1} ATR range, {} tests of the level).",
            s.consolidation.duration, s.consolidation.range_atr, s.consolidation.touches
        ));
    }

    parts.push(format!(
        "Market trend is {} ({}).",
        s.market_trend.as_str().to_lowercase(),
        s.trend_alignment.as_str()
    ));

    if let Some(c) = &s.continuation {
        parts.push(format!(
            "This is a continuation: a {}-session base held beyond the original level and was cleared on {}.",
            c.base_len, c.resume_date
        ));
    }

    parts.push(format!("Classified {} because {}.", s.classification, s.reason));
    parts.join(" ")
}
