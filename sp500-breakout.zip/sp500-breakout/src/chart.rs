//! Daily candlestick chart rendered as a self-contained SVG (no extra crates).
//!
//! Three stacked panels share one x-axis:
//!
//! 1. price: candles, Bollinger Bands (20, 2), support/resistance zones, the
//!    broken zone highlighted, the original breakout point and the latest close;
//! 2. volume: daily bars with the 20-day average;
//! 3. RSI(14) with 30 / 50 / 70 guides.

use crate::breakout::context::SeriesContext;
use crate::config::Config;
use crate::indicators::sma;
use crate::levels::{build_zones, find_pivots};
use crate::signal::BreakoutSignal;
use crate::types::{Bar, Direction};

const W: f64 = 1180.0;
const H: f64 = 840.0;
const ML: f64 = 66.0;
const MR: f64 = 86.0;
const PRICE_TOP: f64 = 56.0;
const PRICE_H: f64 = 410.0;
const VOL_TOP: f64 = 484.0;
const VOL_H: f64 = 96.0;
const RSI_TOP: f64 = 600.0;
const RSI_H: f64 = 130.0;
const AXIS_Y: f64 = 748.0;

const UP: &str = "#26a69a";
const DOWN: &str = "#ef5350";
const TEXT: &str = "#374151";
const GRID: &str = "#e5e7eb";
const BAND: &str = "#5c6bc0";

fn esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

/// "Nice" tick values covering `[min, max]`.
pub fn nice_ticks(min: f64, max: f64, target: usize) -> Vec<f64> {
    let range = (max - min).max(1e-9);
    let raw = range / target.max(1) as f64;
    let mag = 10f64.powf(raw.log10().floor());
    let norm = raw / mag;
    let step = (if norm < 1.5 {
        1.0
    } else if norm < 3.0 {
        2.0
    } else if norm < 7.0 {
        5.0
    } else {
        10.0
    }) * mag;
    let mut v = (min / step).ceil() * step;
    let mut out = Vec::new();
    while v <= max + step * 1e-6 && out.len() < 50 {
        out.push(v);
        v += step;
    }
    out
}

/// SVG path through the finite values of a series, lifting the pen at NaNs.
fn path(values: &[f64], start: usize, end: usize, xf: &dyn Fn(usize) -> f64, yf: &dyn Fn(f64) -> f64) -> String {
    let mut d = String::new();
    let mut pen_down = false;
    for i in start..end {
        let v = values[i];
        if v.is_finite() {
            d.push_str(&format!("{}{:.1} {:.1} ", if pen_down { "L" } else { "M" }, xf(i), yf(v)));
            pen_down = true;
        } else {
            pen_down = false;
        }
    }
    d
}

fn text(s: &mut String, x: f64, y: f64, size: u32, anchor: &str, fill: &str, body: &str) {
    s.push_str(&format!(
        "<text x=\"{x:.1}\" y=\"{y:.1}\" font-size=\"{size}\" text-anchor=\"{anchor}\" fill=\"{fill}\">{}</text>\n",
        esc(body)
    ));
}

/// Render the chart. `signal` is optional: without one the chart still shows
/// candles, bands, zones, volume and RSI.
pub fn render_svg(symbol: &str, bars: &[Bar], signal: Option<&BreakoutSignal>, cfg: &Config) -> String {
    let n = bars.len();
    if n < 2 {
        return format!(
            "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"400\" height=\"60\"><text x=\"10\" y=\"35\" font-family=\"sans-serif\">{}: not enough data</text></svg>",
            esc(symbol)
        );
    }
    let ctx = SeriesContext::new(bars, cfg);

    // visible window
    let mut start = n.saturating_sub(cfg.scan.chart_candles.max(30));
    let breakout_idx = signal.and_then(|s| bars.iter().position(|b| b.date == s.breakout_date));
    if let Some(bi) = breakout_idx {
        start = start.min(bi.saturating_sub(10));
    }
    let count = n - start;
    let plot_w = W - ML - MR;
    let step = plot_w / count as f64;
    let xf = move |i: usize| ML + (i - start) as f64 * step + step / 2.0;

    // price scale from candles + Bollinger Bands + the broken zone
    let mut ymin = f64::INFINITY;
    let mut ymax = f64::NEG_INFINITY;
    for i in start..n {
        ymin = ymin.min(bars[i].low);
        ymax = ymax.max(bars[i].high);
        for v in [ctx.bb.upper[i], ctx.bb.lower[i]] {
            if v.is_finite() {
                ymin = ymin.min(v);
                ymax = ymax.max(v);
            }
        }
    }
    if let Some(s) = signal {
        ymin = ymin.min(s.zone_lower);
        ymax = ymax.max(s.zone_upper);
    }
    let pad = (ymax - ymin) * 0.04;
    let (ymin, ymax) = (ymin - pad, ymax + pad);
    let py = move |v: f64| PRICE_TOP + (ymax - v) / (ymax - ymin) * PRICE_H;

    let mut s = String::with_capacity(64 * 1024);
    s.push_str(&format!(
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{W}\" height=\"{H}\" viewBox=\"0 0 {W} {H}\" font-family=\"Helvetica, Arial, sans-serif\">\n"
    ));
    s.push_str(&format!("<rect width=\"{W}\" height=\"{H}\" fill=\"#ffffff\"/>\n"));
    s.push_str(&format!(
        "<defs><clipPath id=\"pc\"><rect x=\"{ML}\" y=\"{PRICE_TOP}\" width=\"{plot_w}\" height=\"{PRICE_H}\"/></clipPath></defs>\n"
    ));

    // title
    let title = match signal {
        Some(sig) => format!(
            "{} - {} | {} {} | score {:.1} | breakout {} ({}) | close {:.2}",
            sig.symbol,
            sig.company,
            sig.direction,
            sig.classification,
            sig.composite,
            sig.breakout_date,
            if sig.age == 0 { "latest session".to_string() } else { format!("{} sessions ago", sig.age) },
            sig.close
        ),
        None => format!("{symbol} - daily chart | close {:.2}", bars[n - 1].close),
    };
    text(&mut s, ML, 28.0, 16, "start", TEXT, &title);

    // price grid + axis
    for t in nice_ticks(ymin, ymax, 7) {
        let y = py(t);
        s.push_str(&format!(
            "<line x1=\"{ML}\" y1=\"{y:.1}\" x2=\"{:.1}\" y2=\"{y:.1}\" stroke=\"{GRID}\" stroke-width=\"1\"/>\n",
            ML + plot_w
        ));
        text(&mut s, ML + plot_w + 6.0, y + 4.0, 11, "start", TEXT, &format!("{t:.2}"));
    }

    // everything inside the price panel is clipped to it
    s.push_str("<g clip-path=\"url(#pc)\">\n");

    // support / resistance zones
    let last_close = bars[n - 1].close;
    let pivots = find_pivots(bars, &ctx.atr, &ctx.rvol, &cfg.levels);
    let zones = build_zones(&pivots, n, ctx.atr[n - 1], &cfg.levels);
    for z in &zones {
        let is_broken = signal.map_or(false, |sig| z.center >= sig.zone_lower && z.center <= sig.zone_upper);
        if is_broken || z.n_pivots < 2 || z.upper < ymin || z.lower > ymax {
            continue;
        }
        let (fill, stroke) = if z.center > last_close { (DOWN, DOWN) } else { (UP, UP) };
        let (y1, y2) = (py(z.upper), py(z.lower));
        s.push_str(&format!(
            "<rect x=\"{ML}\" y=\"{y1:.1}\" width=\"{plot_w}\" height=\"{:.1}\" fill=\"{fill}\" fill-opacity=\"0.10\" stroke=\"{stroke}\" stroke-opacity=\"0.35\" stroke-width=\"1\"/>\n",
            (y2 - y1).max(1.0)
        ));
    }
    if let Some(sig) = signal {
        let (y1, y2) = (py(sig.zone_upper), py(sig.zone_lower));
        s.push_str(&format!(
            "<rect x=\"{ML}\" y=\"{y1:.1}\" width=\"{plot_w}\" height=\"{:.1}\" fill=\"#f59e0b\" fill-opacity=\"0.20\" stroke=\"#d97706\" stroke-width=\"1.5\" stroke-dasharray=\"6 3\"/>\n",
            (y2 - y1).max(1.5)
        ));
    }

    // Bollinger Bands
    s.push_str(&format!(
        "<path d=\"{}\" fill=\"none\" stroke=\"{BAND}\" stroke-width=\"1.2\" stroke-opacity=\"0.85\"/>\n",
        path(&ctx.bb.upper, start, n, &xf, &py)
    ));
    s.push_str(&format!(
        "<path d=\"{}\" fill=\"none\" stroke=\"{BAND}\" stroke-width=\"1.2\" stroke-opacity=\"0.85\"/>\n",
        path(&ctx.bb.lower, start, n, &xf, &py)
    ));
    s.push_str(&format!(
        "<path d=\"{}\" fill=\"none\" stroke=\"{BAND}\" stroke-width=\"1\" stroke-opacity=\"0.6\" stroke-dasharray=\"4 3\"/>\n",
        path(&ctx.bb.mid, start, n, &xf, &py)
    ));

    // candles
    let body_w = (step * 0.68).max(1.0);
    for i in start..n {
        let b = &bars[i];
        let cx = xf(i);
        let color = if b.close >= b.open { UP } else { DOWN };
        s.push_str(&format!(
            "<line x1=\"{cx:.1}\" y1=\"{:.1}\" x2=\"{cx:.1}\" y2=\"{:.1}\" stroke=\"{color}\" stroke-width=\"1\"/>\n",
            py(b.high),
            py(b.low)
        ));
        let top = py(b.open.max(b.close));
        let bot = py(b.open.min(b.close));
        s.push_str(&format!(
            "<rect x=\"{:.1}\" y=\"{top:.1}\" width=\"{body_w:.1}\" height=\"{:.1}\" fill=\"{color}\"/>\n",
            cx - body_w / 2.0,
            (bot - top).max(1.0)
        ));
    }

    // breakout level line + marker
    if let (Some(sig), Some(bi)) = (signal, breakout_idx) {
        if bi >= start {
            let yl = py(sig.level);
            s.push_str(&format!(
                "<line x1=\"{:.1}\" y1=\"{yl:.1}\" x2=\"{:.1}\" y2=\"{yl:.1}\" stroke=\"#d97706\" stroke-width=\"1.2\" stroke-dasharray=\"2 3\"/>\n",
                xf(bi),
                ML + plot_w
            ));
            let bx = xf(bi);
            let b = &bars[bi];
            let marker = match sig.direction {
                Direction::Long => {
                    let y = py(b.low) + 6.0;
                    format!("{:.1},{:.1} {:.1},{:.1} {:.1},{:.1}", bx, y, bx - 6.0, y + 11.0, bx + 6.0, y + 11.0)
                }
                Direction::Short => {
                    let y = py(b.high) - 6.0;
                    format!("{:.1},{:.1} {:.1},{:.1} {:.1},{:.1}", bx, y, bx - 6.0, y - 11.0, bx + 6.0, y - 11.0)
                }
            };
            s.push_str(&format!("<polygon points=\"{marker}\" fill=\"#d97706\"/>\n"));
        }
    }

    // latest close
    let yc = py(last_close);
    s.push_str(&format!(
        "<line x1=\"{ML}\" y1=\"{yc:.1}\" x2=\"{:.1}\" y2=\"{yc:.1}\" stroke=\"#111827\" stroke-width=\"1\" stroke-dasharray=\"1 3\"/>\n",
        ML + plot_w
    ));
    s.push_str("</g>\n");

    // outside the clip: labels for the close tag and the breakout
    s.push_str(&format!(
        "<rect x=\"{:.1}\" y=\"{:.1}\" width=\"{:.1}\" height=\"16\" fill=\"#111827\"/>\n",
        ML + plot_w + 2.0,
        yc - 8.0,
        MR - 6.0
    ));
    text(&mut s, ML + plot_w + 6.0, yc + 4.0, 11, "start", "#ffffff", &format!("{last_close:.2}"));
    if let (Some(sig), Some(bi)) = (signal, breakout_idx) {
        if bi >= start {
            let bx = xf(bi);
            s.push_str(&format!(
                "<line x1=\"{bx:.1}\" y1=\"{PRICE_TOP}\" x2=\"{bx:.1}\" y2=\"{:.1}\" stroke=\"#d97706\" stroke-width=\"1\" stroke-dasharray=\"5 4\" stroke-opacity=\"0.8\"/>\n",
                RSI_TOP + RSI_H
            ));
            text(
                &mut s,
                (bx + 4.0).min(ML + plot_w - 150.0),
                PRICE_TOP + 14.0,
                11,
                "start",
                "#b45309",
                &format!("Breakout {} @ {:.2}", sig.breakout_date, sig.level),
            );
        }
    }

    // volume panel
    let volumes: Vec<f64> = bars.iter().map(|b| b.volume).collect();
    let vol_avg = sma(&volumes, cfg.volume.rvol_window);
    let vmax = (start..n).map(|i| volumes[i]).fold(0.0f64, f64::max).max(1.0);
    let vy = move |v: f64| VOL_TOP + VOL_H - (v / vmax) * (VOL_H - 4.0);
    s.push_str(&format!(
        "<line x1=\"{ML}\" y1=\"{:.1}\" x2=\"{:.1}\" y2=\"{:.1}\" stroke=\"{GRID}\"/>\n",
        VOL_TOP + VOL_H,
        ML + plot_w,
        VOL_TOP + VOL_H
    ));
    for i in start..n {
        let color = if bars[i].close >= bars[i].open { UP } else { DOWN };
        let y = vy(volumes[i]);
        s.push_str(&format!(
            "<rect x=\"{:.1}\" y=\"{y:.1}\" width=\"{body_w:.1}\" height=\"{:.1}\" fill=\"{color}\" fill-opacity=\"0.7\"/>\n",
            xf(i) - body_w / 2.0,
            (VOL_TOP + VOL_H - y).max(0.5)
        ));
    }
    s.push_str(&format!(
        "<path d=\"{}\" fill=\"none\" stroke=\"#111827\" stroke-width=\"1\" stroke-opacity=\"0.7\"/>\n",
        path(&vol_avg, start, n, &xf, &vy)
    ));
    text(&mut s, ML, VOL_TOP - 6.0, 11, "start", TEXT, "Volume (line = 20-day average)");
    text(&mut s, ML + plot_w + 6.0, VOL_TOP + 10.0, 11, "start", TEXT, &format!("{:.2}M", vmax / 1.0e6));

    // RSI panel
    let ry = move |v: f64| RSI_TOP + (100.0 - v) / 100.0 * RSI_H;
    for level in [30.0, 50.0, 70.0] {
        s.push_str(&format!(
            "<line x1=\"{ML}\" y1=\"{:.1}\" x2=\"{:.1}\" y2=\"{:.1}\" stroke=\"{GRID}\" stroke-dasharray=\"{}\"/>\n",
            ry(level),
            ML + plot_w,
            ry(level),
            if level == 50.0 { "none" } else { "4 3" }
        ));
        text(&mut s, ML + plot_w + 6.0, ry(level) + 4.0, 11, "start", TEXT, &format!("{level:.0}"));
    }
    s.push_str(&format!(
        "<path d=\"{}\" fill=\"none\" stroke=\"#7c3aed\" stroke-width=\"1.5\"/>\n",
        path(&ctx.rsi, start, n, &xf, &ry)
    ));
    text(&mut s, ML, RSI_TOP - 6.0, 11, "start", TEXT, &format!("RSI({})", cfg.indicators.rsi_period));

    // date axis
    let labels = 6usize.min(count);
    for k in 0..labels {
        let i = start + k * (count - 1) / labels.saturating_sub(1).max(1);
        text(&mut s, xf(i), AXIS_Y, 11, "middle", TEXT, &bars[i].date.to_string());
    }

    // legend
    text(
        &mut s,
        ML,
        H - 22.0,
        11,
        "start",
        TEXT,
        "Candles: daily OHLC | Blue: Bollinger Bands (20, 2) | Red/green bands: resistance/support zones | Amber: broken zone and breakout point | Dotted black: latest close",
    );
    s.push_str("</svg>\n");
    s
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn bars(n: usize) -> Vec<Bar> {
        (0..n)
            .map(|i| {
                let c = 100.0 + (i as f64 / 6.0).sin() * 8.0 + i as f64 * 0.05;
                Bar {
                    date: NaiveDate::from_ymd_opt(2025, 1, 1).unwrap() + chrono::Duration::days(i as i64),
                    open: c - 0.3,
                    high: c + 1.0,
                    low: c - 1.0,
                    close: c,
                    volume: 1.0e6 + (i % 7) as f64 * 1.0e5,
                }
            })
            .collect()
    }

    #[test]
    fn ticks_are_ascending_and_in_range() {
        let t = nice_ticks(93.3, 118.7, 6);
        assert!(t.len() >= 3);
        assert!(t.windows(2).all(|w| w[1] > w[0]));
        assert!(t.iter().all(|v| *v >= 93.3 - 1e-9 && *v <= 118.7 + 1e-9));
    }

    #[test]
    fn escapes_markup() {
        assert_eq!(esc("A&B <x>"), "A&amp;B &lt;x&gt;");
    }

    #[test]
    fn renders_a_well_formed_svg_without_a_signal() {
        let svg = render_svg("TEST", &bars(300), None, &Config::default());
        assert!(svg.starts_with("<svg"));
        assert!(svg.trim_end().ends_with("</svg>"));
        assert!(svg.contains("TEST - daily chart"));
        assert!(svg.matches("<rect").count() > 100);
        assert!(!svg.contains("NaN"));
    }

    #[test]
    fn tiny_input_does_not_panic() {
        let svg = render_svg("X", &bars(1), None, &Config::default());
        assert!(svg.contains("not enough data"));
    }
}
