//! Backtest engine: replays the live analyser day by day.

use std::collections::{HashMap, HashSet};

use chrono::{DateTime, Duration, NaiveDate, Utc};
use rayon::prelude::*;

use super::costs::CostModel;
use super::{BacktestOutput, SignalRecord, TradeReturn};
use crate::breakout::Analyzer;
use crate::config::Config;
use crate::data::calendar::last_completed_session_estimate;
use crate::data::integrity::{clean_bars, drop_incomplete};
use crate::data::{DataProvider, MembershipHistory};
use crate::error::{Error, Result};
use crate::market::MarketState;
use crate::signal::BreakoutSignal;
use crate::types::{Bar, Classification, Constituent, Direction};

/// Everything the simulation needs, already loaded and cleaned.
pub struct BacktestInput<'a> {
    pub index_bars: &'a [Bar],
    /// `(constituent, adjusted bars)` for every stock that may be tested.
    pub symbols: &'a [(Constituent, Vec<Bar>)],
    /// Point-in-time membership, if available (reduces survivorship bias).
    pub membership: Option<&'a MembershipHistory>,
    pub start: NaiveDate,
    pub end: NaiveDate,
}

/// Direction-adjusted returns for each horizon.
///
/// The signal is generated after the close of bar `i`. The hypothetical trade
/// enters at the **open of bar `i + 1`** and exits at the close of bar
/// `i + h`, i.e. it is held for exactly `h` sessions.
pub fn forward_returns(
    bars: &[Bar],
    i: usize,
    dir: Direction,
    horizons: &[usize],
    costs: &CostModel,
) -> Vec<Option<TradeReturn>> {
    let entry = match bars.get(i + 1) {
        Some(b) if b.open > 0.0 => b.open,
        _ => return vec![None; horizons.len()],
    };
    horizons
        .iter()
        .map(|&h| {
            let exit_idx = i + h;
            if h == 0 || exit_idx >= bars.len() {
                return None;
            }
            let price_return = bars[exit_idx].close / entry - 1.0;
            let gross = dir.sign() * price_return;
            let net = gross - costs.round_trip_fraction(dir, h);
            Some(TradeReturn { price_return, gross, net })
        })
        .collect()
}

/// With hindsight: did price return inside the zone within the false-breakout
/// window? (Used only to *evaluate* signals, never to generate them.)
pub fn realised_false_breakout(bars: &[Bar], s: &BreakoutSignal, cfg: &Config) -> bool {
    let b = match bars.binary_search_by(|x| x.date.cmp(&s.breakout_date)) {
        Ok(b) => b,
        Err(_) => return false,
    };
    if s.atr_at_breakout <= 0.0 {
        return false;
    }
    let sgn = s.direction.sign();
    let end = (b + cfg.breakout.false_breakout_sessions).min(bars.len().saturating_sub(1));
    for j in (b + 1)..=end {
        let ext = sgn * (bars[j].close - s.level) / s.atr_at_breakout;
        if ext <= -cfg.breakout.failure_buffer_atr {
            return true;
        }
    }
    false
}

struct Sim<'a> {
    cfg: &'a Config,
    analyzer: Analyzer<'a>,
    costs: CostModel,
    index_dates: Vec<NaiveDate>,
    market_states: Vec<MarketState>,
    members_by_date: Option<HashMap<NaiveDate, HashSet<String>>>,
    start: NaiveDate,
    end: NaiveDate,
}

fn make_record(sim: &Sim, s: &BreakoutSignal, bars: &[Bar], i: usize) -> SignalRecord {
    SignalRecord {
        symbol: s.symbol.clone(),
        direction: s.direction,
        classification: s.classification,
        signal_date: s.as_of,
        breakout_date: s.breakout_date,
        age: s.age,
        composite: s.composite,
        components: s.score.components.as_array(),
        rigidity: s.rigidity,
        false_breakout: realised_false_breakout(bars, s, sim.cfg),
        returns: forward_returns(bars, i, s.direction, &sim.cfg.backtest.horizons, &sim.costs),
    }
}

/// Replay one stock. Returns `(first-sighting records, best eligible per day)`.
fn simulate_symbol(sim: &Sim, c: &Constituent, bars: &[Bar]) -> (Vec<SignalRecord>, Vec<SignalRecord>) {
    let cfg = sim.cfg;
    let step = cfg.backtest.signal_step.max(1);
    let lookback = cfg.backtest.lookback_sessions;
    let min_hist = cfg.data.min_history_sessions;

    let mut records = Vec::new();
    let mut daily = Vec::new();
    let mut seen: HashSet<(Direction, NaiveDate, Classification)> = HashSet::new();

    let mut i = bars.partition_point(|b| b.date < sim.start);
    while i + 1 < bars.len() && bars[i].date <= sim.end {
        let date = bars[i].date;
        let allowed = match &sim.members_by_date {
            Some(map) => map.get(&date).map_or(true, |set| set.contains(&c.symbol)),
            None => true,
        };
        if allowed {
            // Only what was knowable on `date`: the trailing window ending today.
            let lo = (i + 1).saturating_sub(lookback);
            let window = &bars[lo..=i];
            if window.len() >= min_hist {
                let mi = sim.index_dates.partition_point(|d| *d <= date);
                let market = if mi == 0 { MarketState::neutral() } else { sim.market_states[mi - 1].clone() };
                let signals = sim.analyzer.analyze(&c.symbol, &c.name, window, &market);

                let mut best: Option<&BreakoutSignal> = None;
                for s in &signals {
                    if s.is_eligible() && best.map_or(true, |b| s.composite > b.composite) {
                        best = Some(s);
                    }
                    if seen.insert((s.direction, s.breakout_date, s.classification)) {
                        records.push(make_record(sim, s, bars, i));
                    }
                }
                if let Some(b) = best {
                    daily.push(make_record(sim, b, bars, i));
                }
            }
        }
        i += step;
    }
    (records, daily)
}

/// Run the simulation on already-loaded data.
pub fn run_backtest(cfg: &Config, input: &BacktestInput) -> BacktestOutput {
    let index_dates: Vec<NaiveDate> = input.index_bars.iter().map(|b| b.date).collect();
    let market_states = MarketState::series(input.index_bars, &cfg.market);

    let members_by_date = input.membership.map(|hist| {
        index_dates
            .iter()
            .filter(|d| **d >= input.start && **d <= input.end)
            .map(|d| (*d, hist.members_on(*d)))
            .collect::<HashMap<_, _>>()
    });

    let sim = Sim {
        cfg,
        analyzer: Analyzer::new(cfg),
        costs: CostModel::from_config(&cfg.backtest),
        index_dates,
        market_states,
        members_by_date,
        start: input.start,
        end: input.end,
    };

    let per_symbol: Vec<(Vec<SignalRecord>, Vec<SignalRecord>)> = input
        .symbols
        .par_iter()
        .map(|(c, bars)| simulate_symbol(&sim, c, bars))
        .collect();

    let mut records = Vec::new();
    let mut daily_eligible = Vec::new();
    for (r, d) in per_symbol {
        records.extend(r);
        daily_eligible.extend(d);
    }

    BacktestOutput {
        horizons: cfg.backtest.horizons.clone(),
        start: input.start,
        end: input.end,
        symbols_tested: input.symbols.len(),
        records,
        daily_eligible,
    }
}

/// Load data from a provider (index, constituents, optional membership history,
/// per-stock history) and run the simulation.
pub fn run(
    cfg: &Config,
    provider: &dyn DataProvider,
    start: NaiveDate,
    end: NaiveDate,
    now: DateTime<Utc>,
) -> Result<BacktestOutput> {
    let buffer = cfg.data.market_close_buffer_minutes;
    let latest = last_completed_session_estimate(now, buffer);
    let end = end.min(latest);
    if start >= end {
        return Err(Error::Config(format!("backtest start {start} must be before end {end}")));
    }
    let max_h = cfg.backtest.horizons.iter().copied().max().unwrap_or(0) as i64;

    // Enough history before `start` for the lookback window, and enough after
    // `end` to measure the longest horizon.
    let fetch_from = start - Duration::days((cfg.backtest.lookback_sessions as f64 * 1.5) as i64 + 30);
    let fetch_to = (end + Duration::days(max_h * 2 + 10)).min(latest);

    // index
    let (_, raw_index) = crate::data::fetch_index(provider, &cfg.data, fetch_from, fetch_to)
        .map_err(|e| Error::Provider(format!("index {}: {e}", cfg.data.index_symbol)))?;
    let (mut index_bars, _) = clean_bars(&raw_index);
    drop_incomplete(&mut index_bars, now, fetch_to, buffer);
    if index_bars.is_empty() {
        return Err(Error::Data(format!("no data for index {}", cfg.data.index_symbol)));
    }

    // universe + point-in-time membership
    let current = provider.constituents()?;
    let membership = if cfg.backtest.use_historical_membership {
        match provider.membership_changes() {
            Ok(changes) if !changes.is_empty() => Some(MembershipHistory::new(&current, changes)),
            Ok(_) => {
                log::warn!(
                    "provider returned no index-change history: testing today's constituents only \
                     (survivorship bias will flatter results)"
                );
                None
            }
            Err(e) => {
                log::warn!("could not load index-change history ({e}); testing today's constituents only");
                None
            }
        }
    } else {
        None
    };

    let mut universe: Vec<Constituent> = current.clone();
    if let Some(hist) = &membership {
        let known: HashSet<String> = current.iter().map(|c| c.symbol.clone()).collect();
        let mut extra: Vec<String> = hist
            .all_symbols_since(start)
            .into_iter()
            .filter(|s| !known.contains(s))
            .collect();
        extra.sort();
        for s in extra {
            universe.push(Constituent { name: s.clone(), symbol: s, sector: None, date_added: None });
        }
    }
    if let Some(limit) = cfg.scan.universe_limit {
        universe.truncate(limit);
    }

    // download
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(cfg.data.concurrency.max(1))
        .build()
        .map_err(|e| Error::Config(format!("cannot build thread pool: {e}")))?;
    let fetched: Vec<(Constituent, Result<Vec<crate::types::RawBar>>)> = pool.install(|| {
        universe
            .par_iter()
            .map(|c| (c.clone(), provider.history(&c.symbol, fetch_from, fetch_to)))
            .collect()
    });

    let mut symbols: Vec<(Constituent, Vec<Bar>)> = Vec::new();
    let mut unavailable = 0usize;
    for (c, res) in fetched {
        match res {
            Ok(raw) => {
                let (mut bars, _) = clean_bars(&raw);
                drop_incomplete(&mut bars, now, fetch_to, buffer);
                if bars.len() >= cfg.data.min_history_sessions {
                    symbols.push((c, bars));
                } else {
                    unavailable += 1;
                }
            }
            Err(e) => {
                log::debug!("{}: {e}", c.symbol);
                unavailable += 1;
            }
        }
    }
    if unavailable > 0 {
        log::warn!(
            "{unavailable} symbols had no usable history (delisted tickers are often unavailable; \
             this leaves some survivorship bias)"
        );
    }
    if symbols.is_empty() {
        return Err(Error::Data("no symbols with usable history".into()));
    }
    log::info!("backtesting {} symbols from {start} to {end}", symbols.len());

    let input = BacktestInput {
        index_bars: &index_bars,
        symbols: &symbols,
        membership: membership.as_ref(),
        start,
        end,
    };
    Ok(run_backtest(cfg, &input))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn bars(opens_closes: &[(f64, f64)]) -> Vec<Bar> {
        opens_closes
            .iter()
            .enumerate()
            .map(|(i, &(o, c))| Bar {
                date: NaiveDate::from_ymd_opt(2025, 1, 1).unwrap() + Duration::days(i as i64),
                open: o,
                high: o.max(c),
                low: o.min(c),
                close: c,
                volume: 1.0,
            })
            .collect()
    }

    fn zero_costs() -> CostModel {
        CostModel { commission_bps: 0.0, spread_bps: 0.0, slippage_bps: 0.0, borrow_bps_per_year: 0.0 }
    }

    #[test]
    fn entry_is_next_open_and_exit_is_close_h_sessions_later() {
        // i = 0 is the signal bar; entry open of bar 1 = 100; exit close of bar 2 (h = 2) = 110
        let b = bars(&[(90.0, 95.0), (100.0, 102.0), (103.0, 110.0), (110.0, 120.0)]);
        let r = forward_returns(&b, 0, Direction::Long, &[1, 2, 3, 9], &zero_costs());
        assert!((r[0].unwrap().price_return - 0.02).abs() < 1e-12); // close of bar 1 / 100 - 1
        assert!((r[1].unwrap().price_return - 0.10).abs() < 1e-12);
        assert!((r[2].unwrap().price_return - 0.20).abs() < 1e-12);
        assert!(r[3].is_none()); // beyond the data
    }

    #[test]
    fn shorts_profit_from_falls_and_pay_costs() {
        let b = bars(&[(90.0, 95.0), (100.0, 100.0), (100.0, 90.0)]);
        let costs = CostModel { commission_bps: 0.0, spread_bps: 10.0, slippage_bps: 0.0, borrow_bps_per_year: 0.0 };
        let r = forward_returns(&b, 0, Direction::Short, &[2], &costs)[0].unwrap();
        assert!((r.price_return - (-0.10)).abs() < 1e-12);
        assert!((r.gross - 0.10).abs() < 1e-12);
        assert!((r.net - (0.10 - 0.0010)).abs() < 1e-12);
    }

    #[test]
    fn no_entry_bar_means_no_returns() {
        let b = bars(&[(90.0, 95.0)]);
        let r = forward_returns(&b, 0, Direction::Long, &[1, 5], &zero_costs());
        assert!(r.iter().all(|x| x.is_none()));
    }
}
