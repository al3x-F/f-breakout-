//! Historical backtesting and performance evaluation (spec section 11).
//!
//! The backtester replays the *same* `Analyzer` used by the live scanner on
//! every simulated day, feeding it only the trailing `lookback_sessions` bars
//! available on that day (so there is no look-ahead), then measures what
//! happened next. Signals are generated after the close; the hypothetical entry
//! is the **next session's open**, with commission, spread, slippage and (for
//! shorts) borrow costs deducted.

pub mod costs;
pub mod engine;
pub mod metrics;

use std::path::Path;

use chrono::NaiveDate;
use serde::Serialize;

use crate::error::Result;
use crate::scoring::COMPONENT_NAMES;
use crate::types::{Classification, Direction};

/// Return of one hypothetical trade over one horizon.
#[derive(Debug, Clone, Copy, Serialize)]
pub struct TradeReturn {
    /// Raw price change from entry open to exit close (not direction-adjusted).
    pub price_return: f64,
    /// Direction-adjusted return before costs.
    pub gross: f64,
    /// Direction-adjusted return after all costs.
    pub net: f64,
}

/// One observed breakout state and what followed it.
///
/// A given breakout event produces at most one record per classification: the
/// *first* simulated day on which it was seen in that state. So "FRESH" records
/// are entries on the first day a breakout is seen, "EXTENDED" records are late
/// entries, and so on. Comparing them shows whether the recency / extension
/// filters improve outcomes.
#[derive(Debug, Clone, Serialize)]
pub struct SignalRecord {
    pub symbol: String,
    pub direction: Direction,
    pub classification: Classification,
    pub signal_date: NaiveDate,
    pub breakout_date: NaiveDate,
    pub age: usize,
    pub composite: f64,
    /// Normalised components in the order of [`COMPONENT_NAMES`].
    pub components: [f64; 5],
    pub rigidity: f64,
    /// Price returned inside the zone within the false-breakout window (measured
    /// with hindsight, for evaluation only).
    pub false_breakout: bool,
    /// One entry per configured horizon; `None` when data ended first.
    pub returns: Vec<Option<TradeReturn>>,
}

#[derive(Debug, Clone)]
pub struct BacktestOutput {
    pub horizons: Vec<usize>,
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub symbols_tested: usize,
    /// First-sighting records per (event, classification).
    pub records: Vec<SignalRecord>,
    /// The best eligible (FRESH/DEVELOPING) signal per stock per simulated day,
    /// used to evaluate the daily top-N list.
    pub daily_eligible: Vec<SignalRecord>,
}

/// Dump every record to CSV (one row per record, two columns per horizon).
pub fn write_records_csv(path: &Path, out: &BacktestOutput) -> Result<()> {
    if let Some(parent) = path.parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent)?;
        }
    }
    let mut w = csv::Writer::from_path(path)?;
    let mut header: Vec<String> = vec![
        "symbol".into(),
        "direction".into(),
        "classification".into(),
        "signal_date".into(),
        "breakout_date".into(),
        "age".into(),
        "composite".into(),
        "rigidity".into(),
        "false_breakout".into(),
    ];
    for name in COMPONENT_NAMES {
        header.push(format!("c_{name}"));
    }
    for h in &out.horizons {
        header.push(format!("gross_{h}d"));
        header.push(format!("net_{h}d"));
    }
    w.write_record(&header)?;

    for r in &out.records {
        let mut row: Vec<String> = vec![
            r.symbol.clone(),
            r.direction.to_string(),
            r.classification.to_string(),
            r.signal_date.to_string(),
            r.breakout_date.to_string(),
            r.age.to_string(),
            format!("{:.3}", r.composite),
            format!("{:.2}", r.rigidity),
            r.false_breakout.to_string(),
        ];
        for c in r.components {
            row.push(format!("{c:.4}"));
        }
        for t in &r.returns {
            match t {
                Some(t) => {
                    row.push(format!("{:.6}", t.gross));
                    row.push(format!("{:.6}", t.net));
                }
                None => {
                    row.push(String::new());
                    row.push(String::new());
                }
            }
        }
        w.write_record(&row)?;
    }
    w.flush()?;
    Ok(())
}
