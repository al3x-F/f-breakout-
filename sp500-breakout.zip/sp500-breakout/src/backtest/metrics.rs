//! Performance statistics for a backtest (spec section 11).
//!
//! Everything is computed on **net** (after-cost) direction-adjusted returns
//! unless stated otherwise. "Hit rate" follows the spec's wording: the share of
//! bullish breakouts followed by a positive price change, and of bearish
//! breakouts followed by a negative one (before costs).

use std::cmp::Ordering;
use std::collections::BTreeMap;

use chrono::NaiveDate;
use serde::Serialize;

use super::{BacktestOutput, SignalRecord};
use crate::config::Config;
use crate::scoring::COMPONENT_NAMES;
use crate::types::{Classification, Direction};
use crate::util::{mean, median, spearman, std_dev};

#[derive(Debug, Clone, Serialize)]
pub struct GroupStats {
    pub label: String,
    pub horizon: usize,
    pub n: usize,
    /// Share of signals whose price moved in the signalled direction (before costs).
    pub hit_rate: f64,
    pub mean_gross: f64,
    pub mean_net: f64,
    pub median_net: f64,
    pub std_net: f64,
    /// t-statistic of the mean net return (observations overlap; treat as indicative).
    pub t_stat: f64,
    /// Share of trades with a positive net return.
    pub net_win_rate: f64,
}

#[derive(Debug, Clone, Serialize)]
pub struct ScoreIc {
    pub horizon: usize,
    pub n: usize,
    /// Spearman correlation between composite score and net return.
    pub ic: f64,
}

#[derive(Debug, Clone, Serialize)]
pub struct FactorStats {
    pub name: &'static str,
    pub horizon: usize,
    pub n: usize,
    pub ic: f64,
    pub top_half_net: f64,
    pub bottom_half_net: f64,
}

#[derive(Debug, Clone, Serialize)]
pub struct ComboStats {
    pub name: String,
    pub horizon: usize,
    pub n: usize,
    pub mean_net: f64,
}

#[derive(Debug, Clone, Serialize)]
pub struct BacktestSummary {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub horizons: Vec<usize>,
    pub symbols_tested: usize,
    pub n_records: usize,
    pub n_eligible: usize,
    pub eligible: Vec<GroupStats>,
    pub by_direction: Vec<GroupStats>,
    pub by_class: Vec<GroupStats>,
    pub filter_comparison: Vec<GroupStats>,
    pub by_score_bucket: Vec<GroupStats>,
    pub daily_top_n: Vec<GroupStats>,
    pub daily_all: Vec<GroupStats>,
    pub score_ic: Vec<ScoreIc>,
    pub factors: Vec<FactorStats>,
    pub combos: Vec<ComboStats>,
    /// `(label, events, share that returned inside the zone within the window)`.
    pub false_breakout_rate: Vec<(String, usize, f64)>,
}

pub fn group_stats(label: &str, records: &[&SignalRecord], h_idx: usize, horizon: usize) -> Option<GroupStats> {
    let mut gross = Vec::new();
    let mut net = Vec::new();
    let mut hits = 0usize;
    for r in records {
        if let Some(Some(t)) = r.returns.get(h_idx) {
            gross.push(t.gross);
            net.push(t.net);
            if r.direction.sign() * t.price_return > 0.0 {
                hits += 1;
            }
        }
    }
    let n = net.len();
    if n == 0 {
        return None;
    }
    let mean_net = mean(&net);
    let sd = std_dev(&net);
    let t_stat = if n >= 2 && sd.is_finite() && sd > 0.0 { mean_net / (sd / (n as f64).sqrt()) } else { f64::NAN };
    let wins = net.iter().filter(|x| **x > 0.0).count();
    Some(GroupStats {
        label: label.to_string(),
        horizon,
        n,
        hit_rate: hits as f64 / n as f64,
        mean_gross: mean(&gross),
        mean_net,
        median_net: median(&net),
        std_net: sd,
        t_stat,
        net_win_rate: wins as f64 / n as f64,
    })
}

fn stats_for(label: &str, recs: &[&SignalRecord], horizons: &[usize]) -> Vec<GroupStats> {
    horizons
        .iter()
        .enumerate()
        .filter_map(|(hi, &h)| group_stats(label, recs, hi, h))
        .collect()
}

fn net_at(r: &SignalRecord, hi: usize) -> Option<f64> {
    r.returns.get(hi).and_then(|x| x.as_ref()).map(|t| t.net)
}

pub fn summarize(out: &BacktestOutput, cfg: &Config) -> BacktestSummary {
    let hs = &out.horizons;
    let eligible: Vec<&SignalRecord> = out.records.iter().filter(|r| r.classification.is_eligible()).collect();

    // by classification (first-sighting entries)
    let mut by_class = Vec::new();
    for c in Classification::all() {
        let recs: Vec<&SignalRecord> = out.records.iter().filter(|r| r.classification == c).collect();
        by_class.extend(stats_for(c.as_str(), &recs, hs));
    }

    // do the recency / extension filters help?
    let late: Vec<&SignalRecord> = out
        .records
        .iter()
        .filter(|r| matches!(r.classification, Classification::Extended | Classification::Fading))
        .collect();
    let mut filter_comparison = stats_for("FRESH+DEVELOPING (passes filters)", &eligible, hs);
    filter_comparison.extend(stats_for("EXTENDED+FADING (late entries)", &late, hs));

    let eligible_all = stats_for("FRESH+DEVELOPING", &eligible, hs);

    let mut by_direction = Vec::new();
    for d in Direction::both() {
        let recs: Vec<&SignalRecord> = eligible.iter().copied().filter(|r| r.direction == d).collect();
        by_direction.extend(stats_for(d.as_str(), &recs, hs));
    }

    // does a higher composite score mean better outcomes?
    let buckets: [(f64, f64, &str); 5] = [
        (0.0, 50.0, "score <50"),
        (50.0, 60.0, "score 50-60"),
        (60.0, 70.0, "score 60-70"),
        (70.0, 80.0, "score 70-80"),
        (80.0, 101.0, "score >=80"),
    ];
    let mut by_score_bucket = Vec::new();
    for (lo, hi, label) in buckets {
        let recs: Vec<&SignalRecord> =
            eligible.iter().copied().filter(|r| r.composite >= lo && r.composite < hi).collect();
        by_score_bucket.extend(stats_for(label, &recs, hs));
    }

    let mut score_ic = Vec::new();
    for (hi, &h) in hs.iter().enumerate() {
        let pairs: Vec<(f64, f64)> = eligible.iter().filter_map(|r| net_at(r, hi).map(|y| (r.composite, y))).collect();
        if pairs.len() >= 3 {
            let xs: Vec<f64> = pairs.iter().map(|p| p.0).collect();
            let ys: Vec<f64> = pairs.iter().map(|p| p.1).collect();
            score_ic.push(ScoreIc { horizon: h, n: pairs.len(), ic: spearman(&xs, &ys) });
        }
    }

    // the daily top-N list as it would actually have been traded
    let mut by_date: BTreeMap<NaiveDate, Vec<&SignalRecord>> = BTreeMap::new();
    for r in &out.daily_eligible {
        by_date.entry(r.signal_date).or_default().push(r);
    }
    let mut top_pool: Vec<&SignalRecord> = Vec::new();
    for (_, mut v) in by_date {
        v.sort_by(|a, b| b.composite.partial_cmp(&a.composite).unwrap_or(Ordering::Equal));
        v.truncate(cfg.backtest.daily_top_n);
        top_pool.extend(v);
    }
    let daily_label = format!("daily top-{} list (pooled)", cfg.backtest.daily_top_n);
    let daily_top_n = stats_for(&daily_label, &top_pool, hs);
    let all_daily: Vec<&SignalRecord> = out.daily_eligible.iter().collect();
    let daily_all = stats_for("all eligible, every day (pooled)", &all_daily, hs);

    // individual indicators: rank correlation and top-half vs bottom-half spread
    let mut factors = Vec::new();
    for k in 0..COMPONENT_NAMES.len() {
        for (hi, &h) in hs.iter().enumerate() {
            let pairs: Vec<(f64, f64)> =
                eligible.iter().filter_map(|r| net_at(r, hi).map(|y| (r.components[k], y))).collect();
            if pairs.len() < 3 {
                continue;
            }
            let xs: Vec<f64> = pairs.iter().map(|p| p.0).collect();
            let ys: Vec<f64> = pairs.iter().map(|p| p.1).collect();
            let med = median(&xs);
            let (mut top, mut bottom) = (Vec::new(), Vec::new());
            for &(x, y) in &pairs {
                if x >= med {
                    top.push(y);
                } else {
                    bottom.push(y);
                }
            }
            factors.push(FactorStats {
                name: COMPONENT_NAMES[k],
                horizon: h,
                n: pairs.len(),
                ic: spearman(&xs, &ys),
                top_half_net: mean(&top),
                bottom_half_net: mean(&bottom),
            });
        }
    }

    // combinations: both components at or above their medians
    let mut combos = Vec::new();
    for a in 0..COMPONENT_NAMES.len() {
        for b in (a + 1)..COMPONENT_NAMES.len() {
            for (hi, &h) in hs.iter().enumerate() {
                let rows: Vec<(f64, f64, f64)> = eligible
                    .iter()
                    .filter_map(|r| net_at(r, hi).map(|y| (r.components[a], r.components[b], y)))
                    .collect();
                if rows.len() < 3 {
                    continue;
                }
                let ma = median(&rows.iter().map(|x| x.0).collect::<Vec<_>>());
                let mb = median(&rows.iter().map(|x| x.1).collect::<Vec<_>>());
                let sel: Vec<f64> = rows.iter().filter(|x| x.0 >= ma && x.1 >= mb).map(|x| x.2).collect();
                combos.push(ComboStats {
                    name: format!("{} + {}", COMPONENT_NAMES[a], COMPONENT_NAMES[b]),
                    horizon: h,
                    n: sel.len(),
                    mean_net: mean(&sel),
                });
            }
        }
    }

    // false-breakout frequency among first-sighting breakouts
    let mut false_breakout_rate = Vec::new();
    let fresh: Vec<&SignalRecord> =
        out.records.iter().filter(|r| r.classification == Classification::Fresh).collect();
    if !fresh.is_empty() {
        let rate = fresh.iter().filter(|r| r.false_breakout).count() as f64 / fresh.len() as f64;
        false_breakout_rate.push(("all first-sighting breakouts".to_string(), fresh.len(), rate));
    }
    for d in Direction::both() {
        let v: Vec<&&SignalRecord> = fresh.iter().filter(|r| r.direction == d).collect();
        if !v.is_empty() {
            let rate = v.iter().filter(|r| r.false_breakout).count() as f64 / v.len() as f64;
            false_breakout_rate.push((format!("{d} first-sighting breakouts"), v.len(), rate));
        }
    }

    BacktestSummary {
        start: out.start,
        end: out.end,
        horizons: out.horizons.clone(),
        symbols_tested: out.symbols_tested,
        n_records: out.records.len(),
        n_eligible: eligible.len(),
        eligible: eligible_all,
        by_direction,
        by_class,
        filter_comparison,
        by_score_bucket,
        daily_top_n,
        daily_all,
        score_ic,
        factors,
        combos,
        false_breakout_rate,
    }
}

fn pct(x: f64) -> String {
    if x.is_finite() {
        format!("{:>7.2}%", x * 100.0)
    } else {
        format!("{:>8}", "n/a")
    }
}

fn table(out: &mut String, title: &str, rows: &[GroupStats], min_group: usize) {
    out.push_str(&format!("\n{title}\n"));
    if rows.is_empty() {
        out.push_str("  (no observations)\n");
        return;
    }
    out.push_str(&format!(
        "  {:>4}  {:<36} {:>6} {:>8} {:>8} {:>8} {:>8} {:>6}\n",
        "hor.", "group", "N", "hit", "gross", "net", "median", "t"
    ));
    for g in rows {
        out.push_str(&format!(
            "  {:>3}d  {:<36} {:>6} {} {} {} {} {:>6.2}{}\n",
            g.horizon,
            g.label,
            g.n,
            pct(g.hit_rate),
            pct(g.mean_gross),
            pct(g.mean_net),
            pct(g.median_net),
            g.t_stat,
            if g.n < min_group { "  (thin sample)" } else { "" }
        ));
    }
}

pub fn render(s: &BacktestSummary, min_group: usize) -> String {
    let mut o = String::new();
    o.push_str(&format!(
        "BACKTEST {} .. {}  |  {} symbols  |  {} first-sighting records ({} FRESH/DEVELOPING)  |  horizons {:?} sessions\n",
        s.start, s.end, s.symbols_tested, s.n_records, s.n_eligible, s.horizons
    ));
    o.push_str(
        "Signals fire after the close; trades enter at the next open and pay commission, spread, slippage\n\
         (and borrow on shorts). 'hit' = price moved in the signalled direction (before costs).\n",
    );

    table(&mut o, "1. FRESH + DEVELOPING signals (all directions)", &s.eligible, min_group);
    table(&mut o, "2. By direction", &s.by_direction, min_group);
    table(&mut o, "3. FRESH vs DEVELOPING vs the excluded classes (entry on first sighting in each state)", &s.by_class, min_group);
    table(&mut o, "4. Do the recency / extension filters help?", &s.filter_comparison, min_group);
    table(&mut o, "5. Composite score buckets (FRESH + DEVELOPING)", &s.by_score_bucket, min_group);
    table(&mut o, "6. The daily top-N list as it would have been traded", &s.daily_top_n, min_group);
    table(&mut o, "   ... versus every eligible signal", &s.daily_all, min_group);

    o.push_str("\n7. Does a higher composite score mean better outcomes? (Spearman IC vs net return)\n");
    if s.score_ic.is_empty() {
        o.push_str("  (not enough observations)\n");
    }
    for i in &s.score_ic {
        o.push_str(&format!("  {:>3}d  IC {:>7.3}  (N = {})\n", i.horizon, i.ic, i.n));
    }

    o.push_str("\n8. Individual indicators (components of the composite)\n");
    if s.factors.is_empty() {
        o.push_str("  (not enough observations)\n");
    } else {
        o.push_str(&format!(
            "  {:>4}  {:<12} {:>6} {:>8} {:>10} {:>10}\n",
            "hor.", "component", "N", "IC", "top half", "bottom half"
        ));
    }
    for f in &s.factors {
        o.push_str(&format!(
            "  {:>3}d  {:<12} {:>6} {:>8.3} {} {}\n",
            f.horizon,
            f.name,
            f.n,
            f.ic,
            pct(f.top_half_net),
            pct(f.bottom_half_net)
        ));
    }

    o.push_str("\n9. Indicator combinations (both components at/above their medians, mean net return)\n");
    if s.combos.is_empty() {
        o.push_str("  (not enough observations)\n");
    }
    for c in &s.combos {
        o.push_str(&format!("  {:>3}d  {:<26} N {:>5}  {}\n", c.horizon, c.name, c.n, pct(c.mean_net)));
    }

    o.push_str("\n10. False breakouts (closed back inside the zone within the false-breakout window)\n");
    if s.false_breakout_rate.is_empty() {
        o.push_str("  (no observations)\n");
    }
    for (label, n, rate) in &s.false_breakout_rate {
        o.push_str(&format!("  {:<34} N {:>5}  {:>6.1}%\n", label, n, rate * 100.0));
    }

    o.push_str(
        "\nCaveats: consecutive daily observations overlap, so t-statistics overstate significance; \
         delisted tickers are frequently missing from data vendors (residual survivorship bias); \
         results describe the past and say nothing certain about the future. Look for monotonic \
         improvement across score buckets and positive information coefficients rather than tuning \
         parameters until the numbers look good.\n",
    );
    o
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::backtest::TradeReturn;

    fn rec(class: Classification, dir: Direction, composite: f64, comp0: f64, price_ret: f64) -> SignalRecord {
        let gross = dir.sign() * price_ret;
        SignalRecord {
            symbol: "T".into(),
            direction: dir,
            classification: class,
            signal_date: NaiveDate::from_ymd_opt(2026, 1, 5).unwrap(),
            breakout_date: NaiveDate::from_ymd_opt(2026, 1, 5).unwrap(),
            age: 0,
            composite,
            components: [comp0, 0.5, 0.5, 0.5, 0.5],
            rigidity: 50.0,
            false_breakout: false,
            returns: vec![Some(TradeReturn { price_return: price_ret, gross, net: gross - 0.001 })],
        }
    }

    #[test]
    fn group_stats_basic_numbers() {
        let rs = vec![
            rec(Classification::Fresh, Direction::Long, 70.0, 0.5, 0.05),
            rec(Classification::Fresh, Direction::Long, 70.0, 0.5, -0.01),
            rec(Classification::Fresh, Direction::Short, 70.0, 0.5, -0.03), // short wins
            rec(Classification::Fresh, Direction::Short, 70.0, 0.5, 0.02),  // short loses
        ];
        let refs: Vec<&SignalRecord> = rs.iter().collect();
        let g = group_stats("x", &refs, 0, 5).unwrap();
        assert_eq!(g.n, 4);
        assert!((g.hit_rate - 0.5).abs() < 1e-12);
        // gross: 0.05, -0.01, 0.03, -0.02 => mean 0.0125
        assert!((g.mean_gross - 0.0125).abs() < 1e-12);
        assert!((g.mean_net - 0.0115).abs() < 1e-12);
        assert!(group_stats("x", &[], 0, 5).is_none());
    }

    #[test]
    fn higher_scores_with_better_returns_give_positive_ic_and_monotone_buckets() {
        let mut records = Vec::new();
        for i in 0..40 {
            let score = 45.0 + i as f64 * 1.2; // 45 .. 91.8
            let ret = (score - 60.0) / 1000.0; // better score -> better return
            records.push(rec(Classification::Fresh, Direction::Long, score, score / 100.0, ret));
        }
        let out = BacktestOutput {
            horizons: vec![5],
            start: NaiveDate::from_ymd_opt(2026, 1, 1).unwrap(),
            end: NaiveDate::from_ymd_opt(2026, 6, 1).unwrap(),
            symbols_tested: 3,
            daily_eligible: records.clone(),
            records,
        };
        let s = summarize(&out, &Config::default());
        assert_eq!(s.n_eligible, 40);
        assert!(s.score_ic[0].ic > 0.99);
        let means: Vec<f64> = s.by_score_bucket.iter().map(|g| g.mean_net).collect();
        assert!(means.len() >= 3);
        assert!(means.windows(2).all(|w| w[1] > w[0]));
        let comp0 = s.factors.iter().find(|f| f.name == "rigidity").unwrap();
        assert!(comp0.top_half_net > comp0.bottom_half_net);
        assert!(!s.combos.is_empty());
        let text = render(&s, 5);
        assert!(text.contains("BACKTEST") && text.contains("Spearman"));
    }

    #[test]
    fn late_entries_are_compared_separately() {
        let out = BacktestOutput {
            horizons: vec![5],
            start: NaiveDate::from_ymd_opt(2026, 1, 1).unwrap(),
            end: NaiveDate::from_ymd_opt(2026, 6, 1).unwrap(),
            symbols_tested: 1,
            records: vec![
                rec(Classification::Fresh, Direction::Long, 70.0, 0.5, 0.04),
                rec(Classification::Extended, Direction::Long, 70.0, 0.5, -0.02),
            ],
            daily_eligible: vec![],
        };
        let s = summarize(&out, &Config::default());
        assert_eq!(s.filter_comparison.len(), 2);
        assert!(s.filter_comparison[0].mean_net > s.filter_comparison[1].mean_net);
        assert!(s.daily_top_n.is_empty());
    }

    #[test]
    fn empty_output_does_not_panic() {
        let out = BacktestOutput {
            horizons: vec![5, 10],
            start: NaiveDate::from_ymd_opt(2026, 1, 1).unwrap(),
            end: NaiveDate::from_ymd_opt(2026, 6, 1).unwrap(),
            symbols_tested: 0,
            records: vec![],
            daily_eligible: vec![],
        };
        let text = render(&summarize(&out, &Config::default()), 5);
        assert!(text.contains("no observations"));
    }
}
