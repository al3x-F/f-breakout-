//! Transaction-cost model for hypothetical trades (spec section 11).

use crate::config::BacktestConfig;
use crate::types::Direction;

/// Round-trip cost assumptions, all in basis points.
#[derive(Debug, Clone, Copy)]
pub struct CostModel {
    /// Per side.
    pub commission_bps: f64,
    /// Full quoted bid-ask spread; half is crossed on entry and half on exit.
    pub spread_bps: f64,
    /// Per side (market impact / adverse fill on the open).
    pub slippage_bps: f64,
    /// Annualised short-borrow fee, charged pro rata to the holding period.
    pub borrow_bps_per_year: f64,
}

impl CostModel {
    pub fn from_config(cfg: &BacktestConfig) -> Self {
        Self {
            commission_bps: cfg.commission_bps,
            spread_bps: cfg.spread_bps,
            slippage_bps: cfg.slippage_bps,
            borrow_bps_per_year: cfg.borrow_bps_per_year,
        }
    }

    /// Total cost as a fraction of notional for a trade held `horizon_sessions`.
    ///
    /// `2 * commission + spread + 2 * slippage (+ borrow * horizon / 252 for shorts)`.
    pub fn round_trip_fraction(&self, dir: Direction, horizon_sessions: usize) -> f64 {
        let fixed = 2.0 * self.commission_bps + self.spread_bps + 2.0 * self.slippage_bps;
        let borrow = match dir {
            Direction::Short => self.borrow_bps_per_year * horizon_sessions as f64 / 252.0,
            Direction::Long => 0.0,
        };
        (fixed + borrow) / 10_000.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn long_pays_fixed_costs_only() {
        let m = CostModel { commission_bps: 1.0, spread_bps: 2.0, slippage_bps: 2.0, borrow_bps_per_year: 50.0 };
        // 2*1 + 2 + 2*2 = 8 bps
        assert!((m.round_trip_fraction(Direction::Long, 10) - 0.0008).abs() < 1e-12);
    }

    #[test]
    fn short_adds_pro_rata_borrow() {
        let m = CostModel { commission_bps: 1.0, spread_bps: 2.0, slippage_bps: 2.0, borrow_bps_per_year: 252.0 };
        // 8 bps + 252 * 20 / 252 = 20 bps => 28 bps
        assert!((m.round_trip_fraction(Direction::Short, 20) - 0.0028).abs() < 1e-12);
    }
}
