//! Persistent signal registry (spec section 12).
//!
//! Classification is always recomputed from price data, so the scanner itself is
//! stateless. The registry adds *memory across daily runs*:
//!
//! * the original breakout date of every detected breakout is recorded once and
//!   never re-announced as new (`first_seen` / event key = symbol|direction|breakout date);
//! * a previously FRESH or DEVELOPING breakout that has since become EXTENDED,
//!   FADING or FAILED is reported as a reclassification rather than silently
//!   disappearing from the ranking;
//! * old entries are pruned after `scan.registry_retention_days`.

use std::collections::{BTreeMap, HashSet};
use std::path::Path;

use chrono::{Duration, NaiveDate};
use serde::{Deserialize, Serialize};

use crate::error::Result;
use crate::signal::BreakoutSignal;
use crate::types::{Classification, Direction};

/// The slice of a [`BreakoutSignal`] the registry cares about.
#[derive(Debug, Clone)]
pub struct Observation {
    pub key: String,
    pub symbol: String,
    pub direction: Direction,
    pub breakout_date: NaiveDate,
    pub level: f64,
    pub classification: Classification,
    pub composite: f64,
}

impl Observation {
    pub fn from_signal(s: &BreakoutSignal) -> Self {
        Self {
            key: s.event_key(),
            symbol: s.symbol.clone(),
            direction: s.direction,
            breakout_date: s.breakout_date,
            level: s.level,
            classification: s.classification,
            composite: s.composite,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RegistryEntry {
    pub symbol: String,
    pub direction: Direction,
    pub breakout_date: NaiveDate,
    pub level: f64,
    pub first_seen: NaiveDate,
    pub last_seen: NaiveDate,
    pub first_classification: Classification,
    pub last_classification: Classification,
    pub peak_composite: f64,
    /// Was it in the main ranked list at the last scan?
    pub listed: bool,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Registry {
    pub entries: BTreeMap<String, RegistryEntry>,
    pub last_scan: Option<NaiveDate>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum ChangeKind {
    /// Eligible breakout seen for the first time.
    New,
    /// Classification differs from the previous scan.
    Reclassified,
}

#[derive(Debug, Clone, Serialize)]
pub struct Change {
    pub symbol: String,
    pub direction: Direction,
    pub breakout_date: NaiveDate,
    pub from: Option<Classification>,
    pub to: Classification,
    pub kind: ChangeKind,
    /// Was in the ranked list last time but is no longer eligible.
    pub dropped_from_list: bool,
}

impl Change {
    pub fn describe(&self) -> String {
        match (self.kind, self.from) {
            (ChangeKind::New, _) => format!(
                "NEW   {} {} (broke out {}): {}",
                self.symbol, self.direction, self.breakout_date, self.to
            ),
            (_, Some(from)) => format!(
                "{} {} {} (broke out {}): {} -> {}{}",
                if self.dropped_from_list { "DROP " } else { "MOVED" },
                self.symbol,
                self.direction,
                self.breakout_date,
                from,
                self.to,
                if self.dropped_from_list { "  [removed from ranking]" } else { "" }
            ),
            (_, None) => format!("{} {} {}", self.symbol, self.direction, self.to),
        }
    }
}

impl Registry {
    /// Load from `path`; a missing file yields an empty registry.
    pub fn load(path: &Path) -> Result<Registry> {
        if !path.exists() {
            return Ok(Registry::default());
        }
        let text = std::fs::read_to_string(path)?;
        Ok(serde_json::from_str(&text)?)
    }

    /// Atomic save (write to a temporary file, then rename).
    pub fn save(&self, path: &Path) -> Result<()> {
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                std::fs::create_dir_all(parent)?;
            }
        }
        let tmp = path.with_extension("json.tmp");
        std::fs::write(&tmp, serde_json::to_string_pretty(self)?)?;
        std::fs::rename(&tmp, path)?;
        Ok(())
    }

    /// Record this scan's observations and return what changed since the last one.
    ///
    /// `listed` holds the event keys that appear in the main ranked list.
    pub fn update(
        &mut self,
        as_of: NaiveDate,
        observations: &[Observation],
        listed: &HashSet<String>,
        retention_days: i64,
    ) -> Vec<Change> {
        let mut changes = Vec::new();
        for o in observations {
            let is_listed = listed.contains(&o.key);
            match self.entries.get_mut(&o.key) {
                Some(e) => {
                    if e.last_classification != o.classification {
                        changes.push(Change {
                            symbol: o.symbol.clone(),
                            direction: o.direction,
                            breakout_date: o.breakout_date,
                            from: Some(e.last_classification),
                            to: o.classification,
                            kind: ChangeKind::Reclassified,
                            dropped_from_list: e.listed && !o.classification.is_eligible(),
                        });
                        e.last_classification = o.classification;
                    }
                    e.last_seen = as_of;
                    e.level = o.level;
                    e.peak_composite = e.peak_composite.max(o.composite);
                    e.listed = is_listed;
                }
                None => {
                    if o.classification.is_eligible() {
                        changes.push(Change {
                            symbol: o.symbol.clone(),
                            direction: o.direction,
                            breakout_date: o.breakout_date,
                            from: None,
                            to: o.classification,
                            kind: ChangeKind::New,
                            dropped_from_list: false,
                        });
                    }
                    self.entries.insert(
                        o.key.clone(),
                        RegistryEntry {
                            symbol: o.symbol.clone(),
                            direction: o.direction,
                            breakout_date: o.breakout_date,
                            level: o.level,
                            first_seen: as_of,
                            last_seen: as_of,
                            first_classification: o.classification,
                            last_classification: o.classification,
                            peak_composite: o.composite,
                            listed: is_listed,
                        },
                    );
                }
            }
        }
        self.last_scan = Some(as_of);
        let cutoff = as_of - Duration::days(retention_days.max(1));
        self.entries.retain(|_, e| e.last_seen >= cutoff);
        changes
    }

    /// Original breakout date already on record for this event key, if any.
    pub fn first_seen(&self, key: &str) -> Option<NaiveDate> {
        self.entries.get(key).map(|e| e.first_seen)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn d(day: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(2026, 11, day).unwrap()
    }

    fn obs(class: Classification) -> Observation {
        Observation {
            key: "AAA|LONG|2026-11-09".to_string(),
            symbol: "AAA".to_string(),
            direction: Direction::Long,
            breakout_date: d(9),
            level: 100.0,
            classification: class,
            composite: 70.0,
        }
    }

    #[test]
    fn new_then_reclassified_then_dropped() {
        let mut reg = Registry::default();
        let key = "AAA|LONG|2026-11-09".to_string();

        let ch = reg.update(d(10), &[obs(Classification::Fresh)], &HashSet::from([key.clone()]), 90);
        assert_eq!(ch.len(), 1);
        assert_eq!(ch[0].kind, ChangeKind::New);

        // same classification again: nothing to report
        let ch = reg.update(d(11), &[obs(Classification::Fresh)], &HashSet::from([key.clone()]), 90);
        assert!(ch.is_empty());

        // FRESH -> DEVELOPING is a move but not a drop
        let ch = reg.update(d(12), &[obs(Classification::Developing)], &HashSet::from([key.clone()]), 90);
        assert_eq!(ch.len(), 1);
        assert!(!ch[0].dropped_from_list);

        // DEVELOPING -> EXTENDED removes it from the list
        let ch = reg.update(d(13), &[obs(Classification::Extended)], &HashSet::new(), 90);
        assert_eq!(ch.len(), 1);
        assert!(ch[0].dropped_from_list);
        assert_eq!(reg.first_seen(&key), Some(d(10)));
    }

    #[test]
    fn ineligible_first_sighting_is_not_announced() {
        let mut reg = Registry::default();
        let ch = reg.update(d(10), &[obs(Classification::Extended)], &HashSet::new(), 90);
        assert!(ch.is_empty());
        assert_eq!(reg.entries.len(), 1);
    }

    #[test]
    fn old_entries_are_pruned_and_roundtrip_works() {
        let mut reg = Registry::default();
        reg.update(d(2), &[obs(Classification::Fresh)], &HashSet::new(), 5);
        reg.update(d(20), &[], &HashSet::new(), 5);
        assert!(reg.entries.is_empty());

        reg.update(d(20), &[obs(Classification::Fresh)], &HashSet::new(), 5);
        let path = std::env::temp_dir().join(format!("sp500_registry_test_{}.json", std::process::id()));
        reg.save(&path).unwrap();
        let back = Registry::load(&path).unwrap();
        assert_eq!(back.entries.len(), 1);
        assert_eq!(back.last_scan, Some(d(20)));
        std::fs::remove_file(&path).ok();
    }
}
