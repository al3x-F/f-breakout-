//! Trading-volume abnormality (spec section 5). Daily volume only.

use serde::Serialize;

use crate::config::VolumeConfig;
use crate::util::clamp01;

/// Relative volume: today's volume divided by the mean of the *previous*
/// `window` sessions (today excluded). NaN until `window` sessions exist.
pub fn rvol_series(volume: &[f64], window: usize) -> Vec<f64> {
    let n = volume.len();
    let mut out = vec![f64::NAN; n];
    if window == 0 || n <= window {
        return out;
    }
    let mut sum: f64 = volume[..window].iter().sum();
    for i in window..n {
        let avg = sum / window as f64;
        out[i] = if avg > 0.0 { volume[i] / avg } else { f64::NAN };
        sum += volume[i] - volume[i - window];
    }
    out
}

/// Volume Z-score against the previous `window` sessions (today excluded):
/// `(V - mean) / sample_std`. A flat history yields 0 rather than infinity.
pub fn zscore_series(volume: &[f64], window: usize, use_log: bool) -> Vec<f64> {
    let n = volume.len();
    let mut out = vec![f64::NAN; n];
    if window < 2 || n <= window {
        return out;
    }
    let t = |v: f64| if use_log { v.max(1.0).ln() } else { v };
    let w = window as f64;
    for i in window..n {
        let hist = &volume[i - window..i];
        let mean = hist.iter().map(|&v| t(v)).sum::<f64>() / w;
        let var = hist.iter().map(|&v| (t(v) - mean) * (t(v) - mean)).sum::<f64>() / (w - 1.0);
        let sd = var.sqrt();
        out[i] = if sd > 0.0 { (t(volume[i]) - mean) / sd } else { 0.0 };
    }
    out
}

/// Normalised volume abnormality in `[0, 1]`. Both RVOL and the Z-score
/// contribute; each is capped so that one extreme print cannot dominate.
pub fn abnormality_score(rvol: f64, z: f64, cfg: &VolumeConfig) -> f64 {
    if !rvol.is_finite() || !z.is_finite() {
        return 0.0;
    }
    let s_r = clamp01((rvol - 1.0) / (cfg.rvol_cap - 1.0).max(1e-9));
    let s_z = clamp01(z / cfg.z_cap.max(1e-9));
    let wsum = cfg.rvol_weight + cfg.z_weight;
    if wsum <= 0.0 {
        return 0.0;
    }
    (cfg.rvol_weight * s_r + cfg.z_weight * s_z) / wsum
}

/// Coarse description of how unusual a session's activity was.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum ActivityLevel {
    UnusuallyHigh,
    Normal,
    UnusuallyLow,
}

/// Flag unusually high or low trading activity (spec 5: "unusually high or low").
pub fn activity_level(rvol: f64, z: f64, cfg: &VolumeConfig) -> ActivityLevel {
    if rvol.is_finite() && z.is_finite() {
        if rvol >= cfg.high_rvol && z >= 1.0 {
            return ActivityLevel::UnusuallyHigh;
        }
        if rvol <= cfg.low_rvol && z <= -1.0 {
            return ActivityLevel::UnusuallyLow;
        }
    }
    ActivityLevel::Normal
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rvol_uses_previous_window_only() {
        let mut v = vec![100.0; 20];
        v.push(250.0);
        let r = rvol_series(&v, 20);
        assert!(r[19].is_nan());
        assert!((r[20] - 2.5).abs() < 1e-12);
    }

    #[test]
    fn zscore_of_spike() {
        let mut v: Vec<f64> = (0..60).map(|i| 100.0 + (i % 5) as f64).collect();
        v.push(300.0);
        let z = zscore_series(&v, 60, false);
        assert!(z[60] > 10.0);
        assert!(z[59].is_nan());
    }

    #[test]
    fn flat_history_gives_zero_z() {
        let mut v = vec![100.0; 30];
        v.push(500.0);
        assert_eq!(zscore_series(&v, 30, false)[30], 0.0);
    }

    #[test]
    fn abnormality_is_bounded() {
        let cfg = VolumeConfig::default();
        assert_eq!(abnormality_score(100.0, 100.0, &cfg), 1.0);
        assert_eq!(abnormality_score(0.5, -2.0, &cfg), 0.0);
        assert_eq!(abnormality_score(f64::NAN, 1.0, &cfg), 0.0);
    }

    #[test]
    fn activity_levels() {
        let cfg = VolumeConfig::default();
        assert_eq!(activity_level(2.0, 2.0, &cfg), ActivityLevel::UnusuallyHigh);
        assert_eq!(activity_level(0.3, -1.5, &cfg), ActivityLevel::UnusuallyLow);
        assert_eq!(activity_level(1.0, 0.0, &cfg), ActivityLevel::Normal);
    }
}
