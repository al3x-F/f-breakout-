//! Central, user-adjustable configuration.
//!
//! Every threshold, weight and lookback used anywhere in the system lives here
//! so that the scanner is "objective, configurable and consistently applied"
//! (spec 7.5). Each struct has a `Default` that matches the initial values in
//! the project specification; a TOML file only needs to override what it wants
//! to change.
//!
//! **No secrets live here.** API keys are read from environment variables whose
//! *names* are configured in [`DataConfig`].

use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use crate::error::{Error, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ProviderKind {
    /// Financial Modeling Prep (needs `FMP_API_KEY`).
    Fmp,
    /// Local CSV files (no key needed).
    Csv,
    /// Deterministic generated data for demos and tests (no key needed).
    Synthetic,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct Config {
    pub data: DataConfig,
    pub indicators: IndicatorConfig,
    pub volume: VolumeConfig,
    pub levels: LevelConfig,
    pub rigidity: RigidityConfig,
    pub breakout: BreakoutConfig,
    pub classification: ClassificationConfig,
    pub consolidation: ConsolidationConfig,
    pub market: MarketConfig,
    pub scoring: ScoringConfig,
    pub scan: ScanConfig,
    pub backtest: BacktestConfig,
    pub output: OutputConfig,
}

/// Data acquisition and integrity (spec section 2).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct DataConfig {
    pub provider: ProviderKind,
    /// Symbol of the S&P 500 index used for the market-trend filter.
    pub index_symbol: String,
    /// Sessions of history analysed per stock (~2 years).
    pub history_sessions: usize,
    /// Calendar days requested from the provider to cover `history_sessions`.
    pub history_calendar_days: i64,
    /// Stocks with fewer sessions than this are skipped.
    pub min_history_sessions: usize,
    /// Name of the environment variable holding the FMP API key.
    pub api_key_env: String,
    pub fmp_base_url: String,
    /// `dividend-adjusted` (default) or `full` (split-adjusted only).
    pub fmp_price_endpoint: String,
    pub request_delay_ms: u64,
    pub max_retries: u32,
    /// Parallel download threads.
    pub concurrency: usize,
    pub cache_dir: PathBuf,
    pub csv_dir: PathBuf,
    pub constituents_file: PathBuf,
    /// A same-day bar is only treated as complete this many minutes after 16:00 ET.
    pub market_close_buffer_minutes: i64,
    /// Max share of index sessions a stock may lack before it is rejected.
    pub max_missing_fraction: f64,
    pub recent_window: usize,
    /// Missing sessions tolerated inside `recent_window`.
    pub max_recent_missing: usize,
    /// Single-day moves larger than this are flagged as anomalies (possible
    /// unadjusted split).
    pub max_abs_daily_return: f64,
}

impl Default for DataConfig {
    fn default() -> Self {
        Self {
            provider: ProviderKind::Fmp,
            index_symbol: "^GSPC".to_string(),
            history_sessions: 504,
            history_calendar_days: 790,
            min_history_sessions: 260,
            api_key_env: "FMP_API_KEY".to_string(),
            fmp_base_url: "https://financialmodelingprep.com/stable".to_string(),
            fmp_price_endpoint: "dividend-adjusted".to_string(),
            request_delay_ms: 60,
            max_retries: 4,
            concurrency: 8,
            cache_dir: PathBuf::from("cache"),
            csv_dir: PathBuf::from("data/csv"),
            constituents_file: PathBuf::from("data/constituents.csv"),
            market_close_buffer_minutes: 20,
            max_missing_fraction: 0.03,
            recent_window: 20,
            max_recent_missing: 0,
            max_abs_daily_return: 0.45,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct IndicatorConfig {
    pub rsi_period: usize,
    pub atr_period: usize,
    pub bb_period: usize,
    pub bb_std: f64,
}

impl Default for IndicatorConfig {
    fn default() -> Self {
        Self { rsi_period: 14, atr_period: 14, bb_period: 20, bb_std: 2.0 }
    }
}

/// Volume abnormality (spec section 5).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct VolumeConfig {
    /// RVOL denominator window (previous N completed sessions).
    pub rvol_window: usize,
    /// Window for the historical mean / standard deviation in the Z-score.
    pub z_window: usize,
    /// Compute the Z-score on ln(volume). Off by default to follow the spec literally.
    pub z_use_log: bool,
    /// RVOL at which the RVOL sub-score saturates at 1.
    pub rvol_cap: f64,
    /// Z at which the Z sub-score saturates at 1.
    pub z_cap: f64,
    pub rvol_weight: f64,
    pub z_weight: f64,
    pub high_rvol: f64,
    pub low_rvol: f64,
}

impl Default for VolumeConfig {
    fn default() -> Self {
        Self {
            rvol_window: 20,
            z_window: 60,
            z_use_log: false,
            rvol_cap: 3.0,
            z_cap: 3.0,
            rvol_weight: 0.5,
            z_weight: 0.5,
            high_rvol: 1.5,
            low_rvol: 0.5,
        }
    }
}

/// Swing / zone detection (spec section 3).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct LevelConfig {
    pub pivot_left: usize,
    pub pivot_right: usize,
    /// A pivot must stand out from its window by at least this many ATRs.
    pub pivot_min_prominence_atr: f64,
    /// Pivots within this many ATRs of each other are merged into one zone.
    pub cluster_width_atr: f64,
    /// Padding added to both zone edges, in ATRs.
    pub zone_pad_atr: f64,
    /// Half-life (sessions) of the recency weighting.
    pub recency_halflife: f64,
    /// Touches closer than this many bars are one interaction.
    pub touch_gap: usize,
    /// Sessions after an interaction over which rejection is measured.
    pub rejection_window: usize,
    pub min_interactions: usize,
    pub min_rigidity: f64,
    /// Only levels that are "established" may be broken out of.
    pub require_established: bool,
    pub established_min_span: usize,
    pub established_min_age: usize,
}

impl Default for LevelConfig {
    fn default() -> Self {
        Self {
            pivot_left: 5,
            pivot_right: 5,
            pivot_min_prominence_atr: 1.0,
            cluster_width_atr: 1.0,
            zone_pad_atr: 0.1,
            recency_halflife: 126.0,
            touch_gap: 3,
            rejection_window: 10,
            min_interactions: 2,
            min_rigidity: 30.0,
            require_established: true,
            established_min_span: 20,
            established_min_age: 30,
        }
    }
}

/// Rigidity score (spec section 4). The six weights are normalised internally.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct RigidityConfig {
    pub w_frequency: f64,
    pub w_rejection: f64,
    pub w_duration: f64,
    pub w_recency: f64,
    pub w_volume: f64,
    pub w_compression: f64,
    /// Quality-weighted touch count at which frequency reaches ~63%.
    pub frequency_scale: f64,
    /// Rejections smaller than this (ATRs) earn no credit ("tested without rejection").
    pub rejection_min_atr: f64,
    /// Rejection (ATRs) that earns full credit.
    pub rejection_target_atr: f64,
    /// Span (sessions) at which the duration component reaches ~63%.
    pub duration_scale: f64,
    /// RVOL at an interaction that earns full volume credit.
    pub volume_target_rvol: f64,
    /// Minimum step (ATRs) between successive reaction extremes to count as compression.
    pub compression_min_step_atr: f64,
}

impl Default for RigidityConfig {
    fn default() -> Self {
        Self {
            w_frequency: 0.25,
            w_rejection: 0.25,
            w_duration: 0.10,
            w_recency: 0.15,
            w_volume: 0.15,
            w_compression: 0.10,
            frequency_scale: 2.5,
            rejection_min_atr: 0.5,
            rejection_target_atr: 2.5,
            duration_scale: 60.0,
            volume_target_rvol: 2.0,
            compression_min_step_atr: 0.1,
        }
    }
}

/// Breakout detection (spec section 7.1-7.3).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct BreakoutConfig {
    /// Close must exceed the zone edge by this many ATRs.
    pub buffer_atr: f64,
    /// Breakouts older than this many completed sessions are discarded entirely.
    pub max_age: usize,
    /// Suppress a second break of the *same level* (same direction) within this
    /// many sessions of an earlier breakout, unless that earlier one has failed.
    /// Breaks of other levels are unaffected.
    pub cooldown_sessions: usize,
    pub min_rvol: f64,
    pub min_z: f64,
    pub require_volume: bool,
    pub require_momentum: bool,
    pub require_bollinger: bool,
    pub rsi_mid: f64,
    pub rsi_improve_lookback: usize,
    pub rsi_improve_min: f64,
    /// Bandwidth must grow by at least this fraction day-on-day to count as expanding.
    pub bb_expand_min: f64,
    /// Sessions a breakout must hold beyond the level to become CONFIRMED.
    pub confirm_sessions: usize,
    /// A return inside the zone within this many sessions marks a false breakout.
    pub false_breakout_sessions: usize,
    /// How far (ATRs) back inside the zone a close must be to count as a failure.
    pub failure_buffer_atr: f64,
}

impl Default for BreakoutConfig {
    fn default() -> Self {
        Self {
            buffer_atr: 0.25,
            max_age: 40,
            cooldown_sessions: 10,
            min_rvol: 1.5,
            min_z: 1.0,
            require_volume: true,
            require_momentum: true,
            require_bollinger: true,
            rsi_mid: 50.0,
            rsi_improve_lookback: 3,
            rsi_improve_min: 3.0,
            bb_expand_min: 0.0,
            confirm_sessions: 2,
            false_breakout_sessions: 5,
            failure_buffer_atr: 0.0,
        }
    }
}

/// Opportunity classification (spec section 7.4-7.5).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ClassificationConfig {
    pub fresh_max_age: usize,
    pub developing_max_age: usize,
    pub fresh_max_extension_atr: f64,
    /// Extension (ATRs beyond the level) at which a breakout becomes EXTENDED.
    pub extended_atr: f64,
    /// Number of fading symptoms (of three) needed to classify as FADING.
    pub fading_min_signals: usize,
    pub fading_rsi_drop: f64,
    pub fading_rvol_floor: f64,
    pub fading_pullback_atr: f64,
    /// Sessions over which post-breakout volume is averaged.
    pub follow_window: usize,
    pub developing_min_rvol: f64,

    pub continuation_enabled: bool,
    pub cont_min_base: usize,
    pub cont_max_base: usize,
    pub cont_max_range_atr: f64,
    pub cont_resume_max_age: usize,
    pub cont_resume_buffer_atr: f64,
    pub cont_min_rvol: f64,
    pub cont_max_total_extension_atr: f64,
    pub cont_max_trigger_extension_atr: f64,
}

impl Default for ClassificationConfig {
    fn default() -> Self {
        Self {
            fresh_max_age: 5,
            developing_max_age: 15,
            fresh_max_extension_atr: 1.5,
            extended_atr: 3.0,
            fading_min_signals: 2,
            fading_rsi_drop: 5.0,
            fading_rvol_floor: 0.9,
            fading_pullback_atr: 1.0,
            follow_window: 3,
            developing_min_rvol: 1.0,
            continuation_enabled: true,
            cont_min_base: 4,
            cont_max_base: 20,
            cont_max_range_atr: 3.0,
            cont_resume_max_age: 3,
            cont_resume_buffer_atr: 0.1,
            cont_min_rvol: 1.2,
            cont_max_total_extension_atr: 6.0,
            cont_max_trigger_extension_atr: 1.5,
        }
    }
}

/// Consolidation analysis (spec section 8.2).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ConsolidationConfig {
    pub min_len: usize,
    pub max_len: usize,
    /// A window counts as consolidation while its high-low range stays under this many ATRs.
    pub max_range_atr: f64,
    pub duration_target: f64,
    pub touches_target: f64,
    /// Relative contraction (0.4 = 40%) that earns full credit.
    pub contraction_target: f64,
    pub w_duration: f64,
    pub w_tightness: f64,
    pub w_touches: f64,
    pub w_volume: f64,
    pub w_volatility: f64,
}

impl Default for ConsolidationConfig {
    fn default() -> Self {
        Self {
            min_len: 8,
            max_len: 60,
            max_range_atr: 6.0,
            duration_target: 30.0,
            touches_target: 3.0,
            contraction_target: 0.4,
            w_duration: 0.25,
            w_tightness: 0.25,
            w_touches: 0.15,
            w_volume: 0.15,
            w_volatility: 0.20,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct MarketConfig {
    pub fast_period: usize,
    pub slow_period: usize,
}

impl Default for MarketConfig {
    fn default() -> Self {
        Self { fast_period: 50, slow_period: 200 }
    }
}

/// Composite scoring (spec section 9). The five weights are normalised internally.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ScoringConfig {
    pub w_rigidity: f64,
    pub w_volume: f64,
    pub w_rsi: f64,
    pub w_bollinger: f64,
    pub w_magnitude: f64,

    /// Close distance beyond the level (ATRs) at the breakout bar that earns full magnitude credit.
    pub magnitude_target_atr: f64,
    pub rsi_level_lo: f64,
    pub rsi_level_hi: f64,
    pub rsi_slope_target: f64,
    pub rsi_slope_lookback: usize,
    pub rsi_level_weight: f64,
    pub bb_expand_target: f64,
    pub bb_squeeze_window: usize,
    pub bb_w_expansion: f64,
    pub bb_w_squeeze: f64,
    pub bb_w_band_break: f64,
    /// Share of the volume component taken from the breakout bar (rest = follow-through).
    pub volume_breakout_weight: f64,

    // Additive point adjustments applied after the weighted base score.
    pub trend_bonus: f64,
    pub countertrend_penalty: f64,
    pub neutral_trend_penalty: f64,
    pub consolidation_bonus_max: f64,
    pub extension_free_atr: f64,
    pub extension_penalty_per_atr: f64,
    pub age_penalty_per_session: f64,
    pub momentum_penalty: f64,
    pub follow_through_penalty: f64,
    pub continuation_penalty: f64,
}

impl Default for ScoringConfig {
    fn default() -> Self {
        Self {
            w_rigidity: 0.30,
            w_volume: 0.25,
            w_rsi: 0.15,
            w_bollinger: 0.15,
            w_magnitude: 0.15,
            magnitude_target_atr: 1.5,
            rsi_level_lo: 45.0,
            rsi_level_hi: 65.0,
            rsi_slope_target: 10.0,
            rsi_slope_lookback: 3,
            rsi_level_weight: 0.6,
            bb_expand_target: 0.6,
            bb_squeeze_window: 126,
            bb_w_expansion: 0.45,
            bb_w_squeeze: 0.35,
            bb_w_band_break: 0.20,
            volume_breakout_weight: 0.65,
            trend_bonus: 3.0,
            countertrend_penalty: 8.0,
            neutral_trend_penalty: 0.0,
            consolidation_bonus_max: 6.0,
            extension_free_atr: 1.0,
            extension_penalty_per_atr: 4.0,
            age_penalty_per_session: 1.0,
            momentum_penalty: 6.0,
            follow_through_penalty: 3.0,
            continuation_penalty: 3.0,
        }
    }
}

impl ScoringConfig {
    /// Weights in the order rigidity, volume, RSI, Bollinger, magnitude, normalised to sum to 1.
    pub fn weights(&self) -> [f64; 5] {
        let w = [self.w_rigidity, self.w_volume, self.w_rsi, self.w_bollinger, self.w_magnitude];
        let s: f64 = w.iter().sum();
        if s <= 0.0 {
            return [0.2; 5];
        }
        [w[0] / s, w[1] / s, w[2] / s, w[3] / s, w[4] / s]
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ScanConfig {
    pub top_n: usize,
    /// Keep only the best-scoring eligible breakout per ticker.
    pub one_per_symbol: bool,
    pub registry_path: PathBuf,
    pub registry_retention_days: i64,
    /// Candles drawn on each chart.
    pub chart_candles: usize,
    /// Restrict the universe to the first N constituents (debugging).
    pub universe_limit: Option<usize>,
}

impl Default for ScanConfig {
    fn default() -> Self {
        Self {
            top_n: 10,
            one_per_symbol: true,
            registry_path: PathBuf::from("state/signals.json"),
            registry_retention_days: 90,
            chart_candles: 160,
            universe_limit: None,
        }
    }
}

/// Backtesting (spec section 11).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct BacktestConfig {
    /// Sessions of history visible to the scanner on each simulated day.
    pub lookback_sessions: usize,
    /// Default number of sessions simulated when no explicit start date is given.
    pub test_sessions: usize,
    /// Run the scanner every N sessions (1 = every session).
    pub signal_step: usize,
    pub horizons: Vec<usize>,
    pub commission_bps: f64,
    /// Full quoted bid-ask spread in bps (half is paid on entry, half on exit).
    pub spread_bps: f64,
    pub slippage_bps: f64,
    /// Annualised short-borrow cost, charged pro rata for short signals.
    pub borrow_bps_per_year: f64,
    pub min_group_size: usize,
    pub use_historical_membership: bool,
    pub daily_top_n: usize,
}

impl Default for BacktestConfig {
    fn default() -> Self {
        Self {
            lookback_sessions: 504,
            test_sessions: 252,
            signal_step: 1,
            horizons: vec![5, 10, 20],
            commission_bps: 1.0,
            spread_bps: 2.0,
            slippage_bps: 2.0,
            borrow_bps_per_year: 50.0,
            min_group_size: 5,
            use_historical_membership: true,
            daily_top_n: 10,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct OutputConfig {
    pub dir: PathBuf,
    pub write_json: bool,
    pub write_csv: bool,
    pub write_charts: bool,
}

impl Default for OutputConfig {
    fn default() -> Self {
        Self { dir: PathBuf::from("output"), write_json: true, write_csv: true, write_charts: true }
    }
}

impl Config {
    /// Load configuration from `path`, or from `./config.toml` if present, or fall back to defaults.
    pub fn load(path: Option<&Path>) -> Result<Config> {
        let cfg = match path {
            Some(p) => {
                let text = std::fs::read_to_string(p)
                    .map_err(|e| Error::Config(format!("cannot read {}: {e}", p.display())))?;
                toml::from_str::<Config>(&text)?
            }
            None => {
                let default_path = Path::new("config.toml");
                if default_path.exists() {
                    let text = std::fs::read_to_string(default_path)?;
                    toml::from_str::<Config>(&text)?
                } else {
                    Config::default()
                }
            }
        };
        cfg.validate()?;
        Ok(cfg)
    }

    pub fn validate(&self) -> Result<()> {
        let bad = |msg: &str| Err(Error::Config(msg.to_string()));

        if self.indicators.rsi_period < 2
            || self.indicators.atr_period < 2
            || self.indicators.bb_period < 2
        {
            return bad("indicator periods must be at least 2");
        }
        if self.volume.rvol_window < 2 || self.volume.z_window < 3 {
            return bad("volume.rvol_window must be >= 2 and volume.z_window >= 3");
        }
        if self.levels.pivot_left == 0 || self.levels.pivot_right == 0 {
            return bad("levels.pivot_left and levels.pivot_right must be >= 1");
        }
        if self.levels.cluster_width_atr <= 0.0 || self.levels.recency_halflife <= 0.0 {
            return bad("levels.cluster_width_atr and levels.recency_halflife must be positive");
        }
        if self.rigidity.rejection_target_atr <= self.rigidity.rejection_min_atr {
            return bad("rigidity.rejection_target_atr must exceed rigidity.rejection_min_atr");
        }
        if self.rigidity.volume_target_rvol <= 1.0 {
            return bad("rigidity.volume_target_rvol must exceed 1.0");
        }
        let rigidity_w = self.rigidity.w_frequency
            + self.rigidity.w_rejection
            + self.rigidity.w_duration
            + self.rigidity.w_recency
            + self.rigidity.w_volume
            + self.rigidity.w_compression;
        if rigidity_w <= 0.0 {
            return bad("rigidity weights must sum to a positive number");
        }
        let sw: f64 = self.scoring.weights().iter().sum();
        if !(sw > 0.0) {
            return bad("scoring weights must sum to a positive number");
        }
        if self.classification.fresh_max_age > self.classification.developing_max_age {
            return bad("classification.fresh_max_age must be <= developing_max_age");
        }
        if self.breakout.max_age < self.classification.developing_max_age {
            return bad("breakout.max_age must be >= classification.developing_max_age");
        }
        if self.classification.follow_window == 0 {
            return bad("classification.follow_window must be >= 1");
        }
        if self.classification.cont_min_base == 0
            || self.classification.cont_min_base > self.classification.cont_max_base
        {
            return bad("classification.cont_min_base must be in 1..=cont_max_base");
        }
        if self.market.fast_period >= self.market.slow_period {
            return bad("market.fast_period must be smaller than market.slow_period");
        }
        if self.consolidation.min_len == 0 || self.consolidation.min_len > self.consolidation.max_len
        {
            return bad("consolidation.min_len must be in 1..=max_len");
        }
        if self.backtest.horizons.is_empty() || self.backtest.horizons.contains(&0) {
            return bad("backtest.horizons must be non-empty and contain positive integers");
        }
        if self.backtest.signal_step == 0 {
            return bad("backtest.signal_step must be >= 1");
        }
        if self.data.concurrency == 0 {
            return bad("data.concurrency must be >= 1");
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_are_valid() {
        Config::default().validate().expect("default config must validate");
    }

    #[test]
    fn scoring_weights_normalise() {
        let w = ScoringConfig::default().weights();
        assert!((w.iter().sum::<f64>() - 1.0).abs() < 1e-12);
        assert!((w[0] - 0.30).abs() < 1e-12);
    }

    #[test]
    fn partial_toml_overrides_only_named_fields() {
        let cfg: Config = toml::from_str("[breakout]\nbuffer_atr = 0.5\n").unwrap();
        assert_eq!(cfg.breakout.buffer_atr, 0.5);
        assert_eq!(cfg.breakout.min_rvol, BreakoutConfig::default().min_rvol);
        assert_eq!(cfg.scan.top_n, 10);
    }
}
