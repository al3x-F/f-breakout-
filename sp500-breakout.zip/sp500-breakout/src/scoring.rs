//! Composite 0-100 breakout score (spec section 9).
//!
//! ```text
//! composite = clamp( 100 * sum_i( w_i * c_i )  +  adjustments, 0, 100 )
//! ```
//!
//! * Five **components** `c_i` are each normalised to `[0, 1]` with capped or
//!   saturating transforms (so no single extreme measurement can dominate) and
//!   combined with the configurable weights `w_i` (default 30/25/15/15/15).
//! * **Adjustments** are explicit, additive point changes: market-trend
//!   alignment, consolidation bonus, and penalties for extension, staleness,
//!   contradicting momentum, weak follow-through and continuation setups.
//!   Keeping them separate makes every score fully explainable.
//!
//! Eligibility (FRESH / DEVELOPING) is decided by the classifier, *never* by
//! this score: a high composite cannot promote an EXTENDED, FADING or FAILED
//! signal into the ranking.

use serde::Serialize;

use crate::breakout::classifier::Evaluation;
use crate::breakout::context::SeriesContext;
use crate::breakout::detector::BreakoutEvent;
use crate::config::Config;
use crate::consolidation::ConsolidationMetrics;
use crate::market::MarketState;
use crate::types::{Direction, TrendAlignment};
use crate::util::{clamp01, mean_finite};
use crate::volume::abnormality_score;

pub const COMPONENT_NAMES: [&str; 5] = ["rigidity", "volume", "rsi", "bollinger", "magnitude"];

/// Normalised component scores, each in `[0, 1]`.
#[derive(Debug, Clone, Copy, Serialize)]
pub struct ScoreComponents {
    pub rigidity: f64,
    pub volume: f64,
    pub rsi: f64,
    pub bollinger: f64,
    pub magnitude: f64,
}

impl ScoreComponents {
    /// In the same order as [`COMPONENT_NAMES`] and `ScoringConfig::weights()`.
    pub fn as_array(&self) -> [f64; 5] {
        [self.rigidity, self.volume, self.rsi, self.bollinger, self.magnitude]
    }
}

/// Additive point adjustments (negative = penalty).
#[derive(Debug, Clone, Copy, Default, Serialize)]
pub struct ScoreAdjustments {
    pub trend: f64,
    pub consolidation: f64,
    pub extension: f64,
    pub age: f64,
    pub momentum: f64,
    pub follow_through: f64,
    pub continuation: f64,
}

impl ScoreAdjustments {
    pub fn total(&self) -> f64 {
        self.trend
            + self.consolidation
            + self.extension
            + self.age
            + self.momentum
            + self.follow_through
            + self.continuation
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct ScoreBreakdown {
    pub components: ScoreComponents,
    /// Normalised weights actually used.
    pub weights: [f64; 5],
    /// `100 * weight * component` per component.
    pub points: [f64; 5],
    /// Weighted sum before adjustments (0-100).
    pub base: f64,
    pub adjustments: ScoreAdjustments,
    /// Final score, clamped to 0-100.
    pub composite: f64,
}

pub fn score(
    ctx: &SeriesContext,
    ev: &BreakoutEvent,
    eval: &Evaluation,
    cons: &ConsolidationMetrics,
    market: &MarketState,
    cfg: &Config,
) -> ScoreBreakdown {
    let sc = &cfg.scoring;
    let dir = ev.direction;
    let b = ev.idx;
    let e = ctx.len() - 1;

    // 1. rigidity -----------------------------------------------------------
    let rigidity = clamp01(ev.stats.rigidity / 100.0);

    // 2. volume abnormality: breakout bar plus follow-through -------------------
    let breakout_abn = abnormality_score(ev.rvol, ev.volume_z, &cfg.volume);
    let volume = if eval.age >= 1 {
        let start = (e + 1).saturating_sub(cfg.classification.follow_window).max(b + 1);
        let vals: Vec<f64> = (start..=e)
            .map(|j| abnormality_score(ctx.rvol[j], ctx.vz[j], &cfg.volume))
            .collect();
        let follow = if vals.is_empty() { breakout_abn } else { mean_finite(&vals) };
        sc.volume_breakout_weight * breakout_abn + (1.0 - sc.volume_breakout_weight) * follow
    } else {
        breakout_abn
    };
    let volume = clamp01(volume);

    // 3. RSI momentum: level (above 50 and rising) + slope --------------------
    //    Direction-adjusted, so SHORT uses 100 - RSI. High (even overbought)
    //    readings keep full credit: they do not invalidate a breakout.
    let now = ctx.dir_rsi(dir, e);
    let lb = sc.rsi_slope_lookback.min(e);
    let before = ctx.dir_rsi(dir, e - lb);
    let level = clamp01((now - sc.rsi_level_lo) / (sc.rsi_level_hi - sc.rsi_level_lo).max(1e-9));
    let slope = clamp01((now - before) / sc.rsi_slope_target.max(1e-9));
    let rsi = clamp01(sc.rsi_level_weight * level + (1.0 - sc.rsi_level_weight) * slope);

    // 4. Bollinger expansion after a squeeze -------------------------------------
    let bw_pre = ctx.bb.bandwidth[b - 1];
    let bw_now = ctx.bb.bandwidth[e];
    let growth = if bw_pre.is_finite() && bw_pre > 0.0 && bw_now.is_finite() { bw_now / bw_pre - 1.0 } else { 0.0 };
    let expansion = clamp01(growth / sc.bb_expand_target.max(1e-9));
    let squeeze = {
        let hi = b - 1;
        let lo = (hi + 1).saturating_sub(sc.bb_squeeze_window);
        let vals: Vec<f64> = ctx.bb.bandwidth[lo..=hi].iter().copied().filter(|v| v.is_finite()).collect();
        if vals.len() >= 20 && bw_pre.is_finite() {
            let rank = vals.iter().filter(|&&v| v <= bw_pre).count() as f64 / vals.len() as f64;
            clamp01(1.0 - rank)
        } else {
            0.5
        }
    };
    let beyond_band = |i: usize| match dir {
        Direction::Long => ctx.bars[i].close > ctx.bb.upper[i],
        Direction::Short => ctx.bars[i].close < ctx.bb.lower[i],
    };
    let band_break = if beyond_band(b) || beyond_band(e) { 1.0 } else { 0.0 };
    let bw_wsum = sc.bb_w_expansion + sc.bb_w_squeeze + sc.bb_w_band_break;
    let bollinger = if bw_wsum > 0.0 {
        clamp01((sc.bb_w_expansion * expansion + sc.bb_w_squeeze * squeeze + sc.bb_w_band_break * band_break) / bw_wsum)
    } else {
        0.0
    };

    // 5. breakout magnitude: how decisively the breakout bar closed beyond the level
    let buf = cfg.breakout.buffer_atr;
    let magnitude = clamp01((ev.distance_atr - buf) / (sc.magnitude_target_atr - buf).max(1e-9));

    let components = ScoreComponents { rigidity, volume, rsi, bollinger, magnitude };
    let weights = sc.weights();
    let arr = components.as_array();
    let mut points = [0.0f64; 5];
    for i in 0..5 {
        points[i] = 100.0 * weights[i] * clamp01(arr[i]);
    }
    let base: f64 = points.iter().sum();

    // Adjustments --------------------------------------------------------------------
    // For continuation setups, recency and extension are measured from the
    // resumption trigger rather than from the original breakout.
    let (eff_age, eff_ext) = match &eval.continuation {
        Some(c) => (e.saturating_sub(c.resume_idx), c.extension_from_trigger_atr),
        None => (eval.age, eval.extension_atr),
    };

    let trend = match market.alignment(dir) {
        TrendAlignment::WithTrend => sc.trend_bonus,
        TrendAlignment::Countertrend => -sc.countertrend_penalty,
        TrendAlignment::Neutral => -sc.neutral_trend_penalty,
    };
    let adjustments = ScoreAdjustments {
        trend,
        consolidation: sc.consolidation_bonus_max * clamp01(cons.score),
        extension: -sc.extension_penalty_per_atr * (eff_ext - sc.extension_free_atr).max(0.0),
        age: -sc.age_penalty_per_session * eff_age.saturating_sub(cfg.classification.fresh_max_age) as f64,
        momentum: if eval.momentum_ok_now { 0.0 } else { -sc.momentum_penalty },
        follow_through: if eval.volume_ok_now { 0.0 } else { -sc.follow_through_penalty },
        continuation: if eval.continuation.is_some() { -sc.continuation_penalty } else { 0.0 },
    };

    let composite = (base + adjustments.total()).clamp(0.0, 100.0);
    ScoreBreakdown { components, weights, points, base, adjustments, composite }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn adjustments_sum() {
        let a = ScoreAdjustments { trend: 3.0, extension: -4.0, age: -2.0, ..Default::default() };
        assert_eq!(a.total(), -3.0);
    }

    #[test]
    fn components_order_matches_names() {
        let c = ScoreComponents { rigidity: 0.1, volume: 0.2, rsi: 0.3, bollinger: 0.4, magnitude: 0.5 };
        assert_eq!(c.as_array(), [0.1, 0.2, 0.3, 0.4, 0.5]);
        assert_eq!(COMPONENT_NAMES.len(), 5);
    }
}
