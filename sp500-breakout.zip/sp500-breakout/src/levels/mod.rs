//! Support/resistance detection (spec sections 3 and 4).
//!
//! * [`pivots`]  - swing highs / lows (ATR-prominence filtered).
//! * [`zones`]   - volatility-adaptive price zones built from confirmed pivots.
//! * [`rigidity`] - interaction analysis and the 0-100 rigidity score.

pub mod pivots;
pub mod rigidity;
pub mod zones;

pub use pivots::{find_pivots, Pivot, PivotKind};
pub use rigidity::{
    compute_rigidity, find_interactions, Interaction, LevelStats, Maturity, RigidityComponents,
};
pub use zones::{build_zones, Role, Zone};
