//! Swing-high / swing-low detection on daily bars.

use crate::config::LevelConfig;
use crate::types::Bar;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PivotKind {
    High,
    Low,
}

#[derive(Debug, Clone, Copy)]
pub struct Pivot {
    /// Index of the pivot bar in the series.
    pub idx: usize,
    pub kind: PivotKind,
    /// The wick extreme (high for swing highs, low for swing lows).
    pub price: f64,
    /// ATR at the pivot bar.
    pub atr: f64,
    /// Relative volume at the pivot bar (1.0 when unavailable).
    pub rvol: f64,
}

/// Find fractal swing highs and lows.
///
/// A bar is a swing high when its high is `>=` every high in the `pivot_left`
/// bars before it and `>` every high in the `pivot_right` bars after it (the
/// asymmetry avoids duplicate pivots on plateaus). It must also stand out from
/// the lowest low in that window by `pivot_min_prominence_atr` ATRs so that
/// insignificant wiggles are ignored. Swing lows mirror this.
///
/// **No look-ahead:** a pivot at `i` is only *known* once bar `i + pivot_right`
/// has completed. Callers that analyse "as of bar t" must therefore only use
/// pivots with `idx + pivot_right < t`; `zones::build_zones` enforces this.
pub fn find_pivots(bars: &[Bar], atr: &[f64], rvol: &[f64], cfg: &LevelConfig) -> Vec<Pivot> {
    let n = bars.len();
    let (l, r) = (cfg.pivot_left, cfg.pivot_right);
    let mut out = Vec::new();
    if n < l + r + 1 {
        return out;
    }
    for i in l..(n - r) {
        let a = atr[i];
        if !a.is_finite() || a <= 0.0 {
            continue;
        }
        let hi_i = bars[i].high;
        let lo_i = bars[i].low;
        let mut is_high = true;
        let mut is_low = true;
        let mut min_low = lo_i;
        let mut max_high = hi_i;
        for j in (i - l)..=(i + r) {
            if j == i {
                continue;
            }
            let b = &bars[j];
            if j < i {
                if b.high > hi_i {
                    is_high = false;
                }
                if b.low < lo_i {
                    is_low = false;
                }
            } else {
                if b.high >= hi_i {
                    is_high = false;
                }
                if b.low <= lo_i {
                    is_low = false;
                }
            }
            if b.low < min_low {
                min_low = b.low;
            }
            if b.high > max_high {
                max_high = b.high;
            }
        }
        let rv = if rvol[i].is_finite() { rvol[i] } else { 1.0 };
        if is_high && (hi_i - min_low) >= cfg.pivot_min_prominence_atr * a {
            out.push(Pivot { idx: i, kind: PivotKind::High, price: hi_i, atr: a, rvol: rv });
        }
        if is_low && (max_high - lo_i) >= cfg.pivot_min_prominence_atr * a {
            out.push(Pivot { idx: i, kind: PivotKind::Low, price: lo_i, atr: a, rvol: rv });
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn bars_from_closes(closes: &[f64]) -> Vec<Bar> {
        closes
            .iter()
            .enumerate()
            .map(|(i, &c)| Bar {
                date: NaiveDate::from_ymd_opt(2024, 1, 1).unwrap() + chrono::Duration::days(i as i64),
                open: c,
                high: c + 0.5,
                low: c - 0.5,
                close: c,
                volume: 1000.0,
            })
            .collect()
    }

    #[test]
    fn finds_peak_and_trough() {
        // up 10, down 20, up 10 => peak at 10, trough at 30
        let mut closes: Vec<f64> = (0..=10).map(|i| 100.0 + 2.0 * i as f64).collect();
        closes.extend((1..=20).map(|i| 120.0 - 2.0 * i as f64));
        closes.extend((1..=10).map(|i| 80.0 + 2.0 * i as f64));
        let bars = bars_from_closes(&closes);
        let atr = vec![1.0; bars.len()];
        let rvol = vec![1.0; bars.len()];
        let cfg = LevelConfig::default();
        let piv = find_pivots(&bars, &atr, &rvol, &cfg);
        assert!(piv.iter().any(|p| p.kind == PivotKind::High && p.idx == 10));
        assert!(piv.iter().any(|p| p.kind == PivotKind::Low && p.idx == 30));
    }

    #[test]
    fn small_wiggles_are_not_pivots() {
        let closes: Vec<f64> = (0..40).map(|i| 100.0 + if i % 2 == 0 { 0.0 } else { 0.1 }).collect();
        let bars = bars_from_closes(&closes);
        let atr = vec![5.0; bars.len()];
        let rvol = vec![1.0; bars.len()];
        assert!(find_pivots(&bars, &atr, &rvol, &LevelConfig::default()).is_empty());
    }
}
