//! Volatility-adaptive support/resistance zones.

use std::cmp::Ordering;

use serde::Serialize;

use super::pivots::Pivot;
use crate::config::LevelConfig;
use crate::types::Direction;
use crate::util::half_life_weight;

/// Which side of price a zone acts on.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Role {
    Resistance,
    Support,
}

impl Role {
    /// A LONG breakout breaks resistance; a SHORT breakout breaks support.
    pub fn for_direction(dir: Direction) -> Role {
        match dir {
            Direction::Long => Role::Resistance,
            Direction::Short => Role::Support,
        }
    }
}

/// A price band built from one cluster of swing points.
///
/// The same band can act as resistance (approached from below) or support
/// (approached from above); role-specific statistics are computed on demand
/// by the rigidity module. This naturally handles broken levels that flip role.
#[derive(Debug, Clone, Serialize)]
pub struct Zone {
    pub lower: f64,
    pub upper: f64,
    /// Recency- and volume-weighted centre of the cluster.
    pub center: f64,
    pub n_pivots: usize,
    pub first_pivot_idx: usize,
    pub last_pivot_idx: usize,
}

impl Zone {
    /// The edge that price must clear to break the zone in `dir`.
    pub fn edge(&self, dir: Direction) -> f64 {
        match dir {
            Direction::Long => self.upper,
            Direction::Short => self.lower,
        }
    }

    pub fn width(&self) -> f64 {
        self.upper - self.lower
    }
}

/// Cluster confirmed pivots into zones as known *after bar `end - 1`*.
///
/// * `end` is exclusive: only bars `0..end` exist for this computation.
/// * Pivots are used only once confirmed (`idx + pivot_right < end`).
/// * Pivots (both highs and lows) are merged when within
///   `cluster_width_atr * atr_ref` of the cluster's lowest price, so zone width
///   scales with each stock's own volatility rather than a fixed percentage.
/// * Each zone is padded by `zone_pad_atr * atr_ref` on both sides.
pub fn build_zones(pivots: &[Pivot], end: usize, atr_ref: f64, cfg: &LevelConfig) -> Vec<Zone> {
    if end == 0 || !atr_ref.is_finite() || atr_ref <= 0.0 {
        return Vec::new();
    }
    let mut pts: Vec<&Pivot> = pivots.iter().filter(|p| p.idx + cfg.pivot_right < end).collect();
    if pts.is_empty() {
        return Vec::new();
    }
    pts.sort_by(|a, b| a.price.partial_cmp(&b.price).unwrap_or(Ordering::Equal));

    let max_width = cfg.cluster_width_atr * atr_ref;
    let pad = cfg.zone_pad_atr * atr_ref;
    let last = end - 1;

    let mut zones = Vec::new();
    let mut cluster: Vec<&Pivot> = Vec::new();
    for p in pts {
        let start_price = cluster.first().map(|f| f.price);
        if let Some(sp) = start_price {
            if p.price - sp > max_width {
                zones.push(make_zone(&cluster, last, pad, cfg));
                cluster.clear();
            }
        }
        cluster.push(p);
    }
    if !cluster.is_empty() {
        zones.push(make_zone(&cluster, last, pad, cfg));
    }
    zones
}

fn make_zone(cluster: &[&Pivot], last: usize, pad: f64, cfg: &LevelConfig) -> Zone {
    let mut lo = f64::INFINITY;
    let mut hi = f64::NEG_INFINITY;
    let mut wsum = 0.0;
    let mut psum = 0.0;
    let mut first_idx = usize::MAX;
    let mut last_idx = 0usize;
    for p in cluster {
        lo = lo.min(p.price);
        hi = hi.max(p.price);
        let age = last.saturating_sub(p.idx) as f64;
        // Recent pivots and pivots made on heavy volume carry more weight.
        let w = half_life_weight(age, cfg.recency_halflife) * (1.0 + 0.5 * (p.rvol - 1.0).clamp(0.0, 1.0));
        wsum += w;
        psum += w * p.price;
        first_idx = first_idx.min(p.idx);
        last_idx = last_idx.max(p.idx);
    }
    let center = if wsum > 0.0 { psum / wsum } else { (lo + hi) / 2.0 };
    Zone {
        lower: lo - pad,
        upper: hi + pad,
        center,
        n_pivots: cluster.len(),
        first_pivot_idx: first_idx,
        last_pivot_idx: last_idx,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::levels::pivots::PivotKind;

    fn piv(idx: usize, price: f64) -> Pivot {
        Pivot { idx, kind: PivotKind::High, price, atr: 1.0, rvol: 1.0 }
    }

    #[test]
    fn nearby_pivots_merge_and_far_ones_split() {
        let cfg = LevelConfig::default();
        let pivots = vec![piv(10, 100.0), piv(30, 100.4), piv(50, 100.2), piv(20, 110.0)];
        let zones = build_zones(&pivots, 100, 1.0, &cfg);
        assert_eq!(zones.len(), 2);
        assert_eq!(zones[0].n_pivots, 3);
        assert!(zones[0].lower < 100.0 && zones[0].upper > 100.4);
        assert_eq!(zones[1].n_pivots, 1);
    }

    #[test]
    fn unconfirmed_pivots_are_ignored() {
        let cfg = LevelConfig::default();
        let pivots = vec![piv(95, 100.0)];
        // pivot_right = 5 => needs end > 100
        assert!(build_zones(&pivots, 100, 1.0, &cfg).is_empty());
        assert_eq!(build_zones(&pivots, 101, 1.0, &cfg).len(), 1);
    }

    #[test]
    fn zone_width_scales_with_atr() {
        let cfg = LevelConfig::default();
        let pivots = vec![piv(10, 100.0), piv(30, 103.0)];
        assert_eq!(build_zones(&pivots, 100, 1.0, &cfg).len(), 2);
        assert_eq!(build_zones(&pivots, 100, 5.0, &cfg).len(), 1);
    }
}
