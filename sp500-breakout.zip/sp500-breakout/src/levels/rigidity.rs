//! Rigidity: a 0-100 score for the historical strength of a support/resistance
//! zone (spec section 4). This is the system's primary distinguishing feature.
//!
//! The score blends six components, each normalised to `[0, 1]`:
//!
//! | component   | what it measures                                              |
//! |-------------|---------------------------------------------------------------|
//! | frequency   | recency-weighted count of *meaningful* tests (saturating)      |
//! | rejection   | average ATR-normalised distance price retreated after a test   |
//! | duration    | how long the level has stayed relevant (saturating)            |
//! | recency     | how recently it was last meaningfully tested                   |
//! | volume      | whether the tests happened on unusually heavy volume           |
//! | compression | successive reactions getting shallower (pressure building)     |
//!
//! Two design rules keep the score honest:
//!
//! * A test only earns credit in proportion to the rejection that followed it.
//!   Repeated tests with no meaningful rejection add (almost) nothing and
//!   actually dilute the rejection component, so a level cannot be rated
//!   "strong" merely because price kept touching it.
//! * Frequency and duration use saturating curves, so age and touch count have
//!   diminishing returns.

use serde::Serialize;

use super::zones::{Role, Zone};
use crate::config::{LevelConfig, RigidityConfig};
use crate::types::Bar;
use crate::util::{clamp01, half_life_weight, saturate};

/// One distinct test of a zone (consecutive touches are grouped).
#[derive(Debug, Clone)]
pub struct Interaction {
    pub start: usize,
    pub end: usize,
    /// Bar with the most extreme high (resistance) / low (support) of the group.
    pub extreme_idx: usize,
    /// Highest RVOL seen during the interaction (1.0 when unavailable).
    pub rvol: f64,
    /// Distance price retreated afterwards, in ATRs.
    pub rejection_atr: f64,
    /// The reaction extreme (lowest low after a resistance test / highest high after a support test).
    pub reaction: f64,
    /// Credit in `[0, 1]` derived from `rejection_atr`.
    pub quality: f64,
    /// Recency weight in `(0, 1]`.
    pub weight: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Maturity {
    /// Tested meaningfully more than once, over a span, and not brand new.
    Established,
    /// Too new or too thinly tested to rely on.
    RecentlyFormed,
}

#[derive(Debug, Clone, Copy, Default, Serialize)]
pub struct RigidityComponents {
    pub frequency: f64,
    pub rejection: f64,
    pub duration: f64,
    pub recency: f64,
    pub volume: f64,
    pub compression: f64,
}

#[derive(Debug, Clone, Serialize)]
pub struct LevelStats {
    pub role: Role,
    /// All distinct interactions, including ones with no meaningful rejection.
    pub interactions: usize,
    /// Interactions followed by a meaningful rejection.
    pub quality_interactions: usize,
    pub first_idx: usize,
    pub last_idx: usize,
    /// Sessions between the first and last meaningful test.
    pub span: usize,
    pub mean_rejection_atr: f64,
    pub components: RigidityComponents,
    /// 0-100.
    pub rigidity: f64,
    pub maturity: Maturity,
}

impl LevelStats {
    pub fn empty(role: Role) -> Self {
        Self {
            role,
            interactions: 0,
            quality_interactions: 0,
            first_idx: 0,
            last_idx: 0,
            span: 0,
            mean_rejection_atr: 0.0,
            components: RigidityComponents::default(),
            rigidity: 0.0,
            maturity: Maturity::RecentlyFormed,
        }
    }

    /// May a breakout through this level be considered at all?
    pub fn is_eligible(&self, cfg: &LevelConfig) -> bool {
        self.quality_interactions >= cfg.min_interactions
            && self.rigidity >= cfg.min_rigidity
            && (!cfg.require_established || self.maturity == Maturity::Established)
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Side {
    Below,
    Above,
}

/// Find the distinct interactions between price and `zone`, using only the
/// supplied bars (`bars.len()` is the exclusive "as-of" end; nothing after it
/// is ever read, so there is no look-ahead).
///
/// A bar *touches* a resistance zone when its high reaches the zone, it does
/// not close above it, and price has not closed above the zone since it last
/// closed below it (i.e. it is genuinely approaching from below). Support is
/// the mirror image. Touches separated by at most `touch_gap` bars form one
/// interaction.
#[allow(clippy::too_many_arguments)]
pub fn find_interactions(
    bars: &[Bar],
    atr: &[f64],
    rvol: &[f64],
    zone: &Zone,
    role: Role,
    atr_ref: f64,
    lcfg: &LevelConfig,
    rcfg: &RigidityConfig,
) -> Vec<Interaction> {
    let n = bars.len();
    if n < 2 {
        return Vec::new();
    }

    // 1. collect touching bars
    let mut last_outside: Option<Side> = None;
    let mut touches: Vec<usize> = Vec::new();
    for (j, b) in bars.iter().enumerate() {
        let touch = match role {
            Role::Resistance => {
                b.high >= zone.lower && b.close <= zone.upper && last_outside != Some(Side::Above)
            }
            Role::Support => {
                b.low <= zone.upper && b.close >= zone.lower && last_outside != Some(Side::Below)
            }
        };
        if touch {
            touches.push(j);
        }
        if b.close > zone.upper {
            last_outside = Some(Side::Above);
        } else if b.close < zone.lower {
            last_outside = Some(Side::Below);
        }
    }

    // 2. group nearby touches: (start, end, extreme)
    let mut groups: Vec<(usize, usize, usize)> = Vec::new();
    for &j in &touches {
        let merge = match groups.last() {
            Some(g) => j - g.1 <= lcfg.touch_gap,
            None => false,
        };
        if merge {
            let g = groups.last_mut().expect("group exists when merge is true");
            g.1 = j;
            let better = match role {
                Role::Resistance => bars[j].high > bars[g.2].high,
                Role::Support => bars[j].low < bars[g.2].low,
            };
            if better {
                g.2 = j;
            }
        } else {
            groups.push((j, j, j));
        }
    }

    // 3. measure each group
    let last_idx = n - 1;
    let mut out = Vec::with_capacity(groups.len());
    for (s, e, x) in groups {
        let mut rv = 0.0f64;
        let mut any = false;
        for j in s..=e {
            if rvol[j].is_finite() {
                rv = rv.max(rvol[j]);
                any = true;
            }
        }
        if !any {
            rv = 1.0;
        }

        let a = if atr[e].is_finite() && atr[e] > 0.0 { atr[e] } else { atr_ref };
        let stop = (e + lcfg.rejection_window).min(last_idx);
        let mut reaction = zone.center;
        let mut depth = 0.0;
        match role {
            Role::Resistance => {
                let mut min_low = f64::INFINITY;
                let mut j = e + 1;
                while j <= stop {
                    if bars[j].close > zone.upper {
                        break; // price broke out: later moves are not "rejection"
                    }
                    min_low = min_low.min(bars[j].low);
                    j += 1;
                }
                if min_low.is_finite() {
                    reaction = min_low;
                    depth = (zone.center - min_low).max(0.0);
                }
            }
            Role::Support => {
                let mut max_high = f64::NEG_INFINITY;
                let mut j = e + 1;
                while j <= stop {
                    if bars[j].close < zone.lower {
                        break;
                    }
                    max_high = max_high.max(bars[j].high);
                    j += 1;
                }
                if max_high.is_finite() {
                    reaction = max_high;
                    depth = (max_high - zone.center).max(0.0);
                }
            }
        }

        let rejection_atr = if a > 0.0 { depth / a } else { 0.0 };
        let quality = clamp01(
            (rejection_atr - rcfg.rejection_min_atr) / (rcfg.rejection_target_atr - rcfg.rejection_min_atr),
        );
        let weight = half_life_weight((last_idx - e) as f64, lcfg.recency_halflife);
        out.push(Interaction { start: s, end: e, extreme_idx: x, rvol: rv, rejection_atr, reaction, quality, weight });
    }
    out
}

/// Turn a zone's interactions into a [`LevelStats`] with a 0-100 rigidity.
///
/// `end` is the exclusive as-of index (the length of the bar slice analysed).
pub fn compute_rigidity(
    interactions: &[Interaction],
    role: Role,
    end: usize,
    atr_ref: f64,
    lcfg: &LevelConfig,
    rcfg: &RigidityConfig,
) -> LevelStats {
    if interactions.is_empty() || end == 0 {
        return LevelStats::empty(role);
    }
    let last_bar = end - 1;

    let qual: Vec<&Interaction> = interactions.iter().filter(|i| i.quality > 0.0).collect();

    // frequency: recency-weighted, quality-weighted, saturating
    let freq_sum: f64 = interactions.iter().map(|i| i.weight * i.quality).sum();
    let frequency = saturate(freq_sum, rcfg.frequency_scale);

    // rejection: weighted mean quality over *all* interactions, so tests that
    // were not rejected dilute the score
    let w_all: f64 = interactions.iter().map(|i| i.weight).sum();
    let rejection = if w_all > 0.0 { freq_sum / w_all } else { 0.0 };

    // duration + recency are defined by the meaningful tests
    let (first_idx, last_idx, span) = if qual.is_empty() {
        (0, 0, 0)
    } else {
        let f = qual.first().map(|i| i.extreme_idx).unwrap_or(0);
        let l = qual.last().map(|i| i.extreme_idx).unwrap_or(0);
        (f, l, l.saturating_sub(f))
    };
    let duration = if qual.len() >= 2 { saturate(span as f64, rcfg.duration_scale) } else { 0.0 };
    let recency = if qual.is_empty() {
        0.0
    } else {
        half_life_weight(last_bar.saturating_sub(last_idx) as f64, lcfg.recency_halflife)
    };

    // volume confirmation: quality/recency-weighted share of tests on heavy volume
    let wq: f64 = qual.iter().map(|i| i.weight * i.quality).sum();
    let volume = if wq > 0.0 {
        qual.iter()
            .map(|i| i.weight * i.quality * clamp01((i.rvol - 1.0) / (rcfg.volume_target_rvol - 1.0)))
            .sum::<f64>()
            / wq
    } else {
        0.0
    };

    // compression: reaction extremes getting shallower test after test
    let m = qual.len();
    let compression = if m >= 2 {
        let step = rcfg.compression_min_step_atr * atr_ref;
        let mut improving = 0usize;
        for w in qual.windows(2) {
            let ok = match role {
                // resistance: higher reaction lows = price pressing up into the level
                Role::Resistance => w[1].reaction >= w[0].reaction + step,
                // support: lower reaction highs = price pressing down into the level
                Role::Support => w[1].reaction <= w[0].reaction - step,
            };
            if ok {
                improving += 1;
            }
        }
        (improving as f64 / (m - 1) as f64) * ((m - 1) as f64 / 2.0).min(1.0)
    } else {
        0.0
    };

    let components = RigidityComponents { frequency, rejection, duration, recency, volume, compression };

    let weights = [
        rcfg.w_frequency,
        rcfg.w_rejection,
        rcfg.w_duration,
        rcfg.w_recency,
        rcfg.w_volume,
        rcfg.w_compression,
    ];
    let values = [frequency, rejection, duration, recency, volume, compression];
    let wsum: f64 = weights.iter().sum();
    let rigidity = if wsum > 0.0 {
        100.0 * weights.iter().zip(values.iter()).map(|(w, v)| w * clamp01(*v)).sum::<f64>() / wsum
    } else {
        0.0
    };

    let mean_rejection_atr = if qual.is_empty() {
        0.0
    } else {
        qual.iter().map(|i| i.rejection_atr).sum::<f64>() / qual.len() as f64
    };

    let established = qual.len() >= 2
        && span >= lcfg.established_min_span
        && last_bar.saturating_sub(first_idx) >= lcfg.established_min_age;

    LevelStats {
        role,
        interactions: interactions.len(),
        quality_interactions: qual.len(),
        first_idx,
        last_idx,
        span,
        mean_rejection_atr,
        components,
        rigidity: rigidity.clamp(0.0, 100.0),
        maturity: if established { Maturity::Established } else { Maturity::RecentlyFormed },
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn bars_from_closes(closes: &[f64]) -> Vec<Bar> {
        closes
            .iter()
            .enumerate()
            .map(|(i, &c)| Bar {
                date: NaiveDate::from_ymd_opt(2024, 1, 1).unwrap() + chrono::Duration::days(i as i64),
                open: c,
                high: c + 0.3,
                low: c - 0.3,
                close: c,
                volume: 1000.0,
            })
            .collect()
    }

    fn zone() -> Zone {
        Zone { lower: 99.5, upper: 100.5, center: 100.0, n_pivots: 3, first_pivot_idx: 10, last_pivot_idx: 50 }
    }

    fn stats_for(closes: &[f64]) -> LevelStats {
        let bars = bars_from_closes(closes);
        let atr = vec![1.0; bars.len()];
        let rvol = vec![1.0; bars.len()];
        let (l, r) = (LevelConfig::default(), RigidityConfig::default());
        let inter = find_interactions(&bars, &atr, &rvol, &zone(), Role::Resistance, 1.0, &l, &r);
        compute_rigidity(&inter, Role::Resistance, bars.len(), 1.0, &l, &r)
    }

    #[test]
    fn repeated_rejected_tests_build_an_established_level() {
        // three cycles: ramp 90 -> 100 then fall back to ~91
        let mut closes = Vec::new();
        for _ in 0..3 {
            closes.extend((0..=10).map(|i| 90.0 + i as f64));
            closes.extend((1..=9).map(|i| 100.0 - i as f64));
        }
        let s = stats_for(&closes);
        assert!(s.quality_interactions >= 3, "got {}", s.quality_interactions);
        assert_eq!(s.maturity, Maturity::Established);
        assert!(s.rigidity > 40.0, "rigidity {}", s.rigidity);
    }

    #[test]
    fn touching_without_rejection_earns_no_credit() {
        // ramp to the level then hover inside it, never retreating
        let mut closes: Vec<f64> = (0..=10).map(|i| 90.0 + i as f64).collect();
        closes.extend(std::iter::repeat(99.8).take(40));
        let s = stats_for(&closes);
        assert_eq!(s.quality_interactions, 0);
        assert_eq!(s.rigidity, 0.0);
    }

    #[test]
    fn no_interactions_means_zero() {
        let closes: Vec<f64> = (0..30).map(|i| 50.0 + i as f64 * 0.1).collect();
        let s = stats_for(&closes);
        assert_eq!(s.interactions, 0);
        assert_eq!(s.rigidity, 0.0);
    }

    #[test]
    fn rigidity_is_bounded() {
        let mut closes = Vec::new();
        for _ in 0..8 {
            closes.extend((0..=10).map(|i| 90.0 + i as f64));
            closes.extend((1..=9).map(|i| 100.0 - i as f64));
        }
        let s = stats_for(&closes);
        assert!(s.rigidity >= 0.0 && s.rigidity <= 100.0);
    }
}
