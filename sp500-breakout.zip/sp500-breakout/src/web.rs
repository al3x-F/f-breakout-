//! A tiny local web interface, so the program can be used by double-clicking
//! the executable instead of typing commands.
//!
//! * Standard library only (no extra dependencies): a minimal HTTP/1.1 server.
//! * Binds to `127.0.0.1` only, never to the network.
//! * Every `/api/*` call must carry a per-session random token that only the
//!   page served by this process knows, and the `Host` header must be
//!   `127.0.0.1` / `localhost`. Together these stop other web pages (CSRF, DNS
//!   rebinding) from triggering scans that would spend your data-provider quota.
//! * An API key pasted into the page is sent as a request header, held in memory
//!   for that request only, and never written to disk or logged.
//!
//! Routes: `/` (the page), `/api/info`, `/api/scan`, `/api/chart`, `/api/backtest`.

use std::collections::HashMap;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex, TryLockError};
use std::time::Duration as StdDuration;

use chrono::{Duration, NaiveDate, Utc};
use serde::Serialize;

use crate::backtest::{self, metrics};
use crate::chart;
use crate::config::{Config, ProviderKind};
use crate::data;
use crate::data::calendar::last_completed_session_estimate;
use crate::error::{Error, Result};
use crate::market::MarketState;
use crate::scanner::{self, ScanOptions, ScanResult};
use crate::signal::BreakoutSignal;

const INDEX_HTML: &str = include_str!("web_ui.html");

/// Shared server state.
pub struct AppState {
    cfg: Config,
    /// Random per-session token required on every `/api/*` request.
    pub token: String,
    /// Only one scan or backtest at a time.
    busy: Mutex<()>,
    /// The most recent scan, kept so charts can be served without refetching.
    last: Mutex<Option<Arc<ScanResult>>>,
}

impl AppState {
    pub fn new(cfg: Config) -> Self {
        Self { cfg, token: make_token(), busy: Mutex::new(()), last: Mutex::new(None) }
    }
}

fn make_token() -> String {
    use std::collections::hash_map::RandomState;
    use std::hash::{BuildHasher, Hasher};
    // RandomState is seeded from the operating system's randomness.
    let mut out = String::new();
    for i in 0..4u64 {
        let mut h = RandomState::new().build_hasher();
        h.write_u64(std::process::id() as u64 ^ (i << 32));
        out.push_str(&format!("{:016x}", h.finish()));
    }
    out
}

// ---------------------------------------------------------------------------
// HTTP plumbing
// ---------------------------------------------------------------------------

#[derive(Debug)]
pub struct Request {
    pub method: String,
    pub path: String,
    pub query: HashMap<String, String>,
    /// Header names are lower-cased.
    pub headers: HashMap<String, String>,
}

pub struct Response {
    pub status: u16,
    pub content_type: &'static str,
    pub body: Vec<u8>,
}

impl Response {
    fn new(status: u16, content_type: &'static str, body: Vec<u8>) -> Self {
        Self { status, content_type, body }
    }

    fn json<T: Serialize>(status: u16, value: &T) -> Self {
        match serde_json::to_vec(value) {
            Ok(b) => Self::new(status, "application/json; charset=utf-8", b),
            Err(e) => Self::error(500, &format!("could not serialise the response: {e}")),
        }
    }

    fn error(status: u16, msg: &str) -> Self {
        let body = serde_json::json!({ "error": msg }).to_string().into_bytes();
        Self::new(status, "application/json; charset=utf-8", body)
    }
}

fn reason(status: u16) -> &'static str {
    match status {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        401 => "Unauthorized",
        403 => "Forbidden",
        404 => "Not Found",
        405 => "Method Not Allowed",
        409 => "Conflict",
        _ => "Internal Server Error",
    }
}

/// Percent-decode a URL component (`+` becomes a space).
pub fn url_decode(s: &str) -> String {
    fn hex(b: u8) -> Option<u8> {
        match b {
            b'0'..=b'9' => Some(b - b'0'),
            b'a'..=b'f' => Some(b - b'a' + 10),
            b'A'..=b'F' => Some(b - b'A' + 10),
            _ => None,
        }
    }
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            b'%' if i + 2 < bytes.len() => {
                if let (Some(h), Some(l)) = (hex(bytes[i + 1]), hex(bytes[i + 2])) {
                    out.push(h * 16 + l);
                    i += 3;
                } else {
                    out.push(b'%');
                    i += 1;
                }
            }
            b => {
                out.push(b);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

pub fn parse_query(q: &str) -> HashMap<String, String> {
    let mut map = HashMap::new();
    for pair in q.split('&') {
        if pair.is_empty() {
            continue;
        }
        let (k, v) = pair.split_once('=').unwrap_or((pair, ""));
        map.insert(url_decode(k), url_decode(v));
    }
    map
}

/// Parse the request line and headers (the UI only needs GET, so bodies are ignored).
pub fn parse_request(raw: &str) -> Option<Request> {
    let mut lines = raw.split("\r\n");
    let first = lines.next()?;
    let mut parts = first.split_whitespace();
    let method = parts.next()?.to_string();
    let target = parts.next()?;
    let (path, query) = match target.split_once('?') {
        Some((p, q)) => (p.to_string(), parse_query(q)),
        None => (target.to_string(), HashMap::new()),
    };
    let mut headers = HashMap::new();
    for line in lines {
        if line.is_empty() {
            break;
        }
        if let Some((k, v)) = line.split_once(':') {
            headers.insert(k.trim().to_ascii_lowercase(), v.trim().to_string());
        }
    }
    Some(Request { method, path, query, headers })
}

fn read_head(stream: &mut TcpStream) -> std::io::Result<String> {
    let mut buf: Vec<u8> = Vec::with_capacity(2048);
    let mut chunk = [0u8; 1024];
    loop {
        let n = stream.read(&mut chunk)?;
        if n == 0 {
            break;
        }
        buf.extend_from_slice(&chunk[..n]);
        if buf.windows(4).any(|w| w == b"\r\n\r\n") || buf.len() > 16 * 1024 {
            break;
        }
    }
    Ok(String::from_utf8_lossy(&buf).into_owned())
}

fn write_response(stream: &mut TcpStream, resp: &Response) -> std::io::Result<()> {
    let head = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: {}\r\nContent-Length: {}\r\nCache-Control: no-store\r\n\
         X-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n",
        resp.status,
        reason(resp.status),
        resp.content_type,
        resp.body.len()
    );
    stream.write_all(head.as_bytes())?;
    stream.write_all(&resp.body)?;
    stream.flush()
}

fn handle_connection(state: &AppState, mut stream: TcpStream) -> std::io::Result<()> {
    stream.set_read_timeout(Some(StdDuration::from_secs(10)))?;
    let head = read_head(&mut stream)?;
    let resp = match parse_request(&head) {
        Some(req) => handle(state, &req),
        None => Response::error(400, "bad request"),
    };
    write_response(&mut stream, &resp)
}

// ---------------------------------------------------------------------------
// Routing
// ---------------------------------------------------------------------------

/// Route one request. Pure with respect to the network, so it is unit-testable.
pub fn handle(state: &AppState, req: &Request) -> Response {
    // DNS-rebinding guard: only talk to pages addressed to this machine.
    if let Some(host) = req.headers.get("host") {
        let name = host.rsplit_once(':').map(|(h, _)| h).unwrap_or(host.as_str());
        if name != "127.0.0.1" && name != "localhost" {
            return Response::error(403, "forbidden host");
        }
    }
    if req.method != "GET" {
        return Response::error(405, "method not allowed");
    }
    match req.path.as_str() {
        "/" | "/index.html" => Response::new(
            200,
            "text/html; charset=utf-8",
            INDEX_HTML.replace("__TOKEN__", &state.token).into_bytes(),
        ),
        "/favicon.ico" => Response::new(204, "image/x-icon", Vec::new()),
        path if path.starts_with("/api/") => {
            if req.headers.get("x-token").map(|t| t.as_str()) != Some(state.token.as_str()) {
                return Response::error(401, "missing or invalid session token; reload the page");
            }
            match path {
                "/api/info" => api_info(state),
                "/api/scan" => api_scan(state, req),
                "/api/chart" => api_chart(state, req),
                "/api/backtest" => api_backtest(state, req),
                _ => Response::error(404, "not found"),
            }
        }
        _ => Response::error(404, "not found"),
    }
}

/// Per-request configuration: the server's config plus the page's choices.
fn request_config(state: &AppState, req: &Request) -> std::result::Result<Config, String> {
    let mut cfg = state.cfg.clone();
    if let Some(src) = req.query.get("source") {
        cfg.data.provider = match src.as_str() {
            "fmp" => ProviderKind::Fmp,
            "csv" => ProviderKind::Csv,
            "synthetic" | "demo" => ProviderKind::Synthetic,
            other => return Err(format!("unknown data source '{other}'")),
        };
    }
    if let Some(key) = req.headers.get("x-api-key") {
        let k = key.trim();
        if !k.is_empty() {
            cfg.data.api_key_override = Some(k.to_string());
        }
    }
    Ok(cfg)
}

fn parse_date_opt(q: &HashMap<String, String>, key: &str) -> std::result::Result<Option<NaiveDate>, String> {
    match q.get(key).map(|s| s.trim()).filter(|s| !s.is_empty()) {
        None => Ok(None),
        Some(s) => NaiveDate::parse_from_str(s, "%Y-%m-%d")
            .map(Some)
            .map_err(|_| format!("invalid {key} '{s}' (expected YYYY-MM-DD)")),
    }
}

fn api_info(state: &AppState) -> Response {
    let key_in_env = std::env::var(&state.cfg.data.api_key_env).map(|v| !v.trim().is_empty()).unwrap_or(false);
    Response::json(
        200,
        &serde_json::json!({
            "version": env!("CARGO_PKG_VERSION"),
            "fmp_key_in_env": key_in_env,
            "api_key_env": state.cfg.data.api_key_env,
            "default_top_n": state.cfg.scan.top_n,
        }),
    )
}

#[derive(Serialize)]
struct ScanApi<'a> {
    provider: String,
    as_of: NaiveDate,
    market: &'a MarketState,
    universe_size: usize,
    analysed: usize,
    skipped_count: usize,
    skipped_sample: Vec<&'a (String, String)>,
    event_count: usize,
    ranked: &'a [BreakoutSignal],
}

fn api_scan(state: &AppState, req: &Request) -> Response {
    let cfg = match request_config(state, req) {
        Ok(c) => c,
        Err(m) => return Response::error(400, &m),
    };
    let as_of = match parse_date_opt(&req.query, "as_of") {
        Ok(d) => d,
        Err(m) => return Response::error(400, &m),
    };
    let top_n = req
        .query
        .get("top")
        .and_then(|s| s.trim().parse::<usize>().ok())
        .unwrap_or(cfg.scan.top_n)
        .clamp(1, 50);

    let _guard = match state.busy.try_lock() {
        Ok(g) => g,
        Err(TryLockError::Poisoned(p)) => p.into_inner(),
        Err(TryLockError::WouldBlock) => return Response::error(409, "another scan or backtest is still running"),
    };

    let provider = match data::build_provider(&cfg) {
        Ok(p) => p,
        Err(e) => return Response::error(400, &e.to_string()),
    };
    let provider_name = provider.name().to_string();
    let opts = ScanOptions { as_of, now: Utc::now(), top_n };
    let result = match scanner::run_scan(&cfg, provider.as_ref(), &opts) {
        Ok(r) => Arc::new(r),
        Err(e) => return Response::error(500, &e.to_string()),
    };

    let resp = Response::json(
        200,
        &ScanApi {
            provider: provider_name,
            as_of: result.as_of,
            market: &result.market,
            universe_size: result.universe_size,
            analysed: result.analysed,
            skipped_count: result.skipped.len(),
            skipped_sample: result.skipped.iter().take(10).collect(),
            event_count: result.events.len(),
            ranked: &result.ranked,
        },
    );
    if let Ok(mut slot) = state.last.lock() {
        *slot = Some(Arc::clone(&result));
    }
    resp
}

fn api_chart(state: &AppState, req: &Request) -> Response {
    let rank = match req.query.get("rank").and_then(|s| s.trim().parse::<usize>().ok()) {
        Some(r) if r >= 1 => r,
        _ => return Response::error(400, "rank must be a positive integer"),
    };
    let last = match state.last.lock() {
        Ok(slot) => slot.clone(),
        Err(p) => p.into_inner().clone(),
    };
    let result = match last {
        Some(r) => r,
        None => return Response::error(404, "run a scan first"),
    };
    let signal = match result.ranked.get(rank - 1) {
        Some(s) => s,
        None => return Response::error(404, "no such rank in the last scan"),
    };
    let bars = match result.history.get(&signal.symbol) {
        Some(b) => b,
        None => return Response::error(404, "no price history kept for that symbol"),
    };
    let svg = chart::render_svg(&signal.symbol, bars, Some(signal), &state.cfg);
    Response::new(200, "image/svg+xml; charset=utf-8", svg.into_bytes())
}

fn api_backtest(state: &AppState, req: &Request) -> Response {
    let cfg = match request_config(state, req) {
        Ok(c) => c,
        Err(m) => return Response::error(400, &m),
    };
    let start = match parse_date_opt(&req.query, "start") {
        Ok(d) => d,
        Err(m) => return Response::error(400, &m),
    };
    let end = match parse_date_opt(&req.query, "end") {
        Ok(d) => d,
        Err(m) => return Response::error(400, &m),
    };
    let now = Utc::now();
    let latest = last_completed_session_estimate(now, cfg.data.market_close_buffer_minutes);
    let end = end.unwrap_or(latest);
    let start = start
        .unwrap_or_else(|| end - Duration::days((cfg.backtest.test_sessions as f64 * 1.45).ceil() as i64));

    let _guard = match state.busy.try_lock() {
        Ok(g) => g,
        Err(TryLockError::Poisoned(p)) => p.into_inner(),
        Err(TryLockError::WouldBlock) => return Response::error(409, "another scan or backtest is still running"),
    };
    let provider = match data::build_provider(&cfg) {
        Ok(p) => p,
        Err(e) => return Response::error(400, &e.to_string()),
    };
    match backtest::engine::run(&cfg, provider.as_ref(), start, end, now) {
        Ok(out) => {
            let summary = metrics::summarize(&out, &cfg);
            let report = metrics::render(&summary, cfg.backtest.min_group_size);
            Response::json(
                200,
                &serde_json::json!({
                    "report": report,
                    "records": out.records.len(),
                    "start": out.start.to_string(),
                    "end": out.end.to_string(),
                }),
            )
        }
        Err(e) => Response::error(500, &e.to_string()),
    }
}

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------

fn bind_first_free(start_port: u16) -> Result<(TcpListener, u16)> {
    for p in start_port..start_port.saturating_add(20) {
        if let Ok(l) = TcpListener::bind(("127.0.0.1", p)) {
            return Ok((l, p));
        }
    }
    Err(Error::Data(format!("no free local port found in {}..{}", start_port, start_port.saturating_add(20))))
}

fn open_browser(url: &str) {
    let spawned = if cfg!(target_os = "windows") {
        std::process::Command::new("cmd").args(["/C", "start", "", url]).spawn()
    } else if cfg!(target_os = "macos") {
        std::process::Command::new("open").arg(url).spawn()
    } else {
        std::process::Command::new("xdg-open").arg(url).spawn()
    };
    if let Err(e) = spawned {
        log::warn!("could not open a browser automatically ({e}); open {url} yourself");
    }
}

/// Start the local web interface and block until the process is stopped.
pub fn serve(cfg: Config, port: u16, open: bool) -> Result<()> {
    let (listener, port) = bind_first_free(port)?;
    let state = Arc::new(AppState::new(cfg));
    let url = format!("http://127.0.0.1:{port}/");

    println!("S&P 500 Breakout Scanner is running at {url}");
    println!("It only listens on this computer. Close this window (or press Ctrl+C) to stop it.");
    if open {
        open_browser(&url);
    }

    for conn in listener.incoming() {
        match conn {
            Ok(stream) => {
                let st = Arc::clone(&state);
                std::thread::spawn(move || {
                    if let Err(e) = handle_connection(&st, stream) {
                        log::debug!("connection error: {e}");
                    }
                });
            }
            Err(e) => log::warn!("accept failed: {e}"),
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn req(path_and_query: &str, headers: &[(&str, &str)]) -> Request {
        let mut raw = format!("GET {path_and_query} HTTP/1.1\r\nHost: 127.0.0.1:8787\r\n");
        for (k, v) in headers {
            raw.push_str(&format!("{k}: {v}\r\n"));
        }
        raw.push_str("\r\n");
        parse_request(&raw).expect("valid request")
    }

    fn state() -> AppState {
        AppState::new(Config::default())
    }

    fn body_json(r: &Response) -> serde_json::Value {
        serde_json::from_slice(&r.body).expect("json body")
    }

    #[test]
    fn url_decoding() {
        assert_eq!(url_decode("a%20b+c"), "a b c");
        assert_eq!(url_decode("2026-11-13"), "2026-11-13");
        assert_eq!(url_decode("100%"), "100%");
        assert_eq!(url_decode("%zz"), "%zz");
        assert_eq!(url_decode("%41%42"), "AB");
    }

    #[test]
    fn request_parsing() {
        let r = parse_request("GET /api/scan?source=fmp&top=5 HTTP/1.1\r\nHost: localhost\r\nX-Token: abc\r\n\r\n").unwrap();
        assert_eq!(r.method, "GET");
        assert_eq!(r.path, "/api/scan");
        assert_eq!(r.query.get("source").map(|s| s.as_str()), Some("fmp"));
        assert_eq!(r.query.get("top").map(|s| s.as_str()), Some("5"));
        assert_eq!(r.headers.get("x-token").map(|s| s.as_str()), Some("abc"));
        assert!(parse_request("").is_none());
    }

    #[test]
    fn index_page_gets_the_session_token_injected() {
        let st = state();
        let resp = handle(&st, &req("/", &[]));
        assert_eq!(resp.status, 200);
        let html = String::from_utf8(resp.body).unwrap();
        assert!(html.contains(&st.token));
        assert!(!html.contains("__TOKEN__"));
        assert!(html.contains("Run scan"));
    }

    #[test]
    fn api_requires_the_token_and_a_local_host() {
        let st = state();
        assert_eq!(handle(&st, &req("/api/info", &[])).status, 401);
        assert_eq!(handle(&st, &req("/api/info", &[("X-Token", "wrong")])).status, 401);
        assert_eq!(handle(&st, &req("/api/info", &[("X-Token", st.token.as_str())])).status, 200);

        let rebinding = parse_request("GET /api/info HTTP/1.1\r\nHost: evil.example.com\r\n\r\n").unwrap();
        assert_eq!(handle(&st, &rebinding).status, 403);

        let post = parse_request("POST /api/scan HTTP/1.1\r\nHost: localhost\r\n\r\n").unwrap();
        assert_eq!(handle(&st, &post).status, 405);
        assert_eq!(handle(&st, &req("/nope", &[])).status, 404);
    }

    #[test]
    fn bad_parameters_are_rejected_politely() {
        let st = state();
        let h = [("X-Token", st.token.as_str())];
        assert_eq!(handle(&st, &req("/api/scan?source=bogus", &h)).status, 400);
        assert_eq!(handle(&st, &req("/api/scan?source=synthetic&as_of=yesterday", &h)).status, 400);
        assert_eq!(handle(&st, &req("/api/chart?rank=1", &h)).status, 404); // no scan yet
        assert_eq!(handle(&st, &req("/api/chart?rank=zero", &h)).status, 400);
    }

    #[test]
    fn missing_fmp_key_gives_a_helpful_message_not_a_crash() {
        let mut cfg = Config::default();
        cfg.data.api_key_env = "SP500_WEB_TEST_KEY_NOT_SET".to_string();
        let st = AppState::new(cfg);
        let h = [("X-Token", st.token.as_str())];
        let resp = handle(&st, &req("/api/scan?source=fmp", &h));
        assert_eq!(resp.status, 400);
        let msg = body_json(&resp)["error"].as_str().unwrap_or("").to_string();
        assert!(msg.contains("API key"), "message was: {msg}");
    }

    #[test]
    fn demo_scan_then_chart_end_to_end() {
        let st = state();
        let h = [("X-Token", st.token.as_str())];
        let resp = handle(&st, &req("/api/scan?source=synthetic&top=5", &h));
        assert_eq!(resp.status, 200, "{}", String::from_utf8_lossy(&resp.body));
        let v = body_json(&resp);
        let ranked = v["ranked"].as_array().expect("ranked array");
        assert!(ranked.len() <= 5);
        assert!(ranked.iter().all(|s| matches!(s["classification"].as_str(), Some("FRESH") | Some("DEVELOPING"))));
        assert_eq!(v["provider"].as_str(), Some("synthetic"));

        if !ranked.is_empty() {
            let chart = handle(&st, &req("/api/chart?rank=1", &h));
            assert_eq!(chart.status, 200);
            assert_eq!(chart.content_type, "image/svg+xml; charset=utf-8");
            assert!(String::from_utf8_lossy(&chart.body).starts_with("<svg"));
            assert_eq!(handle(&st, &req("/api/chart?rank=99", &h)).status, 404);
        }
    }
}
