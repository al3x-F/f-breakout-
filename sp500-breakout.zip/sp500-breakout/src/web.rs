//! A tiny local web interface, so the program can be used by double-clicking
//! the executable instead of typing commands.
//!
//! * Standard library only (no extra dependencies): a minimal HTTP/1.1 server.
//! * Binds to `127.0.0.1` only, never to the network.
//! * Every `/api/*` call must carry a per-session random token that only the
//!   page served by this process knows, and the `Host` header must be
//!   `127.0.0.1` / `localhost`. Together these stop other web pages (CSRF, DNS
//!   rebinding) from triggering scans that would spend your data-provider quota.
//! * An API key pasted into the page is sent as a request header, held in memory
//!   for that request only, and never written to disk or logged.
//!
//! Routes: `/` (the page), `/api/info`, `/api/scan`, `/api/progress`, `/api/chart`,
//! `/api/ticker`, `/api/diagnose`, `/api/backtest`, and the scraper job: `/api/scrape_start`,
//! `/api/scrape_status`, `/api/scrape_cancel`.

use std::collections::HashMap;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex, OnceLock, TryLockError};
use std::time::Duration as StdDuration;

use chrono::{Duration, NaiveDate, Utc};
use serde::Serialize;

use crate::backtest::{self, metrics};
use crate::chart;
use crate::config::{Config, ProviderKind};
use crate::data;
use crate::data::calendar::last_completed_session_estimate;
use crate::error::{Error, Result};
use crate::market::MarketState;
use crate::scanner::{self, ScanOptions, ScanResult};
use crate::scrape::{self, Python, ScrapeJob};
use crate::signal::BreakoutSignal;

const INDEX_HTML: &str = include_str!("web_ui.html");

/// Shared server state.
pub struct AppState {
    cfg: Config,
    /// Random per-session token required on every `/api/*` request.
    pub token: String,
    /// Only one scan or backtest at a time.
    busy: Mutex<()>,
    /// The most recent scan, kept so charts can be served without refetching.
    last: Mutex<Option<Arc<ScanResult>>>,
    /// What the running scan is doing, polled by the page for a progress readout.
    progress: Mutex<ProgressState>,
    /// The Python scraper job (download two years of prices).
    scrape: ScrapeJob,
    /// Python is looked up once, the first time it is needed.
    python: OnceLock<Option<Python>>,
}

#[derive(Debug, Clone, Default, Serialize)]
struct ProgressState {
    running: bool,
    phase: String,
    done: usize,
    total: usize,
}

impl AppState {
    pub fn new(cfg: Config) -> Self {
        Self {
            cfg,
            token: make_token(),
            busy: Mutex::new(()),
            last: Mutex::new(None),
            progress: Mutex::new(ProgressState::default()),
            scrape: ScrapeJob::new(),
            python: OnceLock::new(),
        }
    }

    fn python(&self) -> Option<&Python> {
        self.python.get_or_init(scrape::find_python).as_ref()
    }
}

fn set_progress(state: &AppState, running: bool, phase: &str, done: usize, total: usize) {
    if let Ok(mut p) = state.progress.lock() {
        p.running = running;
        p.phase = phase.to_string();
        p.done = done;
        p.total = total;
    }
}

fn make_token() -> String {
    use std::collections::hash_map::RandomState;
    use std::hash::{BuildHasher, Hasher};
    // RandomState is seeded from the operating system's randomness.
    let mut out = String::new();
    for i in 0..4u64 {
        let mut h = RandomState::new().build_hasher();
        h.write_u64(std::process::id() as u64 ^ (i << 32));
        out.push_str(&format!("{:016x}", h.finish()));
    }
    out
}

// ---------------------------------------------------------------------------
// HTTP plumbing
// ---------------------------------------------------------------------------

#[derive(Debug)]
pub struct Request {
    pub method: String,
    pub path: String,
    pub query: HashMap<String, String>,
    /// Header names are lower-cased.
    pub headers: HashMap<String, String>,
}

pub struct Response {
    pub status: u16,
    pub content_type: &'static str,
    pub body: Vec<u8>,
}

impl Response {
    fn new(status: u16, content_type: &'static str, body: Vec<u8>) -> Self {
        Self { status, content_type, body }
    }

    fn json<T: Serialize>(status: u16, value: &T) -> Self {
        match serde_json::to_vec(value) {
            Ok(b) => Self::new(status, "application/json; charset=utf-8", b),
            Err(e) => Self::error(500, &format!("could not serialise the response: {e}")),
        }
    }

    fn error(status: u16, msg: &str) -> Self {
        let body = serde_json::json!({ "error": msg }).to_string().into_bytes();
        Self::new(status, "application/json; charset=utf-8", body)
    }
}

fn reason(status: u16) -> &'static str {
    match status {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        401 => "Unauthorized",
        403 => "Forbidden",
        404 => "Not Found",
        405 => "Method Not Allowed",
        409 => "Conflict",
        _ => "Internal Server Error",
    }
}

/// Percent-decode a URL component (`+` becomes a space).
pub fn url_decode(s: &str) -> String {
    fn hex(b: u8) -> Option<u8> {
        match b {
            b'0'..=b'9' => Some(b - b'0'),
            b'a'..=b'f' => Some(b - b'a' + 10),
            b'A'..=b'F' => Some(b - b'A' + 10),
            _ => None,
        }
    }
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            b'%' if i + 2 < bytes.len() => {
                if let (Some(h), Some(l)) = (hex(bytes[i + 1]), hex(bytes[i + 2])) {
                    out.push(h * 16 + l);
                    i += 3;
                } else {
                    out.push(b'%');
                    i += 1;
                }
            }
            b => {
                out.push(b);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

pub fn parse_query(q: &str) -> HashMap<String, String> {
    let mut map = HashMap::new();
    for pair in q.split('&') {
        if pair.is_empty() {
            continue;
        }
        let (k, v) = pair.split_once('=').unwrap_or((pair, ""));
        map.insert(url_decode(k), url_decode(v));
    }
    map
}

/// Parse the request line and headers (the UI only needs GET, so bodies are ignored).
pub fn parse_request(raw: &str) -> Option<Request> {
    let mut lines = raw.split("\r\n");
    let first = lines.next()?;
    let mut parts = first.split_whitespace();
    let method = parts.next()?.to_string();
    let target = parts.next()?;
    let (path, query) = match target.split_once('?') {
        Some((p, q)) => (p.to_string(), parse_query(q)),
        None => (target.to_string(), HashMap::new()),
    };
    let mut headers = HashMap::new();
    for line in lines {
        if line.is_empty() {
            break;
        }
        if let Some((k, v)) = line.split_once(':') {
            headers.insert(k.trim().to_ascii_lowercase(), v.trim().to_string());
        }
    }
    Some(Request { method, path, query, headers })
}

fn read_head(stream: &mut TcpStream) -> std::io::Result<String> {
    let mut buf: Vec<u8> = Vec::with_capacity(2048);
    let mut chunk = [0u8; 1024];
    loop {
        let n = stream.read(&mut chunk)?;
        if n == 0 {
            break;
        }
        buf.extend_from_slice(&chunk[..n]);
        if buf.windows(4).any(|w| w == b"\r\n\r\n") || buf.len() > 16 * 1024 {
            break;
        }
    }
    Ok(String::from_utf8_lossy(&buf).into_owned())
}

fn write_response(stream: &mut TcpStream, resp: &Response) -> std::io::Result<()> {
    let head = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: {}\r\nContent-Length: {}\r\nCache-Control: no-store\r\n\
         X-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n",
        resp.status,
        reason(resp.status),
        resp.content_type,
        resp.body.len()
    );
    stream.write_all(head.as_bytes())?;
    stream.write_all(&resp.body)?;
    stream.flush()
}

fn handle_connection(state: &AppState, mut stream: TcpStream) -> std::io::Result<()> {
    stream.set_read_timeout(Some(StdDuration::from_secs(10)))?;
    let head = read_head(&mut stream)?;
    let resp = match parse_request(&head) {
        Some(req) => handle(state, &req),
        None => Response::error(400, "bad request"),
    };
    write_response(&mut stream, &resp)
}

// ---------------------------------------------------------------------------
// Routing
// ---------------------------------------------------------------------------

/// Route one request. Pure with respect to the network, so it is unit-testable.
pub fn handle(state: &AppState, req: &Request) -> Response {
    // DNS-rebinding guard: only talk to pages addressed to this machine.
    if let Some(host) = req.headers.get("host") {
        let name = host.rsplit_once(':').map(|(h, _)| h).unwrap_or(host.as_str());
        if name != "127.0.0.1" && name != "localhost" {
            return Response::error(403, "forbidden host");
        }
    }
    if req.method != "GET" {
        return Response::error(405, "method not allowed");
    }
    match req.path.as_str() {
        "/" | "/index.html" => Response::new(
            200,
            "text/html; charset=utf-8",
            INDEX_HTML.replace("__TOKEN__", &state.token).into_bytes(),
        ),
        "/favicon.ico" => Response::new(204, "image/x-icon", Vec::new()),
        path if path.starts_with("/api/") => {
            if req.headers.get("x-token").map(|t| t.as_str()) != Some(state.token.as_str()) {
                return Response::error(401, "missing or invalid session token; reload the page");
            }
            match path {
                "/api/info" => api_info(state),
                "/api/scan" => api_scan(state, req),
                "/api/progress" => api_progress(state),
                "/api/chart" => api_chart(state, req),
                "/api/ticker" => api_ticker(state, req),
                "/api/diagnose" => api_diagnose(state, req),
                "/api/scrape_status" => api_scrape_status(state),
                "/api/scrape_start" => api_scrape_start(state, req),
                "/api/scrape_cancel" => api_scrape_cancel(state),
                "/api/backtest" => api_backtest(state, req),
                _ => Response::error(404, "not found"),
            }
        }
        _ => Response::error(404, "not found"),
    }
}

/// Per-request configuration: the server's config plus the page's choices.
fn request_config(state: &AppState, req: &Request) -> std::result::Result<Config, String> {
    let mut cfg = state.cfg.clone();
    if let Some(src) = req.query.get("source") {
        cfg.data.provider = match src.as_str() {
            "fmp" => ProviderKind::Fmp,
            "csv" => ProviderKind::Csv,
            "synthetic" | "demo" => ProviderKind::Synthetic,
            other => return Err(format!("unknown data source '{other}'")),
        };
    }
    if let Some(key) = req.headers.get("x-api-key") {
        let k = key.trim();
        if !k.is_empty() {
            cfg.data.api_key_override = Some(k.to_string());
        }
    }
    // Optional cap on how many constituents are downloaded (useful on plans with a daily call limit).
    if let Some(n) = req.query.get("limit").and_then(|s| s.trim().parse::<usize>().ok()) {
        if n > 0 {
            cfg.scan.universe_limit = Some(n);
        }
    }
    Ok(cfg)
}

fn parse_date_opt(q: &HashMap<String, String>, key: &str) -> std::result::Result<Option<NaiveDate>, String> {
    match q.get(key).map(|s| s.trim()).filter(|s| !s.is_empty()) {
        None => Ok(None),
        Some(s) => NaiveDate::parse_from_str(s, "%Y-%m-%d")
            .map(Some)
            .map_err(|_| format!("invalid {key} '{s}' (expected YYYY-MM-DD)")),
    }
}

fn api_info(state: &AppState) -> Response {
    let key_in_env = std::env::var(&state.cfg.data.api_key_env).map(|v| !v.trim().is_empty()).unwrap_or(false);
    Response::json(
        200,
        &serde_json::json!({
            "version": env!("CARGO_PKG_VERSION"),
            "fmp_key_in_env": key_in_env,
            "api_key_env": state.cfg.data.api_key_env,
            "default_top_n": state.cfg.scan.top_n,
        }),
    )
}

#[derive(Serialize)]
struct ScanApi<'a> {
    provider: String,
    index_symbol: &'a str,
    as_of: NaiveDate,
    market: &'a MarketState,
    universe_size: usize,
    analysed: usize,
    skipped_count: usize,
    skipped_sample: Vec<&'a (String, String)>,
    event_count: usize,
    ranked: &'a [BreakoutSignal],
}

fn api_scan(state: &AppState, req: &Request) -> Response {
    let cfg = match request_config(state, req) {
        Ok(c) => c,
        Err(m) => return Response::error(400, &m),
    };
    let as_of = match parse_date_opt(&req.query, "as_of") {
        Ok(d) => d,
        Err(m) => return Response::error(400, &m),
    };
    let top_n = req
        .query
        .get("top")
        .and_then(|s| s.trim().parse::<usize>().ok())
        .unwrap_or(cfg.scan.top_n)
        .clamp(1, 50);

    let _guard = match state.busy.try_lock() {
        Ok(g) => g,
        Err(TryLockError::Poisoned(p)) => p.into_inner(),
        Err(TryLockError::WouldBlock) => return Response::error(409, "another scan or backtest is still running"),
    };

    let provider = match data::build_provider(&cfg) {
        Ok(p) => p,
        Err(e) => return Response::error(400, &e.to_string()),
    };
    let provider_name = provider.name().to_string();
    let opts = ScanOptions { as_of, now: Utc::now(), top_n };
    set_progress(state, true, "Starting", 0, 0);
    let outcome = scanner::run_scan_with_progress(
        &cfg,
        provider.as_ref(),
        &opts,
        &|phase: &str, done: usize, total: usize| set_progress(state, true, phase, done, total),
    );
    set_progress(state, false, "", 0, 0);
    let result = match outcome {
        Ok(r) => Arc::new(r),
        Err(e) => return Response::error(500, &e.to_string()),
    };

    let resp = Response::json(
        200,
        &ScanApi {
            provider: provider_name,
            index_symbol: &result.index_symbol,
            as_of: result.as_of,
            market: &result.market,
            universe_size: result.universe_size,
            analysed: result.analysed,
            skipped_count: result.skipped.len(),
            skipped_sample: result.skipped.iter().take(10).collect(),
            event_count: result.events.len(),
            ranked: &result.ranked,
        },
    );
    if let Ok(mut slot) = state.last.lock() {
        *slot = Some(Arc::clone(&result));
    }
    resp
}

fn api_scrape_status(state: &AppState) -> Response {
    let key_in_env = std::env::var("STOOQ_API_KEY").map(|v| !v.trim().is_empty()).unwrap_or(false);
    Response::json(
        200,
        &serde_json::json!({
            "python": state.python().map(|p| p.version.clone()),
            "python_help": scrape::PYTHON_MISSING_HELP,
            "csv_dir": state.cfg.data.csv_dir.to_string_lossy(),
            "stooq_key_in_env": key_in_env,
            "default_count": state.cfg.scrape.count,
            "default_years": state.cfg.scrape.years,
            "job": state.scrape.snapshot(),
        }),
    )
}

/// Start the bundled Python scraper (two years of daily prices) in the background.
fn api_scrape_start(state: &AppState, req: &Request) -> Response {
    let python = match state.python() {
        Some(p) => p.clone(),
        None => return Response::error(400, scrape::PYTHON_MISSING_HELP),
    };
    let count = req
        .query
        .get("count")
        .and_then(|s| s.trim().parse::<usize>().ok())
        .unwrap_or(state.cfg.scrape.count)
        .clamp(1, 600);
    let years = req
        .query
        .get("years")
        .and_then(|s| s.trim().parse::<f64>().ok())
        .unwrap_or(state.cfg.scrape.years);
    if !(years >= 0.25 && years <= 5.0) {
        return Response::error(400, "years must be between 0.25 and 5");
    }
    let tickers = req.query.get("tickers").map(|s| s.trim().to_string()).unwrap_or_default();
    if !tickers.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, ',' | '.' | '-' | ' ')) {
        return Response::error(400, "tickers may only contain letters, digits, commas, dots and dashes");
    }
    let script = match scrape::install_script(&scrape::tools_dir()) {
        Ok(p) => p,
        Err(e) => return Response::error(500, &format!("could not write the scraper script: {e}")),
    };
    let args = scrape::build_args(&state.cfg, "prices", count, years, &tickers.replace(' ', ""));
    let key = req.headers.get("x-stooq-key").map(|s| s.as_str());
    match state.scrape.start(&python, &script, &args, key) {
        Ok(()) => api_scrape_status(state),
        Err(Error::Data(m)) if m.contains("already running") => Response::error(409, &m),
        Err(e) => Response::error(500, &e.to_string()),
    }
}

fn api_scrape_cancel(state: &AppState) -> Response {
    let cancelled = state.scrape.cancel();
    Response::json(200, &serde_json::json!({ "cancelled": cancelled }))
}

fn api_progress(state: &AppState) -> Response {
    let snapshot = match state.progress.lock() {
        Ok(p) => p.clone(),
        Err(poisoned) => poisoned.into_inner().clone(),
    };
    Response::json(200, &snapshot)
}

#[derive(Serialize)]
struct DiagStep {
    name: String,
    ok: bool,
    detail: String,
}

fn step(name: &str, ok: bool, detail: String) -> DiagStep {
    DiagStep { name: name.to_string(), ok, detail }
}

/// A quick end-to-end check of the data source (about five requests) so problems
/// with a key, plan or symbol are reported in plain words before a full scan.
fn api_diagnose(state: &AppState, req: &Request) -> Response {
    let cfg = match request_config(state, req) {
        Ok(c) => c,
        Err(m) => return Response::error(400, &m),
    };
    let mut steps: Vec<DiagStep> = Vec::new();

    let provider = match data::build_provider(&cfg) {
        Ok(p) => p,
        Err(e) => {
            steps.push(step("Data source and API key", false, e.to_string()));
            return Response::json(200, &serde_json::json!({ "ok": false, "provider": "", "steps": steps }));
        }
    };
    steps.push(step("Data source and API key", true, format!("'{}' is ready", provider.name())));

    let latest = last_completed_session_estimate(Utc::now(), cfg.data.market_close_buffer_minutes);
    let from = latest - Duration::days(60);

    // 1. constituents
    let mut sample = "AAPL".to_string();
    match provider.constituents() {
        Ok(list) => {
            if let Some(first) = list.first() {
                sample = first.symbol.clone();
            }
            let e_g: Vec<&str> = list.iter().take(3).map(|c| c.symbol.as_str()).collect();
            steps.push(step("S&P 500 constituent list", !list.is_empty(), format!("{} companies (e.g. {})", list.len(), e_g.join(", "))));
        }
        Err(e) => steps.push(step("S&P 500 constituent list", false, e.to_string())),
    }

    // 2. index (with fallback)
    match data::fetch_index(provider.as_ref(), &cfg.data, from, latest) {
        Ok((sym, rows)) => {
            let last = rows.iter().map(|r| r.date).max().map(|d| d.to_string()).unwrap_or_default();
            let note = if sym != cfg.data.index_symbol {
                format!(" ({} had no data, so {sym} is used for the market-trend filter)", cfg.data.index_symbol)
            } else {
                String::new()
            };
            steps.push(step("Index prices (market trend)", true, format!("{} recent bars from {sym}, latest {last}{note}", rows.len())));
        }
        Err(e) => steps.push(step("Index prices (market trend)", false, e.to_string())),
    }

    // 3. one stock
    match provider.history(&sample, from, latest) {
        Ok(rows) if !rows.is_empty() => {
            let last = rows.iter().map(|r| r.date).max().map(|d| d.to_string()).unwrap_or_default();
            steps.push(step("Daily stock prices", true, format!("{} recent bars for {sample}, latest {last}", rows.len())));
        }
        Ok(_) => steps.push(step("Daily stock prices", false, format!("no bars returned for {sample}"))),
        Err(e) => steps.push(step("Daily stock prices", false, e.to_string())),
    }
    let core_ok = steps.iter().all(|s| s.ok);

    // 4. membership history: only needed for backtests, so it never fails the check
    match provider.membership_changes() {
        Ok(ch) if !ch.is_empty() => {
            steps.push(step("Index change history (backtests)", true, format!("{} additions/removals available", ch.len())))
        }
        Ok(_) => steps.push(step(
            "Index change history (backtests)",
            false,
            "none returned: backtests will use today's constituents only (optional)".to_string(),
        )),
        Err(e) => steps.push(step("Index change history (backtests)", false, format!("{e} (optional: backtests only)"))),
    }

    Response::json(200, &serde_json::json!({ "ok": core_ok, "provider": provider.name(), "steps": steps }))
}

#[derive(Serialize)]
struct TickerApi<'a> {
    symbol: String,
    company: &'a str,
    as_of: NaiveDate,
    market: &'a MarketState,
    lookback_sessions: usize,
    event_count: usize,
    best: Option<&'a BreakoutSignal>,
    chart: String,
}

/// Analyse any single ticker (it need not be in the S&P 500) and draw its chart.
fn api_ticker(state: &AppState, req: &Request) -> Response {
    let cfg = match request_config(state, req) {
        Ok(c) => c,
        Err(m) => return Response::error(400, &m),
    };
    let symbol = req.query.get("symbol").map(|s| s.trim().to_uppercase()).unwrap_or_default();
    let valid = !symbol.is_empty()
        && symbol.len() <= 12
        && symbol.chars().all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == '^');
    if !valid {
        return Response::error(400, "enter a ticker symbol such as AAPL or BRK-B");
    }
    let as_of = match parse_date_opt(&req.query, "as_of") {
        Ok(d) => d,
        Err(m) => return Response::error(400, &m),
    };

    let _guard = match state.busy.try_lock() {
        Ok(g) => g,
        Err(TryLockError::Poisoned(p)) => p.into_inner(),
        Err(TryLockError::WouldBlock) => return Response::error(409, "another scan or backtest is still running"),
    };
    let provider = match data::build_provider(&cfg) {
        Ok(p) => p,
        Err(e) => return Response::error(400, &e.to_string()),
    };
    match scanner::analyze_symbol(&cfg, provider.as_ref(), &symbol, as_of, Utc::now()) {
        Ok(a) => {
            let best = scanner::best_signal(&a.signals);
            let svg = chart::render_svg(&symbol, &a.bars, best, &state.cfg);
            Response::json(
                200,
                &TickerApi {
                    symbol: symbol.clone(),
                    company: &a.company,
                    as_of: a.as_of,
                    market: &a.market,
                    lookback_sessions: cfg.breakout.max_age,
                    event_count: a.signals.len(),
                    best,
                    chart: svg,
                },
            )
        }
        Err(e) => Response::error(500, &e.to_string()),
    }
}

fn api_chart(state: &AppState, req: &Request) -> Response {
    let rank = match req.query.get("rank").and_then(|s| s.trim().parse::<usize>().ok()) {
        Some(r) if r >= 1 => r,
        _ => return Response::error(400, "rank must be a positive integer"),
    };
    let last = match state.last.lock() {
        Ok(slot) => slot.clone(),
        Err(p) => p.into_inner().clone(),
    };
    let result = match last {
        Some(r) => r,
        None => return Response::error(404, "run a scan first"),
    };
    let signal = match result.ranked.get(rank - 1) {
        Some(s) => s,
        None => return Response::error(404, "no such rank in the last scan"),
    };
    let bars = match result.history.get(&signal.symbol) {
        Some(b) => b,
        None => return Response::error(404, "no price history kept for that symbol"),
    };
    let svg = chart::render_svg(&signal.symbol, bars, Some(signal), &state.cfg);
    Response::new(200, "image/svg+xml; charset=utf-8", svg.into_bytes())
}

fn api_backtest(state: &AppState, req: &Request) -> Response {
    let cfg = match request_config(state, req) {
        Ok(c) => c,
        Err(m) => return Response::error(400, &m),
    };
    let start = match parse_date_opt(&req.query, "start") {
        Ok(d) => d,
        Err(m) => return Response::error(400, &m),
    };
    let end = match parse_date_opt(&req.query, "end") {
        Ok(d) => d,
        Err(m) => return Response::error(400, &m),
    };
    let now = Utc::now();
    let latest = last_completed_session_estimate(now, cfg.data.market_close_buffer_minutes);
    let end = end.unwrap_or(latest);
    let start = start
        .unwrap_or_else(|| end - Duration::days((cfg.backtest.test_sessions as f64 * 1.45).ceil() as i64));

    let _guard = match state.busy.try_lock() {
        Ok(g) => g,
        Err(TryLockError::Poisoned(p)) => p.into_inner(),
        Err(TryLockError::WouldBlock) => return Response::error(409, "another scan or backtest is still running"),
    };
    let provider = match data::build_provider(&cfg) {
        Ok(p) => p,
        Err(e) => return Response::error(400, &e.to_string()),
    };
    match backtest::engine::run(&cfg, provider.as_ref(), start, end, now) {
        Ok(out) => {
            let summary = metrics::summarize(&out, &cfg);
            let report = metrics::render(&summary, cfg.backtest.min_group_size);
            Response::json(
                200,
                &serde_json::json!({
                    "report": report,
                    "records": out.records.len(),
                    "start": out.start.to_string(),
                    "end": out.end.to_string(),
                }),
            )
        }
        Err(e) => Response::error(500, &e.to_string()),
    }
}

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------

fn bind_first_free(start_port: u16) -> Result<(TcpListener, u16)> {
    for p in start_port..start_port.saturating_add(20) {
        if let Ok(l) = TcpListener::bind(("127.0.0.1", p)) {
            return Ok((l, p));
        }
    }
    Err(Error::Data(format!("no free local port found in {}..{}", start_port, start_port.saturating_add(20))))
}

fn open_browser(url: &str) {
    let spawned = if cfg!(target_os = "windows") {
        std::process::Command::new("cmd").args(["/C", "start", "", url]).spawn()
    } else if cfg!(target_os = "macos") {
        std::process::Command::new("open").arg(url).spawn()
    } else {
        std::process::Command::new("xdg-open").arg(url).spawn()
    };
    if let Err(e) = spawned {
        log::warn!("could not open a browser automatically ({e}); open {url} yourself");
    }
}

/// Start the local web interface and block until the process is stopped.
pub fn serve(cfg: Config, port: u16, open: bool) -> Result<()> {
    let (listener, port) = bind_first_free(port)?;
    let state = Arc::new(AppState::new(cfg));
    let url = format!("http://127.0.0.1:{port}/");

    println!("S&P 500 Breakout Scanner is running at {url}");
    println!("It only listens on this computer. Close this window (or press Ctrl+C) to stop it.");
    if open {
        open_browser(&url);
    }

    for conn in listener.incoming() {
        match conn {
            Ok(stream) => {
                let st = Arc::clone(&state);
                std::thread::spawn(move || {
                    if let Err(e) = handle_connection(&st, stream) {
                        log::debug!("connection error: {e}");
                    }
                });
            }
            Err(e) => log::warn!("accept failed: {e}"),
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn req(path_and_query: &str, headers: &[(&str, &str)]) -> Request {
        let mut raw = format!("GET {path_and_query} HTTP/1.1\r\nHost: 127.0.0.1:8787\r\n");
        for (k, v) in headers {
            raw.push_str(&format!("{k}: {v}\r\n"));
        }
        raw.push_str("\r\n");
        parse_request(&raw).expect("valid request")
    }

    fn state() -> AppState {
        AppState::new(Config::default())
    }

    fn body_json(r: &Response) -> serde_json::Value {
        serde_json::from_slice(&r.body).expect("json body")
    }

    #[test]
    fn url_decoding() {
        assert_eq!(url_decode("a%20b+c"), "a b c");
        assert_eq!(url_decode("2026-11-13"), "2026-11-13");
        assert_eq!(url_decode("100%"), "100%");
        assert_eq!(url_decode("%zz"), "%zz");
        assert_eq!(url_decode("%41%42"), "AB");
    }

    #[test]
    fn request_parsing() {
        let r = parse_request("GET /api/scan?source=fmp&top=5 HTTP/1.1\r\nHost: localhost\r\nX-Token: abc\r\n\r\n").unwrap();
        assert_eq!(r.method, "GET");
        assert_eq!(r.path, "/api/scan");
        assert_eq!(r.query.get("source").map(|s| s.as_str()), Some("fmp"));
        assert_eq!(r.query.get("top").map(|s| s.as_str()), Some("5"));
        assert_eq!(r.headers.get("x-token").map(|s| s.as_str()), Some("abc"));
        assert!(parse_request("").is_none());
    }

    #[test]
    fn index_page_gets_the_session_token_injected() {
        let st = state();
        let resp = handle(&st, &req("/", &[]));
        assert_eq!(resp.status, 200);
        let html = String::from_utf8(resp.body).unwrap();
        assert!(html.contains(&st.token));
        assert!(!html.contains("__TOKEN__"));
        assert!(html.contains("Run scan"));
    }

    #[test]
    fn api_requires_the_token_and_a_local_host() {
        let st = state();
        assert_eq!(handle(&st, &req("/api/info", &[])).status, 401);
        assert_eq!(handle(&st, &req("/api/info", &[("X-Token", "wrong")])).status, 401);
        assert_eq!(handle(&st, &req("/api/info", &[("X-Token", st.token.as_str())])).status, 200);

        let rebinding = parse_request("GET /api/info HTTP/1.1\r\nHost: evil.example.com\r\n\r\n").unwrap();
        assert_eq!(handle(&st, &rebinding).status, 403);

        let post = parse_request("POST /api/scan HTTP/1.1\r\nHost: localhost\r\n\r\n").unwrap();
        assert_eq!(handle(&st, &post).status, 405);
        assert_eq!(handle(&st, &req("/nope", &[])).status, 404);
    }

    #[test]
    fn bad_parameters_are_rejected_politely() {
        let st = state();
        let h = [("X-Token", st.token.as_str())];
        assert_eq!(handle(&st, &req("/api/scan?source=bogus", &h)).status, 400);
        assert_eq!(handle(&st, &req("/api/scan?source=synthetic&as_of=yesterday", &h)).status, 400);
        assert_eq!(handle(&st, &req("/api/chart?rank=1", &h)).status, 404); // no scan yet
        assert_eq!(handle(&st, &req("/api/chart?rank=zero", &h)).status, 400);
    }

    #[test]
    fn missing_fmp_key_gives_a_helpful_message_not_a_crash() {
        let mut cfg = Config::default();
        cfg.data.api_key_env = "SP500_WEB_TEST_KEY_NOT_SET".to_string();
        let st = AppState::new(cfg);
        let h = [("X-Token", st.token.as_str())];
        let resp = handle(&st, &req("/api/scan?source=fmp", &h));
        assert_eq!(resp.status, 400);
        let msg = body_json(&resp)["error"].as_str().unwrap_or("").to_string();
        assert!(msg.contains("API key"), "message was: {msg}");
    }

    #[test]
    fn limit_progress_diagnose_and_ticker_endpoints() {
        let st = state();
        let h = [("X-Token", st.token.as_str())];

        // limit restricts the universe
        let scan = handle(&st, &req("/api/scan?source=synthetic&limit=10", &h));
        assert_eq!(scan.status, 200);
        assert_eq!(body_json(&scan)["universe_size"].as_u64(), Some(10));

        // progress is idle after a scan finishes
        let prog = body_json(&handle(&st, &req("/api/progress", &h)));
        assert_eq!(prog["running"].as_bool(), Some(false));

        // connection test on the demo source
        let diag = body_json(&handle(&st, &req("/api/diagnose?source=synthetic", &h)));
        assert_eq!(diag["ok"].as_bool(), Some(true), "{diag}");
        assert_eq!(diag["steps"].as_array().map(|a| a.len()), Some(5));

        // ticker lookup (SYN002 has a planted LONG breakout)
        let t = handle(&st, &req("/api/ticker?source=synthetic&symbol=syn002", &h));
        assert_eq!(t.status, 200, "{}", String::from_utf8_lossy(&t.body));
        let tv = body_json(&t);
        assert_eq!(tv["symbol"].as_str(), Some("SYN002"));
        assert!(tv["chart"].as_str().unwrap_or("").starts_with("<svg"));

        // bad symbols are rejected
        assert_eq!(handle(&st, &req("/api/ticker?source=synthetic&symbol=", &h)).status, 400);
        assert_eq!(handle(&st, &req("/api/ticker?source=synthetic&symbol=A%20B%3B", &h)).status, 400);
    }

    #[test]
    fn scraper_endpoints_report_status_and_validate_input() {
        let st = state();
        let h = [("X-Token", st.token.as_str())];

        let status = handle(&st, &req("/api/scrape_status", &h));
        assert_eq!(status.status, 200);
        let v = body_json(&status);
        assert_eq!(v["job"]["running"].as_bool(), Some(false));
        assert!(v["python"].is_string() || v["python"].is_null());
        assert!(v["csv_dir"].as_str().unwrap_or("").contains("csv"));

        // bad input is refused (400 whether or not Python happens to be installed here)
        assert_eq!(handle(&st, &req("/api/scrape_start?years=99", &h)).status, 400);
        assert_eq!(handle(&st, &req("/api/scrape_start?tickers=AAPL%3Brm", &h)).status, 400);

        // nothing running, so nothing to cancel
        let cancel = body_json(&handle(&st, &req("/api/scrape_cancel", &h)));
        assert_eq!(cancel["cancelled"].as_bool(), Some(false));
    }

    #[test]
    fn demo_scan_then_chart_end_to_end() {
        let st = state();
        let h = [("X-Token", st.token.as_str())];
        let resp = handle(&st, &req("/api/scan?source=synthetic&top=5", &h));
        assert_eq!(resp.status, 200, "{}", String::from_utf8_lossy(&resp.body));
        let v = body_json(&resp);
        let ranked = v["ranked"].as_array().expect("ranked array");
        assert!(ranked.len() <= 5);
        assert!(ranked.iter().all(|s| matches!(s["classification"].as_str(), Some("FRESH") | Some("DEVELOPING"))));
        assert_eq!(v["provider"].as_str(), Some("synthetic"));

        if !ranked.is_empty() {
            let chart = handle(&st, &req("/api/chart?rank=1", &h));
            assert_eq!(chart.status, 200);
            assert_eq!(chart.content_type, "image/svg+xml; charset=utf-8");
            assert!(String::from_utf8_lossy(&chart.body).starts_with("<svg"));
            assert_eq!(handle(&st, &req("/api/chart?rank=99", &h)).status, 404);
        }
    }
}
