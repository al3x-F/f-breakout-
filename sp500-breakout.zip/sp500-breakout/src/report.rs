//! Output: terminal table, per-signal explanations, JSON and CSV files
//! (spec section 10).

use std::path::Path;

use chrono::NaiveDate;
use serde::Serialize;

use crate::error::Result;
use crate::market::MarketState;
use crate::registry::Change;
use crate::scanner::ScanResult;
use crate::signal::BreakoutSignal;

/// Truncate to at most `n` characters (char-aware, adds `~` when cut).
pub fn trunc(s: &str, n: usize) -> String {
    if s.chars().count() <= n {
        s.to_string()
    } else {
        let mut out: String = s.chars().take(n.saturating_sub(1)).collect();
        out.push('~');
        out
    }
}

/// Greedy word wrap with a hanging indent on every line.
pub fn wrap(text: &str, width: usize, indent: &str) -> String {
    let mut lines: Vec<String> = Vec::new();
    let mut line = String::new();
    for word in text.split_whitespace() {
        if !line.is_empty() && line.chars().count() + 1 + word.chars().count() > width {
            lines.push(std::mem::take(&mut line));
        }
        if !line.is_empty() {
            line.push(' ');
        }
        line.push_str(word);
    }
    if !line.is_empty() {
        lines.push(line);
    }
    lines.iter().map(|l| format!("{indent}{l}")).collect::<Vec<_>>().join("\n")
}

pub fn render_header(r: &ScanResult) -> String {
    let m = &r.market;
    let market = if m.close.is_finite() && m.sma_fast.is_finite() && m.sma_slow.is_finite() {
        format!(
            "{} (index {:.2}, 50d {:.2}, 200d {:.2})",
            m.trend.as_str(),
            m.close,
            m.sma_fast,
            m.sma_slow
        )
    } else {
        format!("{} (insufficient index history)", m.trend.as_str())
    };
    format!(
        "S&P 500 daily breakout scan - analysis date {}\n\
         Market trend : {}\n\
         Universe     : {} constituents, {} analysed, {} skipped\n\
         Breakouts    : {} evaluated, {} FRESH/DEVELOPING shown",
        r.as_of,
        market,
        r.universe_size,
        r.analysed,
        r.skipped.len(),
        r.events.len(),
        r.ranked.len()
    )
}

/// The ranked table with every field required by spec section 10.
pub fn render_table(signals: &[BreakoutSignal]) -> String {
    if signals.is_empty() {
        return "No FRESH or DEVELOPING breakouts met the criteria today.\n".to_string();
    }
    let mut out = String::new();
    out.push_str(&format!(
        "{:>4} {:<6} {:<22} {:<5} {:<10} {:>9} {:>9} {:<10} {:>3} {:>7} {:>4} {:>5} {:>5} {:>4} {:>6} {:>7} {:>6}\n",
        "Rank", "Ticker", "Company", "Dir", "Class", "Close", "Level", "Breakout", "Age", "Ext/ATR", "Rig",
        "RVOL", "Z", "RSI", "BW", "ATR", "Score"
    ));
    out.push_str(&"-".repeat(150));
    out.push('\n');
    for (i, s) in signals.iter().enumerate() {
        out.push_str(&format!(
            "{:>4} {:<6} {:<22} {:<5} {:<10} {:>9.2} {:>9.2} {:<10} {:>3} {:>7.2} {:>4.0} {:>5.2} {:>5.1} {:>4.0} {:>6.3} {:>7.2} {:>6.1}\n",
            i + 1,
            trunc(&s.symbol, 6),
            trunc(&s.company, 22),
            s.direction.as_str(),
            s.classification.as_str(),
            s.close,
            s.level,
            s.breakout_date.to_string(),
            s.age,
            s.extension_atr,
            s.rigidity,
            s.rvol,
            s.volume_z,
            s.rsi,
            s.bandwidth,
            s.atr,
            s.composite
        ));
    }
    out
}

pub fn render_explanations(signals: &[BreakoutSignal]) -> String {
    let mut out = String::new();
    for (i, s) in signals.iter().enumerate() {
        out.push_str(&format!("{}. {} - {} [{} / {}]\n", i + 1, s.symbol, s.company, s.direction, s.classification));
        out.push_str(&wrap(&s.explanation, 104, "   "));
        out.push_str("\n\n");
    }
    out
}

pub fn render_changes(changes: &[Change]) -> String {
    if changes.is_empty() {
        return "No changes since the previous scan.\n".to_string();
    }
    let mut out = String::from("Changes since the previous scan:\n");
    for c in changes {
        out.push_str("  ");
        out.push_str(&c.describe());
        out.push('\n');
    }
    out
}

/// Flat row for CSV (the csv crate cannot serialise nested structs).
#[derive(Serialize)]
struct SignalRow<'a> {
    rank: usize,
    company: &'a str,
    ticker: &'a str,
    direction: &'static str,
    classification: &'static str,
    confirmation: &'static str,
    closing_price: f64,
    breakout_level: f64,
    breakout_date: String,
    breakout_age: usize,
    extension_atr: f64,
    rigidity: f64,
    relative_volume: f64,
    volume_zscore: f64,
    rsi: f64,
    bollinger_bandwidth: f64,
    atr: f64,
    composite_score: f64,
    market_trend: &'static str,
    trend_alignment: &'static str,
    is_continuation: bool,
    explanation: &'a str,
}

pub fn write_csv(path: &Path, signals: &[BreakoutSignal]) -> Result<()> {
    if let Some(parent) = path.parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent)?;
        }
    }
    let mut w = csv::Writer::from_path(path)?;
    for (i, s) in signals.iter().enumerate() {
        w.serialize(SignalRow {
            rank: i + 1,
            company: &s.company,
            ticker: &s.symbol,
            direction: s.direction.as_str(),
            classification: s.classification.as_str(),
            confirmation: s.confirmation.as_str(),
            closing_price: s.close,
            breakout_level: s.level,
            breakout_date: s.breakout_date.to_string(),
            breakout_age: s.age,
            extension_atr: s.extension_atr,
            rigidity: s.rigidity,
            relative_volume: s.rvol,
            volume_zscore: s.volume_z,
            rsi: s.rsi,
            bollinger_bandwidth: s.bandwidth,
            atr: s.atr,
            composite_score: s.composite,
            market_trend: s.market_trend.as_str(),
            trend_alignment: s.trend_alignment.as_str(),
            is_continuation: s.is_continuation,
            explanation: &s.explanation,
        })?;
    }
    w.flush()?;
    Ok(())
}

#[derive(Serialize)]
struct ScanReportJson<'a> {
    as_of: NaiveDate,
    market: &'a MarketState,
    universe_size: usize,
    analysed: usize,
    skipped: &'a [(String, String)],
    warnings: &'a [String],
    ranked: &'a [BreakoutSignal],
    changes: &'a [Change],
}

pub fn write_json(path: &Path, r: &ScanResult, changes: &[Change]) -> Result<()> {
    if let Some(parent) = path.parent() {
        if !parent.as_os_str().is_empty() {
            std::fs::create_dir_all(parent)?;
        }
    }
    let doc = ScanReportJson {
        as_of: r.as_of,
        market: &r.market,
        universe_size: r.universe_size,
        analysed: r.analysed,
        skipped: &r.skipped,
        warnings: &r.warnings,
        ranked: &r.ranked,
        changes,
    };
    std::fs::write(path, serde_json::to_string_pretty(&doc)?)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn trunc_is_char_aware() {
        assert_eq!(trunc("short", 10), "short");
        assert_eq!(trunc("abcdefghij", 5), "abcd~");
        assert_eq!(trunc("ÅÄÖÅÄÖ", 4), "ÅÄÖ~");
    }

    #[test]
    fn wrap_respects_width_and_indent() {
        let text = "one two three four five six seven eight nine ten";
        let wrapped = wrap(text, 15, "  ");
        for line in wrapped.lines() {
            assert!(line.starts_with("  "));
            assert!(line.chars().count() <= 17);
        }
        assert_eq!(wrapped.split_whitespace().count(), 10);
    }

    #[test]
    fn empty_table_has_a_clear_message() {
        assert!(render_table(&[]).contains("No FRESH or DEVELOPING"));
    }
}
