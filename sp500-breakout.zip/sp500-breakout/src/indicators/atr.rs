//! True range and Wilder-smoothed Average True Range.

use crate::types::Bar;

/// True range per bar (the first bar uses its plain high-low range).
pub fn true_range(bars: &[Bar]) -> Vec<f64> {
    let mut out = Vec::with_capacity(bars.len());
    for (i, b) in bars.iter().enumerate() {
        let hl = b.high - b.low;
        if i == 0 {
            out.push(hl);
        } else {
            let pc = bars[i - 1].close;
            out.push(hl.max((b.high - pc).abs()).max((b.low - pc).abs()));
        }
    }
    out
}

/// Wilder ATR. The first value (index `period - 1`) is the simple mean of the
/// first `period` true ranges; later values are Wilder-smoothed.
pub fn atr(bars: &[Bar], period: usize) -> Vec<f64> {
    let n = bars.len();
    let mut out = vec![f64::NAN; n];
    if period == 0 || n < period {
        return out;
    }
    let tr = true_range(bars);
    let p = period as f64;
    let mut a = tr[..period].iter().sum::<f64>() / p;
    out[period - 1] = a;
    for i in period..n {
        a = (a * (p - 1.0) + tr[i]) / p;
        out[i] = a;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn bar(d: u32, o: f64, h: f64, l: f64, c: f64) -> Bar {
        Bar { date: NaiveDate::from_ymd_opt(2024, 1, 1).unwrap() + chrono::Duration::days(d as i64), open: o, high: h, low: l, close: c, volume: 1.0 }
    }

    #[test]
    fn constant_range_gives_that_range() {
        let bars: Vec<Bar> = (0..30).map(|i| bar(i, 100.0, 101.0, 99.0, 100.0)).collect();
        let a = atr(&bars, 14);
        assert!(a[12].is_nan());
        assert!((a[13] - 2.0).abs() < 1e-12);
        assert!((a[29] - 2.0).abs() < 1e-12);
    }

    #[test]
    fn gap_expands_true_range() {
        let bars = vec![bar(0, 100.0, 101.0, 99.0, 100.0), bar(1, 110.0, 111.0, 109.0, 110.0)];
        let tr = true_range(&bars);
        assert_eq!(tr[1], 11.0);
    }
}
