//! Relative Strength Index with Wilder smoothing.

fn rsi_value(avg_gain: f64, avg_loss: f64) -> f64 {
    if avg_loss == 0.0 {
        if avg_gain == 0.0 {
            50.0
        } else {
            100.0
        }
    } else {
        100.0 - 100.0 / (1.0 + avg_gain / avg_loss)
    }
}

/// Wilder RSI over `period` daily closes. First valid index is `period`.
pub fn rsi(close: &[f64], period: usize) -> Vec<f64> {
    let n = close.len();
    let mut out = vec![f64::NAN; n];
    if period == 0 || n <= period {
        return out;
    }
    let p = period as f64;
    let mut gain = 0.0;
    let mut loss = 0.0;
    for i in 1..=period {
        let d = close[i] - close[i - 1];
        if d >= 0.0 {
            gain += d;
        } else {
            loss -= d;
        }
    }
    let mut avg_gain = gain / p;
    let mut avg_loss = loss / p;
    out[period] = rsi_value(avg_gain, avg_loss);
    for i in (period + 1)..n {
        let d = close[i] - close[i - 1];
        let (g, l) = if d >= 0.0 { (d, 0.0) } else { (0.0, -d) };
        avg_gain = (avg_gain * (p - 1.0) + g) / p;
        avg_loss = (avg_loss * (p - 1.0) + l) / p;
        out[i] = rsi_value(avg_gain, avg_loss);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn monotone_rise_is_100() {
        let close: Vec<f64> = (0..30).map(|i| 100.0 + i as f64).collect();
        let r = rsi(&close, 14);
        assert!(r[13].is_nan());
        assert_eq!(r[14], 100.0);
        assert_eq!(r[29], 100.0);
    }

    #[test]
    fn monotone_fall_is_0() {
        let close: Vec<f64> = (0..30).map(|i| 100.0 - i as f64).collect();
        assert_eq!(rsi(&close, 14)[20], 0.0);
    }

    #[test]
    fn alternating_is_near_50() {
        let close: Vec<f64> = (0..60).map(|i| if i % 2 == 0 { 100.0 } else { 101.0 }).collect();
        let r = rsi(&close, 14);
        assert!((r[59] - 50.0).abs() < 5.0);
    }
}
