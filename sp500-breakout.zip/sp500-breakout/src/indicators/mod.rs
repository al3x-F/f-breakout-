//! Technical indicators. Every function is causal: the value at index `i`
//! depends only on bars `0..=i`. Warm-up positions are `f64::NAN`.

pub mod atr;
pub mod bollinger;
pub mod moving_average;
pub mod rsi;

pub use atr::{atr, true_range};
pub use bollinger::{bollinger, Bollinger};
pub use moving_average::{rolling_std, sma};
pub use rsi::rsi;
