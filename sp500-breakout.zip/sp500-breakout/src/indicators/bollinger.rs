//! Bollinger Bands on daily closes.

use super::moving_average::{rolling_std, sma};

#[derive(Debug, Clone)]
pub struct Bollinger {
    pub mid: Vec<f64>,
    pub upper: Vec<f64>,
    pub lower: Vec<f64>,
    /// `(upper - lower) / mid`.
    pub bandwidth: Vec<f64>,
}

/// Standard Bollinger Bands: SMA(`period`) +/- `k` population standard deviations.
pub fn bollinger(close: &[f64], period: usize, k: f64) -> Bollinger {
    let mid = sma(close, period);
    let sd = rolling_std(close, period);
    let n = close.len();
    let mut upper = vec![f64::NAN; n];
    let mut lower = vec![f64::NAN; n];
    let mut bandwidth = vec![f64::NAN; n];
    for i in 0..n {
        if mid[i].is_finite() && sd[i].is_finite() {
            upper[i] = mid[i] + k * sd[i];
            lower[i] = mid[i] - k * sd[i];
            bandwidth[i] = if mid[i] != 0.0 { (upper[i] - lower[i]) / mid[i] } else { f64::NAN };
        }
    }
    Bollinger { mid, upper, lower, bandwidth }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn constant_series_has_zero_bandwidth() {
        let bb = bollinger(&[10.0; 30], 20, 2.0);
        assert!(bb.bandwidth[18].is_nan());
        assert_eq!(bb.bandwidth[19], 0.0);
        assert_eq!(bb.upper[25], 10.0);
    }

    #[test]
    fn bandwidth_expands_with_volatility() {
        let mut close = vec![100.0; 25];
        close.extend([110.0, 90.0, 112.0, 88.0, 115.0]);
        let bb = bollinger(&close, 20, 2.0);
        assert!(bb.bandwidth[29] > bb.bandwidth[24]);
    }
}
