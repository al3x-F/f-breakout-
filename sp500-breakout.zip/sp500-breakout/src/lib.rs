//! # sp500-breakout
//!
//! A daily-timeframe (1D) breakout scanner for the S&P 500. For every
//! constituent it measures support/resistance **rigidity**, volume
//! abnormality, momentum (RSI), volatility (Bollinger Bands, ATR),
//! consolidation and the broad-market trend, detects recent breakouts,
//! classifies them (FRESH / DEVELOPING / EXTENDED / FADING / FAILED), and
//! ranks only the FRESH and DEVELOPING ones by a 0-100 composite score.
//!
//! ## Module map
//!
//! | module            | responsibility                                              | spec § |
//! |-------------------|-------------------------------------------------------------|--------|
//! | [`config`]        | every tunable parameter (defaults = spec values)            | all    |
//! | [`types`]         | bars, directions, classifications, constituents             |        |
//! | [`data`]          | providers (FMP / CSV / synthetic), cache, calendar, integrity | 2    |
//! | [`indicators`]    | SMA, RSI, ATR, Bollinger Bands                              | 6      |
//! | [`volume`]        | RVOL, volume Z-score, abnormality score                     | 5      |
//! | [`levels`]        | swing pivots, ATR-adaptive zones, **rigidity**              | 3, 4   |
//! | [`market`]        | S&P 500 50/200-day trend filter                             | 8.1    |
//! | [`consolidation`] | pre-breakout compression metrics                            | 8.2    |
//! | [`breakout`]      | detection, classification, continuation setups              | 7      |
//! | [`scoring`]       | normalised composite score and explicit adjustments         | 9      |
//! | [`signal`]        | the evaluated signal and its plain-English explanation      | 10     |
//! | [`registry`]      | cross-run memory: original dates, reclassifications         | 12     |
//! | [`scanner`]       | universe orchestration and the FRESH/DEVELOPING gate        | 10     |
//! | [`report`]        | table, explanations, JSON, CSV                              | 10     |
//! | [`chart`]         | SVG candlestick charts                                      | 10     |
//! | [`backtest`]      | no-look-ahead replay, costs, performance statistics         | 11     |
//! | [`web`]           | local browser interface (what the `.exe` opens by default) |        |
//!
//! This is an analytical and research tool. LONG/SHORT labels describe detected
//! market conditions; they are not instructions to trade.

pub mod backtest;
pub mod breakout;
pub mod chart;
pub mod config;
pub mod consolidation;
pub mod data;
pub mod error;
pub mod indicators;
pub mod levels;
pub mod market;
pub mod registry;
pub mod report;
pub mod scanner;
pub mod scoring;
pub mod signal;
pub mod types;
pub mod util;
pub mod volume;
pub mod web;

pub use config::Config;
pub use error::{Error, Result};
