#!/usr/bin/env python3
"""Scrape company data from public web pages into CSV files.

Two commands
------------
``prices``    Two years (configurable) of DAILY price history for many S&P 500 companies.
              Writes ``<out-dir>/<TICKER>.csv`` in the exact layout the sp500-breakout program reads with
              its "Local CSV files" data source (``date,open,high,low,close,adj_close,volume``), plus
              ``constituents.csv`` (``symbol,name,sector``) for the companies that were downloaded, plus
              the market index used for the trend filter.

``profiles``  One row per company (sector, headquarters, revenue, employees, ...) taken from Wikipedia's
              S&P 500 table and each company's own article, written to ``companies.csv``.

Examples
--------
    python scrape_companies.py prices                       # 50 companies, 2 years
    python scrape_companies.py prices --count 200 --years 2
    python scrape_companies.py prices --tickers AAPL,MSFT,KO
    python scrape_companies.py profiles --count 25 --out companies.csv

Needs only Python 3.8+ and an internet connection (no packages to install).

Where the data comes from
-------------------------
* Company list and profiles: Wikipedia (text is CC BY-SA 4.0; the CSV records source URLs).
* Daily prices: Stooq's CSV download (https://stooq.com). Stooq now requires a free API key, which you
  obtain on their site through a CAPTCHA form; supply it with the ``STOOQ_API_KEY`` environment variable
  (preferred, so it never appears in a process list) or ``--stooq-key``. Stooq applies a daily request
  quota; when it is reached the script stops, keeps everything already downloaded, and exits with code 4 -
  run it again later and it carries on (files downloaded in the last 12 hours are skipped).
  Stooq's data is free for non-commercial use; check its terms before relying on it for anything else,
  and note that it is not an official exchange feed (check split adjustment for your use).

Being a good citizen
--------------------
It reads robots.txt and refuses anything disallowed, waits ``--delay`` seconds between requests, retries
politely on 5xx, sends a descriptive User-Agent (please pass ``--contact`` with an email or project URL), and
never prints your API key (it is stripped from every message).

Exit codes: 0 success, 1 failure / nothing downloaded, 2 bad usage, 3 Stooq key missing or rejected,
4 stopped early by Stooq's daily quota (partial data kept).
"""

import argparse
import csv
import hashlib
import io
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from pathlib import Path

LIST_URL = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
STOOQ_URL = "https://stooq.com/q/d/l/"

# Downloaded first, so a small --count gives well-known, liquid companies.
DEFAULT_TICKERS = ["AAPL", "MSFT", "AMZN", "NVDA", "GOOGL", "META", "JPM", "JNJ", "XOM", "WMT"]

STOOQ_INDEX_SYMBOL = "^spx"      # S&P 500 index -> saved as _GSPC.csv (what the program's "^GSPC" maps to)
STOOQ_INDEX_FALLBACK = "spy.us"  # saved as SPY.csv (the program's built-in fallback index symbol)

# CSV column -> infobox labels (lower-case) that may carry it, in order of preference.
INFOBOX_FIELDS = {
    "founded_infobox": ("founded",),
    "headquarters_infobox": ("headquarters",),
    "key_people": ("key people",),
    "revenue": ("revenue",),
    "operating_income": ("operating income",),
    "net_income": ("net income",),
    "total_assets": ("total assets",),
    "total_equity": ("total equity",),
    "employees": ("number of employees", "employees"),
    "website": ("website",),
}

PROFILE_COLUMNS = [
    "ticker", "company", "sector", "sub_industry", "headquarters",
    "date_added_to_index", "cik", "founded",
] + list(INFOBOX_FIELDS) + ["wikipedia_url", "source_url", "scraped_at_utc"]

PRICE_COLUMNS = ["date", "open", "high", "low", "close", "adj_close", "volume"]

EXIT_OK, EXIT_FAIL, EXIT_USAGE, EXIT_KEY, EXIT_QUOTA = 0, 1, 2, 3, 4


class ScrapeError(Exception):
    """Something went wrong that the user should be told about."""


class KeyRequired(ScrapeError):
    """The price site wants an API key we do not have (or rejected the one we sent)."""


class QuotaExceeded(ScrapeError):
    """The price site's daily request quota is used up."""


def redact(text):
    """Remove API keys from URLs / messages before they are shown or logged."""
    return re.sub(r"(apikey=)[^&\s)]+", r"\1***", str(text), flags=re.IGNORECASE)


def say(msg):
    print(msg, flush=True)


# ---------------------------------------------------------------------------
# HTML parsing (standard library only)
# ---------------------------------------------------------------------------

def clean_text(s):
    """Collapse whitespace and drop footnote markers such as [1] or [a]."""
    s = re.sub(r"\[[^\]]{1,8}\]", "", s)
    s = s.replace("\u00a0", " ")
    return re.sub(r"\s+", " ", s).strip()


class TableParser(HTMLParser):
    """Collect the rows of the first <table> accepted by ``match(attrs)``.

    Each row is a list of cells ``{"tag": "th"|"td", "text": str, "href": str|None}``.
    Footnote superscripts, <style> and <script> content are ignored, <br> and list items
    become "; " separators, and tables nested inside the target are skipped.
    """

    def __init__(self, match):
        super().__init__(convert_charrefs=True)
        self.match = match
        self.in_target = False
        self.done = False
        self.table_depth = 0
        self.rows = []
        self._row = None
        self._cell = None
        self._skip = 0

    def _active(self):
        return self.in_target and self.table_depth == 1 and not self.done

    def _close_cell(self):
        raw = "".join(self._cell["parts"])
        lines = [clean_text(x) for x in raw.split("\n")]
        text = "; ".join(x for x in lines if x)
        if self._row is not None:
            self._row.append({"tag": self._cell["tag"], "text": text, "href": self._cell["href"]})
        self._cell = None
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if self.done:
            return
        a = {k: (v or "") for k, v in attrs}
        if tag == "table":
            if not self.in_target and self.match(a):
                self.in_target = True
                self.table_depth = 1
            elif self.in_target:
                self.table_depth += 1
            return
        if not self._active():
            return
        if tag == "tr":
            if self._cell is not None:  # previous cell was never closed
                self._close_cell()
            if self._row:  # previous row was never closed
                self.rows.append(self._row)
            self._row = []
        elif tag in ("th", "td") and self._row is not None:
            if self._cell is not None:  # previous cell was never closed
                self._close_cell()
            self._cell = {"tag": tag, "parts": [], "href": None}
        elif self._cell is not None:
            if tag == "a" and self._cell["href"] is None and a.get("href"):
                self._cell["href"] = a["href"]
            elif tag in ("br", "li", "p", "div"):
                self._cell["parts"].append("\n")
            elif tag in ("sup", "style", "script"):
                self._skip += 1

    def handle_endtag(self, tag):
        if self.done:
            return
        if tag == "table":
            if self.in_target:
                self.table_depth -= 1
                if self.table_depth == 0:
                    if self._cell is not None:
                        self._close_cell()
                    if self._row:
                        self.rows.append(self._row)
                    self._row = None
                    self.in_target = False
                    self.done = True
            return
        if not self._active():
            return
        if tag in ("th", "td") and self._cell is not None:
            self._close_cell()
        elif tag == "tr":
            if self._cell is not None:
                self._close_cell()
            if self._row:
                self.rows.append(self._row)
            self._row = None
        elif tag in ("sup", "style", "script") and self._cell is not None and self._skip > 0:
            self._skip -= 1

    def handle_data(self, data):
        if self._active() and self._cell is not None and self._skip == 0:
            self._cell["parts"].append(data)


def parse_table(html_text, match):
    parser = TableParser(match)
    parser.feed(html_text)
    parser.close()
    return parser.rows


def normalise_ticker(t):
    return t.strip().upper().replace("-", ".")


def parse_constituents(html_text, base_url="https://en.wikipedia.org"):
    """Return ``{ticker: {...}}`` (in page order) from the S&P 500 constituents table."""
    rows = parse_table(html_text, lambda a: a.get("id") == "constituents")
    if len(rows) < 2:
        raise ScrapeError("could not find the S&P 500 constituents table (has the page layout changed?)")
    header = [c["text"].replace("; ", " ").lower() for c in rows[0]]

    def col(*names):
        for i, h in enumerate(header):
            if any(h.startswith(n) for n in names):
                return i
        return None

    ix = {
        "ticker": col("symbol", "ticker"),
        "company": col("security", "company", "name"),
        "sector": col("gics sector", "sector"),
        "sub_industry": col("gics sub", "sub-industry"),
        "headquarters": col("headquarters"),
        "date_added_to_index": col("date"),
        "cik": col("cik"),
        "founded": col("founded"),
    }
    if ix["ticker"] is None or ix["company"] is None:
        raise ScrapeError("the constituents table has no Symbol/Security columns (page layout changed?)")

    def cell(row, key):
        i = ix[key]
        return row[i]["text"] if i is not None and i < len(row) else ""

    out = {}
    for row in rows[1:]:
        if len(row) <= max(ix["ticker"], ix["company"]):
            continue
        ticker = normalise_ticker(cell(row, "ticker"))
        if not ticker:
            continue
        href = row[ix["company"]]["href"]
        rec = {k: cell(row, k) for k in ix}
        rec["ticker"] = ticker
        rec["wikipedia_url"] = urllib.parse.urljoin(base_url, href) if href else ""
        out[ticker] = rec
    return out


def parse_infobox(html_text):
    """Return ``{lower-case label: value}`` from the article's infobox ({} if none)."""
    rows = parse_table(html_text, lambda a: "infobox" in a.get("class", "").split())
    out = {}
    for row in rows:
        if len(row) >= 2 and row[0]["tag"] == "th":
            label = row[0]["text"].lower()
            if label and label not in out:
                out[label] = row[1]["text"]
    return out


def infobox_to_columns(infobox):
    cols = {}
    for column, labels in INFOBOX_FIELDS.items():
        cols[column] = next((infobox[l] for l in labels if infobox.get(l)), "")
    return cols


def choose_tickers(table, count, tickers=None):
    """Pick which companies to scrape: an explicit list, or well-known names first then page order."""
    if tickers:
        wanted = []
        for t in tickers:
            n = normalise_ticker(t)
            if n and n not in wanted:
                wanted.append(n)
        return wanted
    ordered = [t for t in DEFAULT_TICKERS if t in table] + [t for t in table if t not in DEFAULT_TICKERS]
    return ordered[: max(0, count)]


# ---------------------------------------------------------------------------
# Polite downloading
# ---------------------------------------------------------------------------

class Fetcher:
    """HTTP GET with robots.txt checks, rate limiting, retries, key redaction and an optional cache."""

    def __init__(self, user_agent, delay=1.5, cache_dir=None, timeout=30, retries=3):
        self.user_agent = user_agent
        self.delay = max(0.0, delay)
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.timeout = timeout
        self.retries = retries
        self._last_request = 0.0
        self._robots = {}
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    # -- robots.txt ----------------------------------------------------------------
    def _robots_for(self, url):
        parts = urllib.parse.urlsplit(url)
        origin = f"{parts.scheme}://{parts.netloc}"
        if origin in self._robots:
            return self._robots[origin]
        rp = urllib.robotparser.RobotFileParser()
        try:
            self._wait()
            req = urllib.request.Request(origin + "/robots.txt", headers={"User-Agent": self.user_agent})
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                text = resp.read().decode("utf-8", errors="replace")
            rp.parse(text.splitlines())
        except urllib.error.HTTPError as e:
            # Same convention as the standard library: 401/403 = everything disallowed, other errors = allowed.
            rp.parse(["User-agent: *", "Disallow: /"] if e.code in (401, 403) else [])
        except (urllib.error.URLError, OSError):
            rp.parse([])  # cannot read it; the real request will fail loudly if the network is down
        self._robots[origin] = rp
        return rp

    def allowed(self, url):
        return self._robots_for(url).can_fetch(self.user_agent, url)

    # -- downloading -----------------------------------------------------------------
    def _wait(self):
        gap = time.monotonic() - self._last_request
        if gap < self.delay:
            time.sleep(self.delay - gap)
        self._last_request = time.monotonic()

    def _cache_path(self, url):
        return self.cache_dir / (hashlib.sha1(url.encode("utf-8")).hexdigest() + ".html")

    def get(self, url, stop_on_429=False):
        """Download ``url`` as text. ``stop_on_429`` raises QuotaExceeded instead of retrying."""
        shown = redact(url)
        if self.cache_dir:
            path = self._cache_path(url)
            if path.exists():
                return path.read_text(encoding="utf-8")
        if not self.allowed(url):
            raise ScrapeError(f"robots.txt does not allow fetching {shown}")

        last_error = None
        for attempt in range(self.retries + 1):
            self._wait()
            req = urllib.request.Request(
                url, headers={"User-Agent": self.user_agent, "Accept": "text/html,text/csv,*/*"})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    charset = resp.headers.get_content_charset() or "utf-8"
                    text = resp.read().decode(charset, errors="replace")
                if self.cache_dir:
                    self._cache_path(url).write_text(text, encoding="utf-8")
                return text
            except urllib.error.HTTPError as e:
                last_error = f"HTTP {e.code}"
                if e.code == 429 and stop_on_429:
                    raise QuotaExceeded(f"{shown}: HTTP 429 (request quota reached)")
                if e.code == 429 or 500 <= e.code < 600:
                    retry_after = e.headers.get("Retry-After", "") if e.headers else ""
                    pause = min(60, int(retry_after)) if retry_after.isdigit() else 2 ** (attempt + 1)
                    time.sleep(pause)
                    continue
                raise ScrapeError(f"{shown}: {last_error}")
            except (urllib.error.URLError, OSError) as e:
                last_error = redact(e)
                time.sleep(2 ** (attempt + 1))
        raise ScrapeError(f"{shown}: giving up after {self.retries + 1} attempts ({last_error})")


# ---------------------------------------------------------------------------
# Prices (Stooq)
# ---------------------------------------------------------------------------

def stooq_symbol(ticker):
    """AAPL -> aapl.us ; BRK.B -> brk-b.us"""
    return ticker.strip().lower().replace(".", "-") + ".us"


def stooq_url(symbol, start, end, key=""):
    params = [("s", symbol), ("d1", start.strftime("%Y%m%d")), ("d2", end.strftime("%Y%m%d")), ("i", "d")]
    if key:
        params.append(("apikey", key))
    return STOOQ_URL + "?" + urllib.parse.urlencode(params)


def safe_name(symbol):
    """Same file-name rule as the Rust program: ^GSPC -> _GSPC, BRK.B stays BRK.B."""
    return "".join(c if (c.isascii() and c.isalnum()) or c in ".-_" else "_" for c in symbol)


def parse_stooq_csv(text, start=None):
    """Parse Stooq's CSV into ascending ``(date, open, high, low, close, volume)`` tuples.

    Raises QuotaExceeded / KeyRequired for Stooq's plain-text refusals; returns [] for "No data".
    """
    body = (text or "").strip()
    low = body.lower()
    if "exceeded the daily hits limit" in low:
        raise QuotaExceeded("Stooq's daily request limit has been reached")
    if not low.startswith("date,"):
        if "apikey" in low or "api key" in low:
            raise KeyRequired("Stooq wants an API key (or rejected the one given)")
        return []
    reader = csv.reader(io.StringIO(body))
    header = [h.strip().lower() for h in next(reader, [])]
    try:
        ix = {k: header.index(k) for k in ("date", "open", "high", "low", "close")}
    except ValueError:
        return []
    vol_ix = header.index("volume") if "volume" in header else None
    rows = {}
    for r in reader:
        try:
            d = datetime.strptime(r[ix["date"]].strip(), "%Y-%m-%d").date()
            o, h, l, c = (float(r[ix[k]]) for k in ("open", "high", "low", "close"))
        except (ValueError, IndexError):
            continue
        if min(o, h, l, c) <= 0 or (start and d < start):
            continue
        try:
            v = float(r[vol_ix]) if vol_ix is not None and r[vol_ix].strip() else 0.0
        except (ValueError, IndexError):
            v = 0.0
        rows[d] = (d, o, h, l, c, v)
    return [rows[d] for d in sorted(rows)]


def write_price_csv(path, rows):
    """Write bars in the layout the Rust program's CSV provider reads. adj_close = close."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".csv.tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(PRICE_COLUMNS)
        for d, o, h, l, c, v in rows:
            w.writerow([d.isoformat(), repr(o), repr(h), repr(l), repr(c), repr(c), repr(v)])
    os.replace(tmp, path)


def is_fresh(path, max_age_hours=12):
    """Was this file written recently enough to skip re-downloading it?"""
    try:
        st = Path(path).stat()
    except OSError:
        return False
    return st.st_size > 100 and (time.time() - st.st_mtime) < max_age_hours * 3600


def write_constituents(path, entries):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["symbol", "name", "sector"])
        for sym, name, sector in entries:
            w.writerow([sym, name, sector])


def download_prices(fetcher, symbol, start, end, key):
    text = fetcher.get(stooq_url(symbol, start, end, key), stop_on_429=True)
    return parse_stooq_csv(text, start)


def run_prices(args, fetcher, today=None):
    """Download daily prices for the chosen companies. Returns an exit code."""
    key = (args.stooq_key or os.environ.get("STOOQ_API_KEY", "")).strip()
    out_dir = Path(args.out_dir)
    end = today or datetime.now(timezone.utc).date()
    start = end - timedelta(days=int(args.years * 365) + 35)

    say("Downloading the company list from Wikipedia ...")
    table = parse_constituents(fetcher.get(LIST_URL))
    requested = [t for t in args.tickers.split(",") if t.strip()] if args.tickers else None
    tickers = choose_tickers(table, args.count, requested)
    for t in [t for t in tickers if t not in table]:
        say(f"{t}: not in the current S&P 500 table, skipped")
    tickers = [t for t in tickers if t in table]
    if not tickers:
        say("error: no companies to download")
        return EXIT_FAIL
    if not key:
        say("note: no Stooq API key supplied (STOOQ_API_KEY). Stooq may refuse the downloads; "
            "get a free key on stooq.com and try again.")

    total = len(tickers) + 1  # the market index counts as one step
    say(f"Downloading {args.years:g} years of daily prices for {len(tickers)} companies "
        f"({start} to {end}) into {out_dir}")
    say(f"PROGRESS 0 {total}")

    status = EXIT_OK
    ok, failed, skipped = [], [], []
    done = 0
    try:
        # 1. the market index (trend filter): S&P 500 index, falling back to the SPY ETF
        index_ok = False
        for stooq_sym, fname in ((STOOQ_INDEX_SYMBOL, "_GSPC.csv"), (STOOQ_INDEX_FALLBACK, "SPY.csv")):
            target = out_dir / fname
            if not args.force and is_fresh(target):
                say(f"index {fname}: fresh file found, skipped")
                index_ok = True
                break
            rows = download_prices(fetcher, stooq_sym, start, end, key)
            if rows:
                write_price_csv(target, rows)
                say(f"index {fname}: {len(rows)} days saved")
                index_ok = True
                break
            say(f"index {stooq_sym}: no data returned")
        if not index_ok:
            say("warning: no market index data; the scanner's trend filter will be neutral")
        done += 1
        say(f"PROGRESS {done} {total}")

        # 2. the companies
        for i, t in enumerate(tickers, 1):
            target = out_dir / (safe_name(t) + ".csv")
            if not args.force and is_fresh(target):
                skipped.append(t)
                say(f"[{i}/{len(tickers)}] {t}: fresh file found, skipped")
            else:
                try:
                    rows = download_prices(fetcher, stooq_symbol(t), start, end, key)
                except (KeyRequired, QuotaExceeded):
                    raise
                except ScrapeError as e:
                    failed.append(t)
                    say(f"[{i}/{len(tickers)}] {t}: failed ({redact(e)})")
                    rows = None
                if rows:
                    write_price_csv(target, rows)
                    ok.append(t)
                    say(f"[{i}/{len(tickers)}] {t}: {len(rows)} days saved ({rows[0][0]} .. {rows[-1][0]})")
                elif rows is not None:
                    failed.append(t)
                    say(f"[{i}/{len(tickers)}] {t}: no data returned, skipped")
            done += 1
            say(f"PROGRESS {done} {total}")
    except KeyRequired as e:
        say(f"error: {redact(e)}. Get a free key from stooq.com (it is issued through a CAPTCHA form) "
            f"and set STOOQ_API_KEY.")
        status = EXIT_KEY
    except QuotaExceeded as e:
        say(f"stopped early: {redact(e)}. Everything downloaded so far is kept; run again later to continue.")
        status = EXIT_QUOTA
    finally:
        have = [t for t in tickers if t in ok or t in skipped]
        if have:
            write_constituents(args.constituents, [(t, table[t]["company"], table[t]["sector"]) for t in have])
            say(f"constituents list written: {args.constituents} ({len(have)} companies)")

    say(f"RESULT downloaded={len(ok)} skipped_fresh={len(skipped)} failed={len(failed)}")
    if status == EXIT_KEY:
        return EXIT_KEY
    if status == EXIT_QUOTA:
        return EXIT_QUOTA if (ok or skipped) else EXIT_FAIL
    if not (ok or skipped):
        say("error: nothing was downloaded")
        return EXIT_FAIL
    say(f"Done. In the program choose 'Local CSV files' as the data source to scan these "
        f"{len(ok) + len(skipped)} companies.")
    return EXIT_OK


# ---------------------------------------------------------------------------
# Profiles (Wikipedia)
# ---------------------------------------------------------------------------

def scrape_profiles(tickers, table, fetcher, with_infobox=True, log=say):
    """Return ``(rows, warnings)`` for the requested tickers."""
    warnings = []
    rows = []
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    total = len(tickers)
    log(f"PROGRESS 0 {total}")
    for i, t in enumerate(tickers, 1):
        rec = table.get(t)
        if rec is None:
            warnings.append(f"{t}: not in the current S&P 500 table, skipped")
            log(f"PROGRESS {i} {total}")
            continue
        row = {c: "" for c in PROFILE_COLUMNS}
        row.update({k: v for k, v in rec.items() if k in row})
        row["source_url"] = LIST_URL
        row["scraped_at_utc"] = now
        if with_infobox and rec["wikipedia_url"]:
            log(f"[{i}/{total}] {t}: reading {rec['wikipedia_url']}")
            try:
                box = parse_infobox(fetcher.get(rec["wikipedia_url"]))
                if not box:
                    warnings.append(f"{t}: no infobox found on the company page")
                row.update(infobox_to_columns(box))
            except ScrapeError as e:
                warnings.append(f"{t}: could not read the company page ({redact(e)})")
        rows.append(row)
        log(f"PROGRESS {i} {total}")
    return rows, warnings


def write_profiles_csv(path, rows):
    path = Path(path)
    if path.parent and not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
    # utf-8-sig so Excel opens accented characters correctly.
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=PROFILE_COLUMNS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def run_profiles(args, fetcher):
    say(f"Downloading the S&P 500 table from {LIST_URL} ...")
    table = parse_constituents(fetcher.get(LIST_URL))
    say(f"  found {len(table)} companies in the table")
    requested = [t for t in args.tickers.split(",") if t.strip()] if args.tickers else None
    tickers = choose_tickers(table, args.count, requested)
    rows, warnings = scrape_profiles(tickers, table, fetcher, with_infobox=not args.no_infobox)
    if not rows:
        say("error: none of the requested tickers were found")
        for w in warnings:
            say("  " + w)
        return EXIT_FAIL
    write_profiles_csv(args.out, rows)
    say(f"\nWrote {len(rows)} companies to {args.out}")
    for w in warnings:
        say("warning: " + w)
    return EXIT_OK


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def build_parser():
    p = argparse.ArgumentParser(description="Scrape company data from public web pages into CSV files.")
    p.add_argument("--contact", default="",
                   help="your email or project URL, added to the User-Agent as Wikimedia requests")
    sub = p.add_subparsers(dest="command", required=True)

    pr = sub.add_parser("prices", help="daily price history for many companies (feeds the program's CSV source)")
    pr.add_argument("--count", type=int, default=50,
                    help="how many companies (default %(default)s; the whole index is ~500)")
    pr.add_argument("--years", type=float, default=2.0, help="years of history (default %(default)s)")
    pr.add_argument("--tickers", default="", help="comma-separated tickers instead of --count")
    pr.add_argument("--out-dir", default="data/csv", help="folder for <TICKER>.csv files (default %(default)s)")
    pr.add_argument("--constituents", default="data/constituents.csv",
                    help="constituents CSV to write (default %(default)s)")
    pr.add_argument("--stooq-key", default="", help="Stooq API key (prefer the STOOQ_API_KEY environment variable)")
    pr.add_argument("--delay", type=float, default=1.0, help="seconds between requests (default %(default)s)")
    pr.add_argument("--force", action="store_true", help="re-download files fetched in the last 12 hours")

    pf = sub.add_parser("profiles", help="one row of profile data per company (Wikipedia)")
    pf.add_argument("--count", type=int, default=10, help="how many companies (default %(default)s)")
    pf.add_argument("--tickers", default="", help="comma-separated tickers instead of --count")
    pf.add_argument("--out", default="companies.csv", help="output CSV (default %(default)s)")
    pf.add_argument("--delay", type=float, default=1.5, help="seconds between requests (default %(default)s)")
    pf.add_argument("--no-infobox", action="store_true", help="only the S&P 500 table (1 request)")
    pf.add_argument("--cache-dir", default=".scrape_cache", help="where downloaded pages are cached")
    pf.add_argument("--no-cache", action="store_true", help="always download fresh copies")
    return p


def main(argv=None, fetcher=None, today=None):
    args = build_parser().parse_args(argv)
    if args.count < 1 and not args.tickers:
        print("error: --count must be at least 1", file=sys.stderr)
        return EXIT_USAGE
    contact = args.contact.strip() or "set --contact to your email"
    ua = f"sp500-breakout-research-scraper/1.0 (+personal research; {contact})"
    try:
        if args.command == "prices":
            if fetcher is None:
                # no cache: a cached refusal or quota notice would otherwise be replayed forever
                fetcher = Fetcher(ua, delay=args.delay, cache_dir=None)
            return run_prices(args, fetcher, today=today)
        if fetcher is None:
            fetcher = Fetcher(ua, delay=args.delay, cache_dir=None if args.no_cache else args.cache_dir)
        return run_profiles(args, fetcher)
    except ScrapeError as e:
        print(f"error: {redact(e)}", file=sys.stderr)
        return EXIT_FAIL


if __name__ == "__main__":
    sys.exit(main())
