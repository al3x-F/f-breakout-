"""Offline tests for scrape_companies.py (no internet needed): python -m unittest -v"""

import csv
import io
import os
import tempfile
import unittest
import urllib.parse
from contextlib import redirect_stdout
from datetime import date, timedelta

import scrape_companies as sc

CONSTITUENTS_HTML = """<html><body>
<table class="wikitable sortable" id="constituents"><tbody>
<tr><th><a href="/wiki/Ticker_symbol">Symbol</a></th><th>Security</th><th>GICS<br>Sector</th><th>GICS Sub-Industry</th>
<th>Headquarters Location</th><th>Date added</th><th>CIK</th><th>Founded</th></tr>
<tr><td><a rel="nofollow" class="external text" href="https://www.nyse.com/quote/XNYS:AOS">AOS</a></td>
<td><a href="/wiki/A._O._Smith" title="A. O. Smith">A. O. Smith</a></td><td>Industrials</td><td>Building Products</td>
<td>Milwaukee, Wisconsin</td><td>2017-07-26</td><td>0000091142</td><td>1916</td></tr>
<tr><td><a rel="nofollow" class="external text" href="https://www.nasdaq.com/market-activity/stocks/aapl">AAPL</a></td>
<td><a href="/wiki/Apple_Inc." title="Apple Inc.">Apple Inc.</a></td><td>Information Technology</td>
<td>Technology Hardware, Storage &amp; Peripherals</td><td>Cupertino, California</td><td>1982-11-30</td>
<td>0000320193</td><td>1977</td></tr>
<tr><td><a href="#">BRK.B</a></td><td><a href="/wiki/Berkshire_Hathaway">Berkshire Hathaway</a></td><td>Financials</td>
<td>Multi-Sector Holdings</td><td>Omaha, Nebraska</td><td>2010-02-16</td><td>0001067983</td><td>1839</td></tr>
</tbody></table>
<table class="wikitable" id="changes"><tr><th>other</th></tr><tr><td>ignored</td></tr></table>
</body></html>"""

APPLE_HTML = """<html><body>
<table class="infobox vcard"><tbody>
<tr><th colspan="2" class="infobox-above">Apple Inc.</th></tr>
<tr><th scope="row" class="infobox-label">Founded</th><td class="infobox-data">April 1, 1976<sup class="reference"><a href="#cite_note-1">[1]</a></sup></td></tr>
<tr><th scope="row" class="infobox-label">Headquarters</th><td class="infobox-data">Apple Park, Cupertino, California, U.S.</td></tr>
<tr><th scope="row" class="infobox-label">Key people</th><td class="infobox-data"><style>.mw-parser-output .plainlist{margin:0}</style>
<div class="plainlist"><ul><li>Arthur Levinson (chairman)</li><li>Tim Cook (CEO)</li></ul></div></td></tr>
<tr><th scope="row" class="infobox-label">Revenue</th><td class="infobox-data">US$391.0&nbsp;billion<sup>[2]</sup> (2024)</td></tr>
<tr><th scope="row" class="infobox-label">Number of employees</th><td class="infobox-data">164,000 (2023)</td></tr>
<tr><th scope="row" class="infobox-label">Website</th><td class="infobox-data"><a href="https://apple.com">apple.com</a></td></tr>
<tr><td colspan="2"><table><tr><th>Nested</th><td>should be ignored</td></tr></table></td></tr>
</tbody></table>
<table class="infobox"><tr><th>Founded</th><td>wrong second infobox</td></tr></table>
</body></html>"""

TODAY = date(2026, 11, 13)
KEY = "SUPERSECRETKEY123"


def stooq_csv(first_year=2024, last=TODAY, base=100.0):
    """A Stooq-style CSV with one row per weekday from Jan 1 of first_year to `last`."""
    lines = ["Date,Open,High,Low,Close,Volume"]
    d, n = date(first_year, 1, 1), 0
    while d <= last:
        if d.weekday() < 5:
            c = base + n * 0.1
            lines.append(f"{d.isoformat()},{c - 0.2:.2f},{c + 0.5:.2f},{c - 0.6:.2f},{c:.2f},{1000000 + n}")
            n += 1
        d += timedelta(days=1)
    return "\n".join(lines) + "\n"


class FakeFetcher:
    """Serves fixtures instead of touching the network."""

    def __init__(self, pages=None, stooq=None):
        self.pages = pages or {}
        self.stooq = stooq or {}
        self.requested = []

    def get(self, url, stop_on_429=False):
        self.requested.append(url)
        if url.startswith(sc.STOOQ_URL):
            sym = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)["s"][0]
            return self.stooq.get(sym, "No data")
        if url not in self.pages:
            raise sc.ScrapeError(f"{url}: HTTP 404")
        return self.pages[url]

    def stooq_requests(self):
        return [u for u in self.requested if u.startswith(sc.STOOQ_URL)]


def run_main(argv, fetcher):
    buf = io.StringIO()
    with redirect_stdout(buf):
        code = sc.main(argv, fetcher=fetcher, today=TODAY)
    return code, buf.getvalue()


# ---------------------------------------------------------------------------

class ParsingTests(unittest.TestCase):
    def test_clean_text_removes_footnotes_and_whitespace(self):
        self.assertEqual(sc.clean_text("  a\u00a0 b [1] [a]\n c "), "a b c")

    def test_constituents_table(self):
        t = sc.parse_constituents(CONSTITUENTS_HTML)
        self.assertEqual(list(t), ["AOS", "AAPL", "BRK.B"])  # page order kept
        a = t["AAPL"]
        self.assertEqual(a["company"], "Apple Inc.")
        self.assertEqual(a["sector"], "Information Technology")  # header split by <br> still matched
        self.assertEqual(a["sub_industry"], "Technology Hardware, Storage & Peripherals")
        self.assertEqual(a["headquarters"], "Cupertino, California")
        self.assertEqual(a["date_added_to_index"], "1982-11-30")
        self.assertEqual(a["cik"], "0000320193")
        self.assertEqual(a["founded"], "1977")
        self.assertEqual(a["wikipedia_url"], "https://en.wikipedia.org/wiki/Apple_Inc.")

    def test_missing_table_is_a_clear_error(self):
        with self.assertRaises(sc.ScrapeError):
            sc.parse_constituents("<html><body><p>nothing here</p></body></html>")

    def test_infobox(self):
        box = sc.parse_infobox(APPLE_HTML)
        self.assertEqual(box["founded"], "April 1, 1976")
        self.assertEqual(box["revenue"], "US$391.0 billion (2024)")
        self.assertEqual(box["key people"], "Arthur Levinson (chairman); Tim Cook (CEO)")
        self.assertEqual(box["website"], "apple.com")
        self.assertNotIn("nested", box)

    def test_infobox_to_columns_uses_aliases_and_blanks(self):
        cols = sc.infobox_to_columns(sc.parse_infobox(APPLE_HTML))
        self.assertEqual(cols["employees"], "164,000 (2023)")
        self.assertEqual(cols["net_income"], "")

    def test_ticker_normalisation(self):
        self.assertEqual(sc.normalise_ticker(" brk-b "), "BRK.B")

    def test_tolerates_unclosed_cells_and_rows(self):
        html = '<table id="constituents"><tr><th>Symbol<th>Security<tr><td>X<td>Xco</table>'
        rows = sc.parse_table(html, lambda a: a.get("id") == "constituents")
        self.assertEqual([[c["text"] for c in r] for r in rows], [["Symbol", "Security"], ["X", "Xco"]])

    def test_choose_tickers(self):
        table = sc.parse_constituents(CONSTITUENTS_HTML)
        self.assertEqual(sc.choose_tickers(table, 2), ["AAPL", "AOS"])  # well-known first, then page order
        self.assertEqual(sc.choose_tickers(table, 99), ["AAPL", "AOS", "BRK.B"])
        self.assertEqual(sc.choose_tickers(table, 1, ["brk-b", "BRK.B", "zz"]), ["BRK.B", "ZZ"])


class StooqTests(unittest.TestCase):
    def test_symbol_mapping_and_url(self):
        self.assertEqual(sc.stooq_symbol("AAPL"), "aapl.us")
        self.assertEqual(sc.stooq_symbol("BRK.B"), "brk-b.us")
        url = sc.stooq_url("^spx", date(2024, 10, 1), date(2026, 11, 13), "abc")
        self.assertIn("s=%5Espx", url)
        self.assertIn("d1=20241001", url)
        self.assertIn("d2=20261113", url)
        self.assertIn("i=d", url)
        self.assertIn("apikey=abc", url)
        self.assertNotIn("apikey", sc.stooq_url("aapl.us", date(2024, 1, 1), date(2024, 2, 1), ""))

    def test_keys_are_redacted(self):
        url = sc.stooq_url("aapl.us", date(2024, 1, 1), date(2024, 2, 1), KEY)
        shown = sc.redact(url)
        self.assertNotIn(KEY, shown)
        self.assertIn("apikey=***", shown)
        self.assertNotIn(KEY, sc.redact(f"failed ({url})"))

    def test_parse_good_csv_filters_dedupes_and_sorts(self):
        text = ("Date,Open,High,Low,Close,Volume\n2025-01-03,2,3,1,2.5,100\n2024-12-30,1,2,0.5,1.5,50\n"
                "2025-01-03,9,9,9,9,9\nbad,row\n2025-01-06,0,0,0,0,1\n2025-01-07,3,4,2,3.5,\n")
        rows = sc.parse_stooq_csv(text, date(2025, 1, 1))
        self.assertEqual([r[0] for r in rows], [date(2025, 1, 3), date(2025, 1, 7)])
        self.assertEqual(rows[0][4], 9.0)       # the later duplicate wins
        self.assertEqual(rows[1][5], 0.0)       # empty volume -> 0
        self.assertEqual(len(sc.parse_stooq_csv(text)), 3)  # without a start date, the older row is kept too

    def test_refusals_are_classified(self):
        self.assertEqual(sc.parse_stooq_csv("No data"), [])
        with self.assertRaises(sc.QuotaExceeded):
            sc.parse_stooq_csv("Exceeded the daily hits limit")
        with self.assertRaises(sc.KeyRequired):
            sc.parse_stooq_csv("Get your apikey: visit the download page")

    def test_price_csv_matches_the_rust_programs_layout(self):
        rows = sc.parse_stooq_csv(stooq_csv(2025, date(2025, 1, 10)))
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "x", "AAPL.csv")
            sc.write_price_csv(path, rows)
            with open(path, newline="") as f:
                data = list(csv.reader(f))
        self.assertEqual(data[0], ["date", "open", "high", "low", "close", "adj_close", "volume"])
        self.assertEqual(len(data) - 1, len(rows))
        first = dict(zip(data[0], data[1]))
        self.assertEqual(first["close"], first["adj_close"])
        self.assertEqual(first["date"], "2025-01-01")  # Wednesday; New Year's Day rows are not special-cased
        self.assertEqual([r[0] for r in data[1:]], sorted(r[0] for r in data[1:]))

    def test_safe_name_matches_the_rust_rule(self):
        self.assertEqual(sc.safe_name("^GSPC"), "_GSPC")
        self.assertEqual(sc.safe_name("BRK.B"), "BRK.B")


class PricesCommandTests(unittest.TestCase):
    def fetcher(self, **extra):
        stooq = {"aapl.us": stooq_csv(base=150), "aos.us": stooq_csv(base=60), "brk-b.us": stooq_csv(base=400),
                 "^spx": stooq_csv(base=4500)}
        stooq.update(extra)
        return FakeFetcher(pages={sc.LIST_URL: CONSTITUENTS_HTML}, stooq=stooq)

    def paths(self, d):
        return os.path.join(d, "csv"), os.path.join(d, "constituents.csv")

    def test_downloads_two_years_and_writes_everything_the_program_needs(self):
        with tempfile.TemporaryDirectory() as d:
            out, cons = self.paths(d)
            f = self.fetcher()
            code, text = run_main(["prices", "--count", "3", "--out-dir", out, "--constituents", cons,
                                   "--stooq-key", KEY], f)
            self.assertEqual(code, sc.EXIT_OK, text)
            self.assertEqual(sorted(os.listdir(out)), ["AAPL.csv", "AOS.csv", "BRK.B.csv", "_GSPC.csv"])
            self.assertIn("PROGRESS 4 4", text)
            self.assertNotIn(KEY, text)  # the key is never printed

            # two years of history requested and delivered
            start = TODAY - timedelta(days=int(2 * 365) + 35)
            self.assertTrue(all(f"d1={start.strftime('%Y%m%d')}" in u for u in f.stooq_requests()))
            with open(os.path.join(out, "AAPL.csv"), newline="") as fh:
                rows = list(csv.DictReader(fh))
            self.assertGreater(len(rows), 480)
            self.assertGreaterEqual(rows[0]["date"], start.isoformat())
            self.assertEqual(rows[-1]["date"], TODAY.isoformat())

            with open(cons, newline="") as fh:
                c = list(csv.DictReader(fh))
            self.assertEqual([r["symbol"] for r in c], ["AAPL", "AOS", "BRK.B"])
            self.assertEqual(c[0]["name"], "Apple Inc.")
            self.assertEqual(c[0]["sector"], "Information Technology")

    def test_second_run_skips_fresh_files_and_force_redownloads(self):
        with tempfile.TemporaryDirectory() as d:
            out, cons = self.paths(d)
            args = ["prices", "--count", "3", "--out-dir", out, "--constituents", cons, "--stooq-key", KEY]
            run_main(args, self.fetcher())
            f2 = self.fetcher()
            code, text = run_main(args, f2)
            self.assertEqual(code, sc.EXIT_OK)
            self.assertEqual(f2.stooq_requests(), [])
            self.assertIn("fresh file found, skipped", text)
            f3 = self.fetcher()
            run_main(args + ["--force"], f3)
            self.assertEqual(len(f3.stooq_requests()), 4)  # index + 3 companies

    def test_quota_stops_early_but_keeps_what_was_downloaded(self):
        with tempfile.TemporaryDirectory() as d:
            out, cons = self.paths(d)
            f = self.fetcher(**{"aos.us": "Exceeded the daily hits limit"})
            code, text = run_main(["prices", "--count", "3", "--out-dir", out, "--constituents", cons,
                                   "--stooq-key", KEY], f)
            self.assertEqual(code, sc.EXIT_QUOTA)
            self.assertIn("stopped early", text)
            self.assertTrue(os.path.exists(os.path.join(out, "AAPL.csv")))
            self.assertFalse(os.path.exists(os.path.join(out, "BRK.B.csv")))  # never reached
            with open(cons, newline="") as fh:
                self.assertEqual([r["symbol"] for r in csv.DictReader(fh)], ["AAPL"])

    def test_missing_key_gives_exit_code_3_and_clear_advice(self):
        with tempfile.TemporaryDirectory() as d:
            out, cons = self.paths(d)
            f = self.fetcher(**{"^spx": "Get your apikey: visit the download page"})
            code, text = run_main(["prices", "--count", "2", "--out-dir", out, "--constituents", cons], f)
            self.assertEqual(code, sc.EXIT_KEY)
            self.assertIn("STOOQ_API_KEY", text)
            self.assertFalse(os.path.exists(cons))  # nothing downloaded, nothing claimed

    def test_index_falls_back_to_spy(self):
        with tempfile.TemporaryDirectory() as d:
            out, cons = self.paths(d)
            f = self.fetcher(**{"^spx": "No data", "spy.us": stooq_csv(base=450)})
            code, _ = run_main(["prices", "--count", "1", "--out-dir", out, "--constituents", cons,
                                "--stooq-key", KEY], f)
            self.assertEqual(code, sc.EXIT_OK)
            self.assertIn("SPY.csv", os.listdir(out))
            self.assertNotIn("_GSPC.csv", os.listdir(out))

    def test_unknown_tickers_and_empty_results_fail_cleanly(self):
        with tempfile.TemporaryDirectory() as d:
            out, cons = self.paths(d)
            code, text = run_main(["prices", "--tickers", "ZZZZ", "--out-dir", out, "--constituents", cons], self.fetcher())
            self.assertEqual(code, sc.EXIT_FAIL)
            self.assertIn("not in the current S&P 500 table", text)
            f = self.fetcher(**{"aapl.us": "No data"})
            code, text = run_main(["prices", "--tickers", "AAPL", "--out-dir", out, "--constituents", cons], f)
            self.assertEqual(code, sc.EXIT_FAIL)
            self.assertIn("no data returned", text)

    def test_bad_count_is_a_usage_error(self):
        code = sc.main(["prices", "--count", "0"], fetcher=self.fetcher(), today=TODAY)
        self.assertEqual(code, sc.EXIT_USAGE)


class ProfilesCommandTests(unittest.TestCase):
    def pages(self):
        return {
            sc.LIST_URL: CONSTITUENTS_HTML,
            "https://en.wikipedia.org/wiki/Apple_Inc.": APPLE_HTML,
            "https://en.wikipedia.org/wiki/A._O._Smith": "<html><body>no infobox</body></html>",
        }

    def test_profiles_with_infobox_and_warnings(self):
        table = sc.parse_constituents(CONSTITUENTS_HTML)
        rows, warnings = sc.scrape_profiles(["AAPL", "AOS", "NOPE", "BRK.B"], table, FakeFetcher(self.pages()),
                                            log=lambda *_: None)
        self.assertEqual([r["ticker"] for r in rows], ["AAPL", "AOS", "BRK.B"])
        self.assertEqual(rows[0]["revenue"], "US$391.0 billion (2024)")
        self.assertEqual(rows[0]["source_url"], sc.LIST_URL)
        joined = " | ".join(warnings)
        self.assertIn("NOPE: not in the current S&P 500 table", joined)
        self.assertIn("AOS: no infobox", joined)
        self.assertIn("BRK.B: could not read the company page", joined)

    def test_profiles_command_writes_a_csv(self):
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "out", "companies.csv")
            code, text = run_main(["profiles", "--count", "2", "--out", out], FakeFetcher(self.pages()))
            self.assertEqual(code, sc.EXIT_OK)
            with open(out, newline="", encoding="utf-8-sig") as f:
                data = list(csv.DictReader(f))
            self.assertEqual([r["ticker"] for r in data], ["AAPL", "AOS"])
            self.assertEqual(list(data[0].keys()), sc.PROFILE_COLUMNS)
            self.assertIn("Wrote 2 companies", text)

    def test_no_infobox_makes_a_single_request(self):
        f = FakeFetcher(self.pages())
        code, _ = run_main(["profiles", "--tickers", "AAPL", "--no-infobox", "--out", os.devnull], f)
        self.assertEqual(f.requested, [sc.LIST_URL])


class FetcherTests(unittest.TestCase):
    def test_cache_hit_needs_no_network(self):
        with tempfile.TemporaryDirectory() as d:
            f = sc.Fetcher("test-agent", delay=0, cache_dir=d)
            url = "https://example.invalid/page"
            f._cache_path(url).write_text("<html>cached</html>", encoding="utf-8")
            self.assertEqual(f.get(url), "<html>cached</html>")

    def test_robots_disallow_blocks_the_request_and_hides_the_key(self):
        f = sc.Fetcher("test-agent", delay=0)
        rp = sc.urllib.robotparser.RobotFileParser()
        rp.parse(["User-agent: *", "Disallow: /private"])
        f._robots["https://example.invalid"] = rp
        with self.assertRaises(sc.ScrapeError) as ctx:
            f.get("https://example.invalid/private/page?apikey=" + KEY)
        self.assertNotIn(KEY, str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
