#!/usr/bin/env python3
"""
S&P 500 historical market-data scraper.

Output:
    data/
        constituents.csv
        csv/
            AAPL.csv
            MSFT.csv
            ...
            _GSPC.csv

Data sources:
    Constituents: Wikipedia
    Historical prices: Yahoo Finance chart endpoint

Historical CSV format:
    date,open,high,low,close,adj_close,volume

Requires:
    Python 3.8+
    No third-party packages

Default history:
    790 calendar days (approximately two years of trading sessions).
"""

import argparse
import csv
import hashlib
import json
import math
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser

from datetime import datetime, timezone, timedelta
from html.parser import HTMLParser
from pathlib import Path


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

LIST_URL = (
    "https://en.wikipedia.org/wiki/"
    "List_of_S%26P_500_companies"
)

YAHOO_URL = (
    "https://query1.finance.yahoo.com/v8/finance/chart/"
)

INDEX_SYMBOL = "^GSPC"

DEFAULT_TICKERS = [
    "AAPL",
    "MSFT",
    "AMZN",
    "NVDA",
    "GOOGL",
    "META",
    "JPM",
    "JNJ",
    "XOM",
    "WMT",
]

PRICE_COLUMNS = [
    "date",
    "open",
    "high",
    "low",
    "close",
    "adj_close",
    "volume",
]

CONSTITUENT_COLUMNS = [
    "symbol",
    "name",
    "sector",
]


class ScrapeError(Exception):
    """An error occurred while retrieving or processing data."""


# ---------------------------------------------------------------------------
# General helpers
# ---------------------------------------------------------------------------

def clean_text(value):
    """Remove whitespace and Wikipedia footnote references."""
    value = re.sub(r"\[[^\]]{1,8}\]", "", value)
    value = value.replace("\u00a0", " ")
    return re.sub(r"\s+", " ", value).strip()


def normalise_ticker(ticker):
    """Normalise ticker symbols to the project's convention."""
    return ticker.strip().upper().replace("-", ".")


def safe_filename(symbol):
    """Convert symbols into filesystem-safe CSV filenames."""
    return symbol.replace("^", "_")


# ---------------------------------------------------------------------------
# Wikipedia HTML parser
# ---------------------------------------------------------------------------

class TableParser(HTMLParser):
    """
    Extract rows from a selected HTML table.

    Each cell contains:
        tag
        text
        href

    Nested tables are ignored.
    """

    def __init__(self, match):
        super().__init__(convert_charrefs=True)

        self.match = match
        self.in_target = False
        self.done = False
        self.table_depth = 0

        self.rows = []
        self.row = None
        self.cell = None
        self.skip_depth = 0

    def active(self):
        return (
            self.in_target
            and self.table_depth == 1
            and not self.done
        )

    def close_cell(self):
        if self.cell is None:
            return

        raw = "".join(self.cell["parts"])

        lines = [
            clean_text(line)
            for line in raw.split("\n")
        ]

        text = "; ".join(
            line for line in lines if line
        )

        if self.row is not None:
            self.row.append({
                "tag": self.cell["tag"],
                "text": text,
                "href": self.cell["href"],
            })

        self.cell = None
        self.skip_depth = 0

    def handle_starttag(self, tag, attrs):
        if self.done:
            return

        attributes = {
            key: (value or "")
            for key, value in attrs
        }

        if tag == "table":
            if not self.in_target and self.match(attributes):
                self.in_target = True
                self.table_depth = 1

            elif self.in_target:
                self.table_depth += 1

            return

        if not self.active():
            return

        if tag == "tr":

            if self.cell is not None:
                self.close_cell()

            if self.row:
                self.rows.append(self.row)

            self.row = []

        elif tag in ("th", "td") and self.row is not None:

            if self.cell is not None:
                self.close_cell()

            self.cell = {
                "tag": tag,
                "parts": [],
                "href": None,
            }

        elif self.cell is not None:

            if (
                tag == "a"
                and self.cell["href"] is None
                and attributes.get("href")
            ):
                self.cell["href"] = attributes["href"]

            elif tag in ("br", "li", "p", "div"):
                self.cell["parts"].append("\n")

            elif tag in ("sup", "style", "script"):
                self.skip_depth += 1

    def handle_endtag(self, tag):
        if self.done:
            return

        if tag == "table":

            if self.in_target:
                self.table_depth -= 1

                if self.table_depth == 0:

                    if self.cell is not None:
                        self.close_cell()

                    if self.row:
                        self.rows.append(self.row)

                    self.row = None
                    self.in_target = False
                    self.done = True

            return

        if not self.active():
            return

        if tag in ("th", "td") and self.cell is not None:
            self.close_cell()

        elif tag == "tr":

            if self.cell is not None:
                self.close_cell()

            if self.row:
                self.rows.append(self.row)

            self.row = None

        elif (
            tag in ("sup", "style", "script")
            and self.cell is not None
            and self.skip_depth > 0
        ):
            self.skip_depth -= 1

    def handle_data(self, data):
        if (
            self.active()
            and self.cell is not None
            and self.skip_depth == 0
        ):
            self.cell["parts"].append(data)


def parse_table(html_text, match):
    parser = TableParser(match)
    parser.feed(html_text)
    parser.close()
    return parser.rows


# ---------------------------------------------------------------------------
# Wikipedia constituents
# ---------------------------------------------------------------------------

def parse_constituents(html_text, base_url="https://en.wikipedia.org"):
    """Extract the current S&P 500 constituents."""

    rows = parse_table(
        html_text,
        lambda attributes: (
            attributes.get("id") == "constituents"
        ),
    )

    if len(rows) < 2:
        raise ScrapeError(
            "Could not find the S&P 500 constituents table. "
            "Wikipedia may have changed its page layout."
        )

    header = [
        cell["text"].replace("; ", " ").lower()
        for cell in rows[0]
    ]

    def find_column(*names):
        for index, heading in enumerate(header):
            if any(heading.startswith(name) for name in names):
                return index

        return None

    columns = {
        "ticker": find_column("symbol", "ticker"),
        "company": find_column("security", "company", "name"),
        "sector": find_column("gics sector", "sector"),
    }

    if (
        columns["ticker"] is None
        or columns["company"] is None
    ):
        raise ScrapeError(
            "The constituents table is missing Symbol or Security."
        )

    companies = {}

    for row in rows[1:]:

        ticker_index = columns["ticker"]
        company_index = columns["company"]
        sector_index = columns["sector"]

        if len(row) <= max(ticker_index, company_index):
            continue

        ticker = normalise_ticker(
            row[ticker_index]["text"]
        )

        if not ticker:
            continue

        name = row[company_index]["text"]

        sector = (
            row[sector_index]["text"]
            if sector_index is not None
            and sector_index < len(row)
            else ""
        )

        href = row[company_index]["href"]

        companies[ticker] = {
            "ticker": ticker,
            "company": name,
            "sector": sector,
            "wikipedia_url": (
                urllib.parse.urljoin(base_url, href)
                if href else ""
            ),
        }

    if not companies:
        raise ScrapeError(
            "The constituents table contained no companies."
        )

    return companies


# ---------------------------------------------------------------------------
# Wikipedia downloader and cache
# ---------------------------------------------------------------------------

class Fetcher:
    """Polite Wikipedia downloader with robots.txt and caching."""

    def __init__(
        self,
        user_agent,
        delay=1.5,
        cache_dir=".scrape_cache",
        timeout=30,
        retries=3,
    ):

        self.user_agent = user_agent
        self.delay = max(0.0, delay)
        self.cache_dir = (
            Path(cache_dir) if cache_dir else None
        )
        self.timeout = timeout
        self.retries = retries

        self.last_request = 0.0
        self.robots = {}

        if self.cache_dir:
            self.cache_dir.mkdir(
                parents=True,
                exist_ok=True,
            )

    def wait(self):
        elapsed = time.monotonic() - self.last_request

        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)

        self.last_request = time.monotonic()

    def robots_for(self, url):

        parts = urllib.parse.urlsplit(url)

        origin = (
            f"{parts.scheme}://{parts.netloc}"
        )

        if origin in self.robots:
            return self.robots[origin]

        parser = urllib.robotparser.RobotFileParser()

        try:
            self.wait()

            request = urllib.request.Request(
                origin + "/robots.txt",
                headers={
                    "User-Agent": self.user_agent
                },
            )

            with urllib.request.urlopen(
                request,
                timeout=self.timeout,
            ) as response:

                content = response.read().decode(
                    "utf-8",
                    errors="replace",
                )

            parser.parse(content.splitlines())

        except urllib.error.HTTPError as error:

            if error.code in (401, 403):
                parser.parse([
                    "User-agent: *",
                    "Disallow: /",
                ])
            else:
                parser.parse([])

        except (urllib.error.URLError, OSError):
            parser.parse([])

        self.robots[origin] = parser

        return parser

    def cache_path(self, url):

        filename = hashlib.sha1(
            url.encode("utf-8")
        ).hexdigest() + ".html"

        return self.cache_dir / filename

    def get(self, url):

        if self.cache_dir:

            path = self.cache_path(url)

            if path.exists():
                return path.read_text(
                    encoding="utf-8"
                )

        if not self.robots_for(url).can_fetch(
            self.user_agent,
            url,
        ):
            raise ScrapeError(
                f"robots.txt does not allow fetching {url}"
            )

        last_error = None

        for attempt in range(self.retries + 1):

            self.wait()

            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": self.user_agent,
                    "Accept": "text/html",
                },
            )

            try:

                with urllib.request.urlopen(
                    request,
                    timeout=self.timeout,
                ) as response:

                    charset = (
                        response.headers.get_content_charset()
                        or "utf-8"
                    )

                    content = response.read().decode(
                        charset,
                        errors="replace",
                    )

                if self.cache_dir:

                    self.cache_path(url).write_text(
                        content,
                        encoding="utf-8",
                    )

                return content

            except urllib.error.HTTPError as error:

                last_error = f"HTTP {error.code}"

                if (
                    error.code == 429
                    or 500 <= error.code < 600
                ):

                    retry_after = (
                        error.headers.get("Retry-After", "")
                        if error.headers else ""
                    )

                    pause = (
                        min(60, int(retry_after))
                        if retry_after.isdigit()
                        else 2 ** (attempt + 1)
                    )

                    time.sleep(pause)
                    continue

                raise ScrapeError(
                    f"{url}: {last_error}"
                )

            except (urllib.error.URLError, OSError) as error:

                last_error = str(error)
                time.sleep(2 ** (attempt + 1))

        raise ScrapeError(
            f"{url}: failed after {self.retries + 1} attempts "
            f"({last_error})"
        )


# ---------------------------------------------------------------------------
# Yahoo Finance historical data
# ---------------------------------------------------------------------------

def fetch_yahoo_history(
    symbol,
    calendar_days=790,
    delay=1.5,
    retries=3,
):
    """
    Download daily historical OHLCV data.

    Prices:
        open, high, low, close: unadjusted
        adj_close: split/dividend adjusted
        volume: reported trading volume

    The Rust program can subsequently calculate its adjusted OHLC
    values using adj_close / close.
    """

    today = datetime.now(timezone.utc).date()

    start_date = today - timedelta(
        days=calendar_days
    )

    period1 = int(
        datetime.combine(
            start_date,
            datetime.min.time(),
            timezone.utc,
        ).timestamp()
    )

    period2 = int(
        datetime.combine(
            today,
            datetime.min.time(),
            timezone.utc,
        ).timestamp()
    )

    yahoo_symbol = symbol.replace(".", "-")

    parameters = urllib.parse.urlencode({
        "period1": period1,
        "period2": period2,
        "interval": "1d",
        "events": "div,splits",
        "includeAdjustedClose": "true",
    })

    url = (
        YAHOO_URL
        + urllib.parse.quote(
            yahoo_symbol,
            safe="",
        )
        + "?"
        + parameters
    )

    headers = {
        "User-Agent": (
            "Mozilla/5.0 "
            "(compatible; SP500Research/2.0)"
        ),
        "Accept": "application/json",
    }

    last_error = None

    for attempt in range(retries + 1):

        time.sleep(max(0.0, delay))

        try:

            request = urllib.request.Request(
                url,
                headers=headers,
            )

            with urllib.request.urlopen(
                request,
                timeout=30,
            ) as response:

                payload = json.loads(
                    response.read().decode("utf-8")
                )

            chart = payload.get("chart", {})

            if chart.get("error"):
                raise ScrapeError(
                    f"{symbol}: Yahoo error: "
                    f"{chart['error']}"
                )

            results = chart.get("result")

            if not results:
                raise ScrapeError(
                    f"{symbol}: Yahoo returned no data."
                )

            result = results[0]

            timestamps = result.get("timestamp", [])

            indicators = result.get("indicators", {})

            quotes = indicators.get("quote", [])

            adjusted = indicators.get("adjclose", [])

            if not timestamps or not quotes or not adjusted:
                raise ScrapeError(
                    f"{symbol}: incomplete Yahoo response."
                )

            quote = quotes[0]
            adjusted_close = adjusted[0].get("adjclose")

            if adjusted_close is None:
                raise ScrapeError(
                    f"{symbol}: adjusted-close data missing."
                )

            fields = [
                "open",
                "high",
                "low",
                "close",
                "volume",
            ]

            for field in fields:

                if len(quote.get(field, [])) != len(timestamps):
                    raise ScrapeError(
                        f"{symbol}: inconsistent {field} data."
                    )

            if len(adjusted_close) != len(timestamps):
                raise ScrapeError(
                    f"{symbol}: inconsistent adjusted-close data."
                )

            rows = []

            for index, timestamp in enumerate(timestamps):

                values = {
                    "open": quote["open"][index],
                    "high": quote["high"][index],
                    "low": quote["low"][index],
                    "close": quote["close"][index],
                    "adj_close": adjusted_close[index],
                    "volume": quote["volume"][index],
                }

                # Skip incomplete trading observations.
                if any(
                    value is None
                    for value in values.values()
                ):
                    continue

                try:

                    values = {
                        key: float(value)
                        for key, value in values.items()
                    }

                except (ValueError, TypeError):
                    raise ScrapeError(
                        f"{symbol}: invalid numeric data."
                    )

                if not all(
                    math.isfinite(value)
                    for value in values.values()
                ):
                    raise ScrapeError(
                        f"{symbol}: non-finite market data."
                    )

                if (
                    values["open"] <= 0
                    or values["high"] <= 0
                    or values["low"] <= 0
                    or values["close"] <= 0
                    or values["adj_close"] <= 0
                    or values["volume"] < 0
                ):
                    raise ScrapeError(
                        f"{symbol}: invalid OHLCV values."
                    )

                if (
                    values["high"] < values["low"]
                    or values["high"] < max(
                        values["open"],
                        values["close"],
                    )
                    or values["low"] > min(
                        values["open"],
                        values["close"],
                    )
                ):
                    raise ScrapeError(
                        f"{symbol}: inconsistent OHLC prices."
                    )

                if not values["volume"].is_integer():
                    raise ScrapeError(
                        f"{symbol}: non-integer volume."
                    )

                date = datetime.fromtimestamp(
                    timestamp,
                    timezone.utc,
                ).strftime("%Y-%m-%d")

                rows.append({
                    "date": date,
                    "open": values["open"],
                    "high": values["high"],
                    "low": values["low"],
                    "close": values["close"],
                    "adj_close": values["adj_close"],
                    "volume": int(values["volume"]),
                })

            rows.sort(
                key=lambda row: row["date"]
            )

            dates = [
                row["date"]
                for row in rows
            ]

            if len(dates) != len(set(dates)):
                raise ScrapeError(
                    f"{symbol}: duplicate trading dates."
                )

            if len(rows) < 260:
                raise ScrapeError(
                    f"{symbol}: only {len(rows)} valid "
                    "sessions received; at least 260 required."
                )

            return rows

        except ScrapeError:
            raise

        except urllib.error.HTTPError as error:

            last_error = f"HTTP {error.code}"

            if (
                error.code == 429
                or 500 <= error.code < 600
            ):
                time.sleep(
                    min(60, 2 ** (attempt + 1))
                )
                continue

            raise ScrapeError(
                f"{symbol}: {last_error}"
            )

        except (
            urllib.error.URLError,
            OSError,
            KeyError,
            IndexError,
            TypeError,
            ValueError,
        ) as error:

            last_error = str(error)

            time.sleep(
                min(60, 2 ** (attempt + 1))
            )

    raise ScrapeError(
        f"{symbol}: failed after {retries + 1} attempts "
        f"({last_error})"
    )


# ---------------------------------------------------------------------------
# CSV writing
# ---------------------------------------------------------------------------

def atomic_write_csv(path, columns, rows):
    """
    Write to a temporary file before replacing the destination.
    This prevents incomplete individual CSV files.
    """

    path = Path(path)

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    temporary = path.with_name(
        path.name + ".tmp"
    )

    try:

        with open(
            temporary,
            "w",
            newline="",
            encoding="utf-8",
        ) as file:

            writer = csv.DictWriter(
                file,
                fieldnames=columns,
                extrasaction="ignore",
            )

            writer.writeheader()
            writer.writerows(rows)

        temporary.replace(path)

    except OSError:

        if temporary.exists():
            temporary.unlink()

        raise


def write_constituents(path, companies):

    rows = []

    for company in companies:

        rows.append({
            "symbol": company["ticker"],
            "name": company["company"],
            "sector": company.get("sector", ""),
        })

    atomic_write_csv(
        path,
        CONSTITUENT_COLUMNS,
        rows,
    )


def write_price_history(csv_dir, symbol, rows):

    filename = safe_filename(symbol) + ".csv"

    path = Path(csv_dir) / filename

    atomic_write_csv(
        path,
        PRICE_COLUMNS,
        rows,
    )

    return path


# ---------------------------------------------------------------------------
# Main program
# ---------------------------------------------------------------------------

def build_parser():

    parser = argparse.ArgumentParser(
        description=(
            "Download S&P 500 constituents and historical "
            "daily OHLCV data for the Rust breakout detector."
        )
    )

    parser.add_argument(
        "--tickers",
        default=",".join(DEFAULT_TICKERS),
        help="Comma-separated S&P 500 tickers.",
    )

    parser.add_argument(
        "--data-dir",
        default="data",
        help="Output directory (default: data).",
    )

    parser.add_argument(
        "--history-calendar-days",
        type=int,
        default=790,
        help="Historical calendar days (default: 790).",
    )

    parser.add_argument(
        "--delay",
        type=float,
        default=1.5,
        help="Delay between Yahoo requests (default: 1.5).",
    )

    parser.add_argument(
        "--contact",
        default="",
        help="Contact email or project URL for Wikipedia User-Agent.",
    )

    parser.add_argument(
        "--cache-dir",
        default=".scrape_cache",
        help="Wikipedia cache directory.",
    )

    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable Wikipedia caching.",
    )

    return parser


def main(argv=None):

    args = build_parser().parse_args(argv)

    # Validate arguments.
    if args.history_calendar_days <= 0:
        print(
            "error: history days must be positive",
            file=sys.stderr,
        )
        return 2

    if args.delay < 0:
        print(
            "error: delay cannot be negative",
            file=sys.stderr,
        )
        return 2

    # Normalise and deduplicate requested tickers.
    tickers = []

    for ticker in args.tickers.split(","):

        ticker = normalise_ticker(ticker)

        if ticker and ticker not in tickers:
            tickers.append(ticker)

    if not tickers:
        print(
            "error: no tickers specified",
            file=sys.stderr,
        )
        return 2

    data_dir = Path(args.data_dir)

    csv_dir = data_dir / "csv"

    contact = (
        args.contact.strip()
        or "personal research"
    )

    user_agent = (
        "sp500-breakout-research-scraper/2.0 "
        f"({contact})"
    )

    fetcher = Fetcher(
        user_agent=user_agent,
        delay=args.delay,
        cache_dir=(
            None if args.no_cache
            else args.cache_dir
        ),
    )

    try:

        # ---------------------------------------------------------------
        # 1. Download constituents
        # ---------------------------------------------------------------

        print("=" * 65)
        print("S&P 500 CONSTITUENT DOWNLOAD")
        print("=" * 65)

        print(f"Source: {LIST_URL}")

        html = fetcher.get(LIST_URL)

        constituents = parse_constituents(html)

        print(
            f"Found {len(constituents)} current constituents."
        )

        companies = []

        for ticker in tickers:

            company = constituents.get(ticker)

            if company is None:
                raise ScrapeError(
                    f"{ticker} is not in the current "
                    "S&P 500 constituents table."
                )

            companies.append(company)

            print(
                f"  {ticker}: {company['company']}"
            )

        # ---------------------------------------------------------------
        # 2. Download historical prices
        # ---------------------------------------------------------------

        symbols = tickers + [INDEX_SYMBOL]

        historical_data = {}

        print()
        print("=" * 65)
        print("HISTORICAL PRICE DOWNLOAD")
        print("=" * 65)

        print(
            f"Requested history: "
            f"{args.history_calendar_days} calendar days"
        )

        print(
            f"Total symbols: {len(symbols)} "
            f"(including S&P 500 benchmark)"
        )

        for index, symbol in enumerate(
            symbols,
            start=1,
        ):

            print()
            print(
                f"[{index}/{len(symbols)}] {symbol}"
            )

            rows = fetch_yahoo_history(
                symbol=symbol,
                calendar_days=args.history_calendar_days,
                delay=args.delay,
            )

            historical_data[symbol] = rows

            print(
                f"  Received {len(rows)} valid sessions."
            )

            print(
                f"  First date: {rows[0]['date']}"
            )

            print(
                f"  Last date:  {rows[-1]['date']}"
            )

        # ---------------------------------------------------------------
        # 3. Write dataset after all downloads succeed
        # ---------------------------------------------------------------

        print()
        print("=" * 65)
        print("WRITING CSV FILES")
        print("=" * 65)

        data_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        csv_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        # Write constituent information.
        constituents_path = (
            data_dir / "constituents.csv"
        )

        write_constituents(
            constituents_path,
            companies,
        )

        print(
            f"Written: {constituents_path}"
        )

        # Write historical price files.
        for symbol, rows in historical_data.items():

            path = write_price_history(
                csv_dir,
                symbol,
                rows,
            )

            print(
                f"Written: {path}"
            )

        # ---------------------------------------------------------------
        # 4. Summary
        # ---------------------------------------------------------------

        total_rows = sum(
            len(rows)
            for rows in historical_data.values()
        )

        print()
        print("=" * 65)
        print("DATASET SUCCESSFULLY GENERATED")
        print("=" * 65)

        print(
            f"Constituents: {constituents_path}"
        )

        print(
            f"Historical CSV directory: {csv_dir}"
        )

        print(
            f"Companies: {len(companies)}"
        )

        print(
            f"Historical symbols: {len(symbols)}"
        )

        print(
            f"Total price observations: {total_rows:,}"
        )

        print()
        print(
            "The dataset is ready for the Rust CsvProvider."
        )

        return 0

    except ScrapeError as error:

        print(
            f"\nERROR: {error}",
            file=sys.stderr,
        )

        return 1

    except OSError as error:

        print(
            f"\nFILE ERROR: {error}",
            file=sys.stderr,
        )

        return 1


if __name__ == "__main__":
    sys.exit(main())
